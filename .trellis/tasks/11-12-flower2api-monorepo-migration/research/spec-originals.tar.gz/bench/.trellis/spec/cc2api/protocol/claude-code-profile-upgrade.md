# Claude Code Profile Upgrade

> 记录 `cc2api` 升级 Claude Code 版本画像时必须执行的协议契约。目标是让未来升级默认画像时，不再只改版本号而漏掉 CCH、`cc_version`、模型子画像、beta 顺序、bootstrap、超时诊断和账号迁移。

---

## Scenario: Claude Code 版本画像升级

### 1. Scope / Trigger

- Trigger: 升级 `cc2api/` 的 Claude Code 默认版本、User-Agent、请求头、CCH、`cc_version`、bootstrap response、telemetry metadata 或账号默认画像。
- 必须使用真实抓包对比，不允许只根据代码常量推断协议。
- 本场景属于跨层契约：请求重写、header profile、body profile、telemetry、DB migration、Web settings 和远程部署都可能一起受影响。

### 2. Signatures

关键代码入口：

```text
src/service/version_profile.rs
src/service/rewriter.rs
src/service/telemetry.rs
src/service/gateway.rs
src/service/session_hello_probe.rs
src/handler/router.rs
src/store/db.rs
src/store/settings_store.rs
web/src/components/Settings.vue
```

CCH 内部定位函数 `find_cch_value(body: &[u8]) -> Option<usize>` 返回原始 JSON 中五位值的起点。
公开刷新入口为 `Rewriter::refresh_cch_attestation(body: Vec<u8>, account: &Account, client_type: ClientType) -> Vec<u8>`，
由 Gateway 在签名修复改变正文后调用。

关键 wire 字段：

```text
User-Agent: claude-cli/<version> (external, cli)
User-Agent: claude-code/<version>
X-Stainless-Package-Version
X-Stainless-Runtime
X-Stainless-Runtime-Version
X-Stainless-Timeout
anthropic-version
anthropic-beta
x-app
x-anthropic-billing-header: cc_version=<version>.<suffix>; cc_entrypoint=cli; cch=<5hex>;
```

关键 DB 字段：

```sql
accounts.canonical_env.version
accounts.canonical_env.version_base
accounts.canonical_env.build_time
accounts.canonical_env.node_version
settings.claude_code_version_profile
settings.allowed_claude_code_versions
settings.allow_system_role_models
settings.bootstrap_additional_model_options
```

`/api/hello` response signature：

```http
GET /api/hello  -> 200 application/json, body={"message": "hello"}, Content-Length=20
HEAD /api/hello -> 200 application/json, empty body, Content-Length=20
```

抓包目录约定：

```text
data/flows/<account>/<topic_id>/<run_id>/
├── capture_index.json
├── http_capture.jsonl
├── stats.jsonl
└── *.flow
```

HTTP/1 大小写补丁的请求级接口（固定于 reqwest 0.12.4 / hyper 1.9.0）：

```rust
RequestBuilder::http1_header_casing<I, S>(self, names: I) -> RequestBuilder
HeaderCaseMap::from_names<I, S>(names: I) -> Result<Self, InvalidHeaderName>
// 两者约束：I: IntoIterator<Item = S>, S: AsRef<str>。
```

接口只保存头名拼写；头值仍由 `.header(name, value)` 提供，自动长度仍由最终 body 决定。

### 3. Contracts

版本画像必须集中维护：

- `DEFAULT_CLAUDE_CODE_VERSION`
- `DEFAULT_CLAUDE_CODE_VERSION_BASE`
- `DEFAULT_CLAUDE_CODE_BUILD_TIME`
- `DEFAULT_CLAUDE_CODE_VERSION_PROFILE`
- `STAINLESS_RUNTIME_VERSION`
- `claude_cli_user_agent(version)`
- `claude_code_user_agent(version)`
- `DEFAULT_ALLOWED_CLAUDE_CODE_VERSIONS_SETTING`
- `RequestProfile::fable_model(model_id)`
- `RequestProfile::haiku_title_optional_beta_tokens`
- `EndpointProfile::header_profile` / `EndpointHeaderProfile`
- `CchProfile`
- `FableFallbackProfile`

`cc_version` 后缀契约：

- 算法：`sha256("59cf53e54c78" + text[4] + text[7] + text[20] + version).hex()[0:3]`。
- 字符索引必须按 JavaScript UTF-16 code unit 语义。
- 抽样码元先按顺序拼接，再统一转换为 UTF-8；拼接后组成的有效代理对必须还原为完整字符，仅仍孤立的代理项替换为 U+FFFD。缺失索引补字符 `0`，真实 NUL 码元必须保留。
- `cc_version_suffix_matches_node_utf16_boundaries` 使用独立 Node.js 参考值覆盖有效/孤立/倒置代理项、最大 Unicode 码点、中文、ASCII、短/空文本及 NUL；合成文本 `abcd😀😀efghijklmnopqrstuvwxyz` 配版本参数 `2.1.283` 的后缀必须为 `0e9`。该参数仅用于纯函数复现，不表示新增版本画像。
- `messages[0].content` 是数组时，Claude Code 主请求可能先放环境上下文 text block，再放真实用户 prompt text block；后缀文本源应取首条 user message 的最后一个 text block，而不是第一个 text block。
- Haiku/title 这类只有一个 text block 的请求仍取唯一 text block。
- `2.1.280` / `2.1.293` 带 `thread.previous_message_id` 的续轮请求复用入站 billing block 中已有的会话级
  三位小写十六进制后缀；同一会话链的续轮保持一致，同一 run 可以存在交错的独立会话链。即使当前 user message 在
  `tool_result` 后重新出现 text block，也不能按该文本生成确定性后缀。初始线程请求只有
  `thread.type`，仍按最后一个 user text 确定性计算。

`2.1.257` identity 契约：

| 字段 | 值 |
|------|----|
| `version` / `version_base` | `2.1.257` |
| `build_time` | `2026-09-01T05:28:54Z` |
| `User-Agent` | `claude-code/2.1.257` |
| `X-Stainless-Package-Version` | `0.112.1` |
| `X-Stainless-Runtime` | `node` |
| `X-Stainless-Runtime-Version` | `v26.3.0` |
| GrowthBook / session hello UA | `Bun/1.4.1` |
| 默认允许范围 | `2.1.89-2.1.257` |

`2.1.280` identity 契约：

| 字段 | 值 |
|------|----|
| `version` / `version_base` | `2.1.280` |
| `build_time` | `2026-09-21T20:40:17Z` |
| CLI `User-Agent` | `claude-cli/2.1.280 (external, cli)` |
| telemetry `User-Agent` | `claude-code/2.1.280` |
| `X-Stainless-Package-Version` | `0.112.1` |
| `X-Stainless-Runtime` | `node` |
| `X-Stainless-Runtime-Version` | `v26.3.0` |
| GrowthBook / session hello UA | `Bun/1.4.3` |
| `X-Stainless-Timeout` | `600` |
| 默认允许范围 | `2.1.89-2.1.280` |

`2.1.260` identity 契约：

| 字段 | 值 |
|------|----|
| `version` / `version_base` | `2.1.260` |
| `build_time` | `2026-09-03T19:41:35Z` |
| CLI `User-Agent` | `claude-cli/2.1.260 (external, cli)` |
| telemetry `User-Agent` | `claude-code/2.1.260` |
| `X-Stainless-Package-Version` | `0.112.1` |
| `X-Stainless-Runtime` | `node` |
| `X-Stainless-Runtime-Version` | `v26.3.0` |
| GrowthBook / session hello UA | `Bun/1.4.1` |
| `X-Stainless-Timeout` | `600` |
| 默认允许范围 | `2.1.89-2.1.260` |

`2.1.260` 的 endpoint 集合、header 顺序和主请求顶层字段顺序与 `2.1.257` 保持一致；
不得因 patch 版本变化重排已确认的 wire 字段。

`2.1.220` 必须作为独立回滚画像保留，不能复用 2.1.257 的 Stainless、Bun、CCH 或
Fable 5.1 子画像。

`2.1.220` identity 契约：

| 字段 | 值 |
|------|----|
| `version` / `version_base` | `2.1.220` |
| `build_time` | `2026-07-24T22:17:45Z` |
| `User-Agent` | `claude-code/2.1.220` |
| `X-Stainless-Package-Version` | `0.94.0` |
| `X-Stainless-Runtime` | `node` |
| `X-Stainless-Runtime-Version` | `v26.3.0` |
| GrowthBook / hello UA | `Bun/1.4.0` |
| 默认允许范围 | `2.1.89-2.1.220` |

CCH 契约：

- 占位化、初始封口与重试刷新只定位唯一受管理的根级 `system` billing：支持字符串和直接
  `type=text` 块，首个非空白位置须是 billing attribution 行，可跟多行普通上下文。普通文档后续引用、
  messages、tools、metadata 或嵌套 system 中的 CCH 字面量不得被这三步改写。
- attribution 行按独立分号字段识别唯一合法五位 hex CCH；保留既有入口值、附加归因键和原始顺序，
  不要求恰好三个字段或固定字段顺序。`note=cch=12345` 和 `xcch=fedcb` 不构成 CCH 字段。
- 在最终原始字节上只回填该五位值；解码字符串偏移不能直接当作 JSON 字节偏移。目标缺失、非法、
  重复或无法可靠回填时保持 CCH 处理函数的输入，不回退全文搜索、不新增合并或拒绝策略。
  前置占位化继续沿用 cache_control 键存在即跳过的既有规则，包括 null。
- seed 不是默认可变项；升级时先用旧 seed 复算，不命中再尝试找 seed。
- `2.1.156`、`2.1.169`、`2.1.172`、`2.1.173`、`2.1.185`、`2.1.187`、
  `2.1.195`、`2.1.197`、`2.1.220`、`2.1.257`、`2.1.260`、`2.1.280`、`2.1.293` 使用 seed
  `0x4D659218E32A3268`；不能因版本号变化直接更换 seed。
- `2.1.169`：在最终 body 字节上把真实 `cch=<5hex>` 替回 `cch=00000` 后计算，保留完整 body。
- `2.1.172`：在最终 body 字节上替回 `cch=00000` 后，再做 top-level 规范化：
  - `model` 字段保留 key 和空字符串值，排除原模型值。
  - 删除 top-level `max_tokens` 字段。
  - 删除 top-level `fallbacks` 字段。
- `2.1.257`：同样清空 top-level `model` 并删除 top-level `max_tokens`，但
  `fallbacks` 必须按最终精确模型决定：
  - `model=claude-fable-5` 或 `model=claude-fable-5-1` 时保留
    `fallbacks="default"` 参与 CCH。
  - 其他模型仍删除 top-level `fallbacks`。
- `2.1.260`：继续清空 top-level `model`、删除 top-level `max_tokens`；已观察的
  `claude-fable-5-1` 保留 `fallbacks="default"`，Opus、Sonnet 和 Haiku 删除不存在的
  top-level `fallbacks`。没有 `2.1.260 claude-fable-5` 抓包时，不得外推其 fallback
  或 CCH 裁剪规则。
- `2.1.280` / `2.1.293`：保留相同 seed，删除 top-level `max_tokens`，保留最终请求中的 top-level
  `fallbacks`；对序列化 JSON 中每个 key 字节精确等于 `"model"` 且 value 为字符串的字段
  清空值，包括 advisor 工具和 fallback 对象里的嵌套模型。不得改写字符串正文中的
  `\"model\"`、转义 key（例如 `"\u006dodel"`）或非字符串 model 值。
- `2.1.260` 及更早画像的 CCH 输入裁剪必须只作用 top-level JSON 字段；2.1.280/293 的全层级
  model 清空是独立版本契约，不能反向套用到旧画像。
- 不要先 `serde_json` 反序列化再重新序列化后计算 CCH；字段顺序、转义和空格变化会改变结果。

Beta 顺序契约：

- `context-1m-2025-08-07` 不放进通用必需 beta；它由账号 `allow_1m_models` 和客户端传入 beta 共同决定。
- 当允许 1M 并保留 `context-1m-2025-08-07` 时，顺序必须整理为 `oauth-2025-04-20` 后、`interleaved-thinking-2025-05-14` 前。
- `2.1.257 claude-fable-5` 无 1M 主请求顺序：

```text
claude-code-20250219,oauth-2025-04-20,interleaved-thinking-2025-05-14,redact-thinking-2026-02-12,thinking-token-count-2026-05-13,context-management-2025-06-27,prompt-caching-scope-2026-01-05,mid-conversation-system-2026-04-07,advisor-tool-2026-03-01,advanced-tool-use-2025-11-20,effort-2025-11-24,server-side-fallback-2026-07-01,fallback-credit-2026-06-01,extended-cache-ttl-2025-04-11,cache-diagnosis-2026-04-07
```

`2.1.260` 主请求必须按精确模型使用下列 beta，不能把 Fable 5.1 的 token 合并到通用
画像：

Opus 5 `[1m]`：

```text
claude-code-20250219,oauth-2025-04-20,context-1m-2025-08-07,interleaved-thinking-2025-05-14,thinking-token-count-2026-05-13,context-management-2025-06-27,prompt-caching-scope-2026-01-05,mid-conversation-system-2026-04-07,advisor-tool-2026-03-01,advanced-tool-use-2025-11-20,effort-2025-11-24,fallback-credit-2026-06-01,thinking-display-updates-2026-08-18,extended-cache-ttl-2025-04-11,cache-diagnosis-2026-04-07
```

Sonnet 5：

```text
claude-code-20250219,oauth-2025-04-20,interleaved-thinking-2025-05-14,thinking-token-count-2026-05-13,context-management-2025-06-27,prompt-caching-scope-2026-01-05,mid-conversation-system-2026-04-07,advisor-tool-2026-03-01,advanced-tool-use-2025-11-20,effort-2025-11-24,thinking-display-updates-2026-08-18,extended-cache-ttl-2025-04-11,cache-diagnosis-2026-04-07
```

Fable 5.1：

```text
claude-code-20250219,oauth-2025-04-20,interleaved-thinking-2025-05-14,thinking-token-count-2026-05-13,context-management-2025-06-27,prompt-caching-scope-2026-01-05,mid-conversation-system-2026-04-07,per-turn-control-2026-07-01,advisor-tool-2026-03-01,advanced-tool-use-2025-11-20,effort-2025-11-24,server-side-fallback-2026-07-01,fallback-credit-2026-06-01,thinking-display-updates-2026-08-18,extended-cache-ttl-2025-04-11,cache-diagnosis-2026-04-07
```

Haiku main（有 diagnostics）：

```text
oauth-2025-04-20,interleaved-thinking-2025-05-14,thinking-token-count-2026-05-13,context-management-2025-06-27,prompt-caching-scope-2026-01-05,claude-code-20250219,advisor-tool-2026-03-01,advanced-tool-use-2025-11-20,thinking-display-updates-2026-08-18,extended-cache-ttl-2025-04-11,cache-diagnosis-2026-04-07
```

Haiku main 无 diagnostics 时只移除 `claude-code-20250219`；probe、title 和 non-stream
aux 继续使用 `2.1.257` 已确认的独立窄画像。

`2.1.280` 必须按精确模型使用 `version_profile.rs` 中的 280 常量；共同新增的顺序约束为：

- Opus 5.5 与 Fable 5.1 包含 `per-turn-control-2026-07-01`、
  `mid-conversation-tool-changes-2026-07-01`、`mid-conversation-system-clear-at-2026-08-21`、
  `thinking-binding-controls-2026-08-01`，不在基础画像中主动加入 fallback token。
- Sonnet 5 不含 per-turn/tool-changes，包含 system-clear、thinking-binding，并在末尾追加
  `message-threads-2026-08-12`。
- Opus 4.8 普通请求包含 tool-changes、system-clear、effort、thinking-binding 和末尾
  message-threads，不含 per-turn；带 `dangerous_tool_use` safeguard 的 Auto/Plan 请求改用专属
  精确画像，移除 message-threads，并在 effort 后加入 `dangerous-tool-use-2026-09-03`、在
  display 后加入 `afk-mode-2026-01-31`。
- Opus 5.5 带 `dangerous_tool_use` safeguard 的 Auto/Plan 请求同样使用专属精确画像，在
  effort 后加入 `dangerous-tool-use-2026-09-03`、在 display 后加入
  `afk-mode-2026-01-31`；普通请求继续使用基础 Opus 5.5 画像。
- Sonnet 4.5 不含 mid-conversation-system、effort、per-turn 与 tool-changes，保留
  thinking-binding/display。API 生成模式在末尾追加 `message-threads-2026-08-12`；原生
  Claude Code 模式由客户端决定是否携带该 token，不从 `thread` 正文或模式推测开关。
  `MainRequestProfile.client_optional_beta_tokens` 声明此差异：先从 required 集合移除，
  再合并经过账号能力过滤的客户端 beta；不影响 1M/Fast、safeguard 或 count_tokens。
- Haiku main 在 2.1.260 基础上于 display 前新增 `thinking-binding-controls-2026-08-01`；
  无 diagnostics 时仍只移除 `claude-code-20250219`。
- 1M token 仍只在客户端传入且账号白名单允许时插入 oauth 后；仅当 endpoint 精确为
  `/v1/messages` 且最终请求包含非 null `fallbacks` 时，fallback beta 才由动态规则插入，
  不能写进基础模型常量。`/v1/messages/count_tokens` 即使带 `fallbacks` 也只能使用
  count_tokens 专用 beta，不得继承消息生成的 fallback token。

- 当目标版本已经声明非空的精确 `main_models` 时，Haiku main 必须先通过
  `RequestProfile::main_model(model_id)` 精确命中，才能使用该版本的 Haiku main beta；
  未观察的 Haiku 模型回退版本级 `message_beta_tokens`，不能只因 ID 包含 `haiku` 就套用
  新画像。probe、title 和 non-stream aux 属于已有独立证据的请求类型，仍可沿用现有
  Haiku 分类；没有精确 `main_models` 的旧画像继续保持已验证的历史族分类行为。

- Fable `[1m]` 的主请求画像必须按目标版本抓包判断，不能只从 CLI model 后缀推断：
  - `2.1.172` 抓包中，Fable `[1m]` 主请求包含 `context-1m-2025-08-07`，顺序如下。
  - `2.1.173` 抓包中，Fable `[1m]` 主请求不包含 `context-1m-2025-08-07`，只在 telemetry 启动配置里体现 `cli_flag=claude-fable-5[1m]`。
  - `2.1.257` 的 `claude-fable-5-1[1m]` 入口解析后的 message 请求使用精确模型
    `claude-fable-5-1`，不自动携带 `context-1m-2025-08-07`。
  - 当前没有 `2.1.260 claude-fable-5-1[1m]` message 样本；继续保持“不主动注入 1M”
    的兼容行为，但不得宣称该入口已在 `2.1.260` 重新验证。
  - 账号 `allow_1m_models` 只控制客户端已有 `context-1m-2025-08-07` 是否透传，不应自动给 Fable 主请求注入 1M beta。

`2.1.172` Fable `[1m]` 主请求顺序：

```text
claude-code-20250219,oauth-2025-04-20,context-1m-2025-08-07,interleaved-thinking-2025-05-14,redact-thinking-2026-02-12,thinking-token-count-2026-05-13,context-management-2025-06-27,prompt-caching-scope-2026-01-05,mid-conversation-system-2026-04-07,advisor-tool-2026-03-01,advanced-tool-use-2025-11-20,effort-2025-11-24,server-side-fallback-2026-06-01,fallback-credit-2026-06-01,extended-cache-ttl-2025-04-11,cache-diagnosis-2026-04-07
```

Fable body 契约：

- `claude-fable-5` 与 `claude-fable-5-1` 是两个精确模型画像；wire 改写不能用宽泛
  `claude-fable-*` 前缀把二者合并。
- `max_tokens=64000` 默认只在缺失时补齐，不覆盖用户已有值。
- `fallbacks` 必须来自选中的版本画像，只在缺失时补齐，不重复追加，不覆盖用户已有字段。
  - `2.1.257` 的 `claude-fable-5-1` 使用字符串 `"default"`。
  - `2.1.257` 的 `claude-fable-5` 同样使用字符串 `"default"`，不能回退为数组。
  - `2.1.260` 的 `claude-fable-5-1` 使用字符串 `"default"`。
  - `2.1.280` 的 `claude-fable-5-1` 主请求不自动补 `fallbacks`；调用方已有字段保持不变。
  - `2.1.220` 使用 `[{"model":"claude-opus-5"}]`。
  - `2.1.197` 及旧回滚画像保留 `[{"model":"claude-opus-4-8"}]`。
- `2.1.257 claude-fable-5` 缺少 thinking 时补 `{"type":"adaptive"}`，不补 display；
  `2.1.257 claude-fable-5-1` 与 `2.1.260 claude-fable-5-1` 只在缺失时补
  `{"type":"adaptive","display":"updates"}`，不得覆盖客户端已有 thinking 字段。
- `2.1.257` Fable 5.1 beta 顺序必须使用画像常量，其中包含
  `server-side-fallback-2026-07-01` 和 `thinking-display-updates-2026-08-18`，且不包含
  `redact-thinking-2026-02-12`；Fable 5 保留 redact，但 fallback beta 也必须是
  `server-side-fallback-2026-07-01`。
- `2.1.260` Fable 5.1 在 `2.1.257` 画像基础上增加
  `per-turn-control-2026-07-01`；当前没有 `2.1.260 claude-fable-5` 证据，不能套用该画像。
- `2.1.280` Fable 5.1 使用 adaptive thinking/display updates、max effort 和 64000
  max_tokens，但初始主请求未观察到 fallback；不得沿用 2.1.260 的自动 fallback。
- `2.1.220` Fable 顶层字段顺序为 `model,messages,system,tools,metadata,max_tokens,thinking,context_management,fallbacks,output_config,diagnostics,stream`；旧画像保留旧顺序。
- Fable 5/5.1 的 `fallbacks="default"` 必须发送给上游，并按上面的精确版本与模型规则
  参与 CCH；旧画像是否裁剪 fallback 由各自 `CchProfile` 决定。

`2.1.280` 主模型 body 契约：

- Opus 5.5 缺少字段时补 `max_tokens=128000`、
  `thinking={"type":"adaptive","display":"updates"}` 和 `output_config.effort=max`。
- Sonnet 5、Fable 5.1、Opus 4.8 使用 64000；Sonnet 5、Fable 5.1、Opus 4.8 使用
  adaptive thinking/max effort。Sonnet 4.5 使用 32000 与 enabled thinking 31999，不补 effort。
- Opus 5.5 不支持强制工具调用，但网关必须保留调用方显式 `tool_choice=any|tool`，让上游
  返回协议错误；不得静默改为 auto 或关闭 thinking。显式 disabled、thinking、effort 和
  max_tokens 继续遵守既有“只补缺失字段”语义。
- Haiku main 保持 `max_tokens=32000`、enabled thinking 31999/display updates；probe、title、
  non-stream aux 使用各自窄画像。

`2.1.260` 通用与 Haiku body 契约：

- Opus 5、Sonnet 5 主请求缺少 thinking 时补
  `{"type":"adaptive","display":"updates"}`，`max_tokens` 缺失时补 `64000`，并使用
  `output_config.effort=max`；不覆盖客户端已有 thinking、max_tokens 或 effort。
- Haiku main 缺少 thinking 时，只有手动思考与请求参数兼容才补
  `{"budget_tokens":31999,"type":"enabled","display":"updates"}`；`max_tokens` 缺失时
  补 `32000`，不主动添加 `output_config`。自动补齐的预算取
  `min(31999, max_tokens - 1)`，至少为 `1024`；输出上限不足时跳过思考注入，不扩大
  调用方的 `max_tokens`。例如 `max_tokens=4096` 补预算 `4095`，`max_tokens=512`
  保持无 thinking。调用方显式提供的预算、display 和其他参数保持原值。
- API 主模型请求显式设置 `thinking.type=disabled` 时，不追加 display、budget 或
  默认 effort，避免产生 disabled+display 或 Opus 5 disabled+max effort 冲突；
  已有 `output_config` 保留。后续由管理员显式开启的 disabled 兼容改写继续独立生效。
- Haiku 的 `tool_choice.type=any|tool` 与手动思考不兼容，必须保留工具策略并跳过
  默认思考注入；`auto|none` 继续按合法预算补齐。该限制不套用到支持强制工具的
  Opus 5 / Sonnet 5 adaptive 思考模式。
- 上述兼容修正只应用于 API 模式且精确命中当前 `main_models` 的请求；Claude Code
  原生路径、旧画像及既有 probe/title/aux 分类保持原行为。此处只保护默认字段补齐，
  不负责修复调用方已经提交的非法参数组合。
- thinking 字段顺序必须保持 Opus/Sonnet/Fable 5.1 为 `type,display`，Haiku 为
  `budget_tokens,type,display`；主请求顶层字段顺序继续保持抓包顺序。

Haiku 2.1.257 子画像契约：

- 只在模型 ID 包含 `haiku` 时分类；probe 为 `tools` 空、`max_tokens=1`、非流式。
- title 为 `tools` 空、`max_tokens=32000`，并命中结构化 title schema 或历史 title
  prompt marker。结构化分支还要求流式、`thinking.type=disabled`，且
  `output_config.format` 的任一嵌套对象同时声明唯一 required `title` 和
  `properties.title`。
- 为兼容已存在的 title 变体，历史 prompt marker 分支不额外强制 `stream=true`，schema
  检测也保留递归查找；这是已接受的兼容宽度，不能在缺少新抓包回归时擅自收窄。
- non-stream aux 为 `tools` 空、`max_tokens=1024`、非流式；其余 Haiku 请求归为 main。
- main 有 `diagnostics` 时使用完整 Haiku main beta；无 `diagnostics` 时省略
  `claude-code-20250219`；probe、title、non-stream aux 各使用画像中的独立窄 beta。

标题可选 beta 契约：

- 2.1.257/2.1.260 的标题基础窄画像之外，只保留客户端已携带的
  `server-side-fallback-2026-07-01`、`fallback-credit-2026-06-01`；按此顺序去重，
  插入 `cache-diagnosis-2026-04-07` 前。没有携带时不主动开启。
- token 按逗号拆分、去空白后精确匹配；旧日期、相似后缀和父模型的其他 beta 不合入。
- 两种客户端入口共用最终规范化。旧画像的可选列表为空；probe 不保留这些 token。

后台 UA/beta 契约：

- 2.1.257/2.1.260 使用 `EndpointHeaderProfile::ClaudeCode21257`；2.1.280 使用
  `ClaudeCode21280`，继承下表并追加后面的 280 规则。下表的 12 类
  路径来自 260 原始 flow；257 JSONL 可核对其中 10 类，stream/archive 不在该索引中。
- `{id}` 必须是非空单一路径段，后缀精确匹配；相似路径、未知子路径、额外尾斜杠
  不自动套用。旧画像使用 `Legacy`，保留既有行为。
- 两种客户端入口都在通用 header 处理后应用下表；“无”表示删除传入 beta。

| 路径 | User-Agent | anthropic-beta |
| --- | --- | --- |
| `/v1/code/sessions`、`/v1/code/sessions/{id}/bridge` | `claude-code/<version>` | 无 |
| `/v1/code/sessions/{id}/worker`，以及其 `/events`、`/events/stream`、`/internal-events`、`/heartbeat` | `claude-code/<version>` | 无 |
| `/v1/code/sessions/{id}/client/presence` | `axios/1.15.2` | 无 |
| `/v1/sessions/{id}`、`/v1/sessions/{id}/archive` | `claude-code/<version>` | `ccr-byoc-2025-07-29` |
| `/api/claude_code/notification/preferences` | `claude-cli/<version> (external, cli)` | `oauth-2025-04-20` |
| `/v1/ultrareview/quota` | `claude-cli/<version> (external, cli)` | 无 |

以上契约只覆盖 UA/beta，不代表 worker JWT、完整请求头顺序、响应或长连接代理已实现。

2.1.280 非遥测补充契约（本地与正式抓包对照）：

| 路径 | User-Agent | anthropic-beta / 专用请求头 |
| --- | --- | --- |
| `/api/frame/contract/latest` | `claude-cli/2.1.280 (external, cli)` | 精确 oauth；保留 `X-Frame-CP`、`X-Frame-Surface`、`X-Frame-Platform`、`X-Frame-Client-Version`、`X-Frame-Session-Id`，版本来自所选画像 |
| `/v1/mcp/{id}` | `claude-code/2.1.280 (cli)` | 无 beta；保留 `X-Mcp-Client-Session-Id`、`mcp-method` |
| `/api/organizations/{id}/model_selector/cc` | `claude-cli/2.1.280 (external, cli)` | 无 beta |
| `/api/oauth/organizations/{id}/marketplaces`、`plugins/list-plugins`、`skills/list-skills`、`skills/{id}/download` | 同上 | 无 beta |

- 新端点规则仍按非空路径段和精确后缀匹配，近似路径不放宽；旧版本 UA/beta 不套 280 规则。
- 原生 `/v1/messages` 的分类、工具耗时及 agent/prompt 关联头按下方「原生 Messages
  代理关联头透传」合同处理；其它端点不继承这些消息调用字段，API 请求不伪造工具耗时。
  Frame/MCP 新增专用头也只在对应端点放行。
- `/v1/mcp_servers` 的 280 capabilities 为 Base64 编码的
  `{"roots":{"listChanged":true},"elicitation":{}}`；旧画像仍为 `roots:{}`。访问策略独立，不自动放行 axios。
- HTTP/1 大小写必须检查实际 TCP 字节。`ordered_anthropic_headers` 给出顺序和拼写，业务
  forwarding/count_tokens 再通过 `http1_header_casing` 显式传给固定版本的 reqwest/hyper
  补丁；Content-Length 只指定名称拼写，长度由最终 body 自动生成。遥测 event_logging/eval
  不启用，默认请求行为不变；HTTP/2 仍使用规范要求的小写名字。
- 依赖补丁与来源见 `cc2api/vendor/README.md`。升级不得仅修改 HeaderMap 或使用全局
  Title-Case 冒充精确混合大小写；克隆、重定向、代理及敏感头删除必须回归。

Bootstrap 契约：

- `/api/claude_cli/bootstrap` response 可能是 gzip；改写前必须按 `Content-Encoding` 解码 JSON。
- 改写后的响应返回未压缩 JSON 时必须移除或重算 `Content-Encoding`、`Content-Length`、`Transfer-Encoding`，避免客户端按旧压缩头解释。
- Fable 能力由全局设置控制：
  - `bootstrap_model_options_mode=passthrough`：不改上游。
  - `configured`：可按版本画像注入 `client_data.cedar_basin`、
    `client_data.cedar_lagoon`、`additional_model_options`；cwk 必须按精确模型 ID 选择，
    不能只按 Fable/Opus family 选择。
  - `2.1.220` 的 Fable query 使用 `cwk_cfg_key="marigold"`，Opus 5 query 使用
    `cwk_cfg_key="belladonna"`。
  - `2.1.257` configured 默认模型选项为 `claude-fable-5-1[1m]`，
    `claude-fable-5` 使用 `marigold`，`claude-fable-5-1` 使用 `sorrel`，Opus 5 使用
    `belladonna`，`client_data.cedar_basin="2027-08-31"`。
  - `2.1.260` configured 继续使用 `claude-fable-5-1[1m]` 和
    `client_data.cedar_basin="2027-08-31"`；Opus 5=`belladonna`、Sonnet 5=`pewter`、
    Fable 5.1=`sorrel`、Haiku=`null`。当前没有 `2.1.260 Fable 5` cwk 证据。
  - `2.1.280` configured 继续使用 `claude-fable-5-1[1m]` 和同一 cedar basin；
    Opus 5.5=`saffron`、Sonnet 5=`pewter`、Fable 5.1=`sorrel`，Haiku、Opus 4.8、
    Sonnet 4.5 均为 `null`。Opus 5 的 belladonna 仅作为历史兼容映射保留，不能宣称为
    2.1.280 新抓包事实。
  - `hide_fable`：隐藏 Fable 入口并仅清空所选精确模型对应的 Fable key，不得误清除
    Opus 5 的合法 `belladonna` 或 Sonnet 5 的合法 `pewter`。

`/api/hello` 边界契约：

- cc2api 必须在管理路由和鉴权 fallback 之前注册公开的 `GET/HEAD /api/hello`。
- GET 返回精确 JSON `{"message": "hello"}`；HEAD 返回相同 representation 的 `Content-Type` 和 `Content-Length: 20`，但 body 必须为空。
- 该端点是无状态连通性端点，不读取 gateway token，不选择账号，不占用 RPM/并发，不生成 telemetry，也不代理到上游。
- Claude Code `2.1.220` 的 hello 预检固定访问 `https://api.anthropic.com/api/hello`，不使用 `ANTHROPIC_BASE_URL`；模型请求才使用配置的 base URL。
- 因此当前不得为 new-api 添加同名本地响应、渠道选择或故障转移。只有后续版本抓包证明 hello 开始使用 `ANTHROPIC_BASE_URL` 时，才重新评估透传策略。
- session hello 代理探测的 UA 必须来自请求账号副本的有效版本画像：2.1.280 使用 `Bun/1.4.3`，
  2.1.260 与 2.1.257 使用 `Bun/1.4.1`，2.1.220 回滚画像继续使用 `Bun/1.4.0`。

Telemetry 契约：

- `env.version`、`env.version_base`、`env.build_time` 必须跟本次请求或自动遥测容器的有效版本画像一致；客户端模式下无法从原始 UA 匹配版本时使用配置的默认画像。
- `model`、`preNormalizedModel`、`betas` 应来自最终请求 profile。
- `2.1.260` 与 `2.1.280` 继续使用既有 `ClaudeCode2185` telemetry shape；只迁移 env、build time 和
  UA，不因版本号新建 shape。
- `tengu_api_query` / `tengu_api_success` 等 request 事件的 `betas` 使用最终 message
  profile；普通启动和内部事件使用独立的窄 base beta，允许继续包含
  `redact-thinking-2026-02-12`。message beta 去掉 redact 时，不能同步改写 telemetry
  base beta。
- 非 Opus 启动时，在模型解析前短暂出现默认 `claude-opus-5[1m]` telemetry 不代表 wire
  主模型变化；以最终 request 事件和 `/v1/messages` 为准。
- `flags=model` 只表示 CLI 使用了一次性 `--model` 覆盖，不是 Fable 协议字段；不要因为模型是 Fable 就无条件写入。

账号迁移契约：

- 启动迁移必须把已有账号 `canonical_env.version/version_base/build_time/node_version` 更新到当前默认画像。
- 启动迁移必须同时迁移旧默认 settings 组合：当 `settings.claude_code_version_profile` 仍是上一个默认 profile，且 `settings.allowed_claude_code_versions` 仍是对应旧默认范围时，必须把二者升级到当前默认画像。
- 显式回滚 profile 只能在管理员自定义过 `allowed_claude_code_versions` 时保留；否则旧默认 profile 会让远程老库继续发送旧 UA / env 画像。
- `allow_system_role_models` 默认包含 `claude-fable-5-1`；一次性迁移必须按逗号列表精确
  去重后追加，并保留管理员自定义模型。
- `bootstrap_additional_model_options` 只在仍等于旧 Fable 5 默认 JSON 时迁移到 Fable
  5.1 默认值；自定义 JSON 保留。
- 不迁移 `allow_1m_models`、`rewrite_disabled_thinking_models` 或
  `intercept_assistant_prefill_models`。
- 远程部署后必须查 DB 版本分布，不能只依赖日志判断。

流式超时诊断契约：

- `stable_upstream_stream` 必须接收脱敏后的 upstream request ID，优先取 `request-id`，
  再取 `x-request-id`；超过 128 字符或包含非 `[A-Za-z0-9_.-]` 字符时只记录短 SHA256。
- `chunk_count=0` 超时记录 `upstream_first_byte_timeout`，错误文本为
  `upstream first byte timeout`；已收到真实 chunk 后超时记录
  `upstream_stream_idle_timeout`，错误文本为 `upstream stream idle timeout`。
- 两类日志都记录 account、upstream request ID、`wait_ms`、`chunk_count` 和
  `max_gap_ms`，不得记录请求正文、Authorization、Cookie 或账号邮箱。
- keepalive 只能在 `first_chunk_seen=true` 后注入，不能用伪造 SSE 掩盖上游首字节卡死，
  也不能重置真实上游 chunk 的静默超时。

### 4. Validation & Error Matrix

| 条件 | 期望 |
|------|------|
| 新版本抓包 CCH 不命中旧 seed | 先尝试输入规范化差异；只有多组样本都不命中时再逆向 seed |
| 用户／工具／metadata 的 CCH 出现在 billing 之前 | 保持示例原文，只更新根级受管理 billing；刷新使用相同定位规则 |
| 唯一 billing 包含附加归因键或字段变序 | 保留字段与顺序，正常重置、封口及刷新独立 CCH 字段 |
| billing／CCH 缺失、非法、重复或编码无法可靠定位 | CCH 处理保持输入，不全文回退；其它既有 body 改写及缓存规则独立执行 |
| `cc_version` 主请求按第一个 text block 计算不命中 | 检查首条 user message 是否有多个 text block；按最后一个 text block 复算 |
| `cc_version` 在线程续轮按当前 text 复算不命中 | 检查 `thread.previous_message_id`；存在时校验三位小写十六进制形状、同 run 稳定性，并在网关改写时保留入站后缀 |
| Fable 带 `[1m]` 时 beta 顺序与抓包不同 | 先按目标版本抓包判断是否应有 `context-1m-2025-08-07`；若应有，再整理到 `oauth` 后面 |
| 2.1.257 Fable 5.1 CCH 不命中 | 确认清空 `model`、删除 `max_tokens`，但保留 top-level `fallbacks="default"` |
| 2.1.257 Fable 5 CCH 不命中 | 确认 fallback 是字符串 `"default"`、beta 使用 `server-side-fallback-2026-07-01`，并保留 fallback 参与 CCH |
| 2.1.260 Fable 5.1 CCH 不命中 | 保留 `fallbacks="default"`；不得沿用旧的“所有模型删除 fallback”裁剪 |
| 2.1.280 Opus/Fable CCH 不命中 | seed 保持不变；除顶层 model/max_tokens 外，检查 advisor 工具或 fallback 对象里的字符串 model 是否也清空 |
| Fable 5.1 被套用 Fable 5 fallback/beta | 检查 `RequestProfile::fable_model` 是否按精确模型 ID 命中，不能使用 family 前缀选择 wire 画像 |
| 2.1.260 主请求缺少 thinking display 且参数兼容 | 按精确模型补 display；Haiku 缺省输出上限时使用 `budget_tokens=31999` 和 `type=enabled` |
| 2.1.280 Opus 5.5 缺少主模型参数 | 补 128000、adaptive/display updates、max effort；显式强制工具调用保持原样交给上游校验 |
| `/v1/messages/count_tokens` 请求包含 `fallbacks` | 保留 token-counting 画像；不得加入 `server-side-fallback` 或 `fallback-credit` |
| API Haiku 缺少 thinking，max_tokens=4096 / 512 | 分别补预算 `4095` / 跳过注入，输出上限保持不变 |
| API 主模型显式 thinking.type=disabled | 不补 display、budget 或默认 effort，调用方原有配置保持不变 |
| API Haiku 指定 tool_choice=any/tool 且未开启 thinking | 保留强制工具策略，不能自动开启 enabled thinking；Opus/Sonnet adaptive 不受此限制 |
| 未观察 Haiku main 命中 2.1.260 Haiku beta | 新画像存在精确 `main_models` 时检查 `RequestProfile::main_model(model_id)`；未命中则回退版本级通用 beta |
| bootstrap Sonnet 5 没有 `pewter` | 检查 cwk 是否按精确模型映射，不能只维护 Fable/Opus 两个 family key |
| message beta 更新后普通 telemetry 丢失 redact | 将 base beta 与最终 message beta 分开维护，request 事件显式覆盖 |
| Haiku title 分类出现历史变体 | 保留结构化 schema 和旧 prompt marker 两条路径；没有新抓包证据时不收窄旧兼容分支 |
| 257/260 标题携带合法 fallback token | 仅保留已携带白名单 token，按抓包顺序放在 cache-diagnosis 前 |
| 标题未携带 fallback 或只有相似未知 token | 输出基础窄 beta，不主动开启 fallback |
| 已知 worker/presence/quota 路径携带主模型 beta | 输出端点专用 UA，删除 anthropic-beta |
| 未知后台子路径或旧版本画像 | 保留既有处理，不能用宽泛前缀匹配扩大修正范围 |
| 原生 280 Sonnet 4.5 未传 message-threads beta，即使正文有 thread | 不主动补 token；显式传入则保留并去重 |
| HTTP/1 casing 名称含空格、CRLF 或为空 | `from_names` 返回 InvalidHeaderName；reqwest 的 build/send 返回 builder 错误，不发起网络请求 |
| 重定向跨地址，敏感头按原策略删除 | casing 映射不能恢复 Authorization；其余保留头继续使用指定拼写 |
| 请求未显式启用 casing，或使用 HTTP/2 | 保持原网络栈的规范化行为，不能让前一个请求的选项泄漏到后续请求 |
| 上游返回 200 headers 后一直无 SSE body | 等待历史 upstream idle timeout；记录 `upstream_first_byte_timeout`，不要提前注入 keepalive |
| 已收到 SSE chunk 后长时间静默 | 记录 `upstream_stream_idle_timeout`；keepalive 可维持下游连接，但不得重置上游 idle timeout |
| bootstrap response 有 gzip | 先解码再改 JSON，返回时修正压缩/长度相关 header |
| 未携带 token 请求 `GET/HEAD /api/hello` | 返回 200；HEAD body 为空且 `Content-Length=20` |
| 未携带 token 请求其他 fallback 路径 | 保持原 gateway token 鉴权，不得因 hello 公开而放宽 |
| 讨论让 new-api 透传 hello | 先用目标版本探针验证是否使用 `ANTHROPIC_BASE_URL`；固定官方域名时不新增路由 |
| 老库保留旧默认 `claude_code_version_profile` | 若 `allowed_claude_code_versions` 也是旧默认范围，迁移 profile 和 allowed range 到当前默认；若 allowed range 是管理员自定义值，则保留显式回滚 |
| 远程部署后账号仍是旧版本 | 检查迁移是否执行；直接查 volume 内 SQLite/Postgres 的 `canonical_env` |
| 抓包分析需要保存到仓库 | 禁止提交完整 `http_capture.jsonl`、token、Cookie、Authorization、邮箱、完整 prompt/响应正文 |

### 5. Good/Base/Bad Cases

**Good**：升级版本前先收集 baseline 和目标版本的 Opus/Fable/Haiku 抓包，离线复算 `cc_version` 与 CCH，确认 beta 顺序，再改 profile 和测试。

**Good**：普通正文里的 `cch=00000` 作为真实内容参与哈希并保持原文；billing 内唯一 CCH 单独占位并回填。
**Base**：重复 billing 没有唯一目标时保持 CCH 输入，不擅自合并 system 块。
**Bad**：搜索全文首个 `cch=00000` 或任意五位 CCH。应改为定位唯一受管理 billing，附加归因键仍保留。

**Good**：Fable 5 与 Fable 5.1 使用两个精确子画像，只在共享周配额判断中把已知 ID 和
`[suffix]` 形式归到 `seven_day_fable`。

**Good**：Haiku probe/title/non-stream aux 继续使用已验证的请求类型分类；Haiku main 在
新画像中只有精确模型 ID 命中时才使用新 beta，未知 Haiku 回退版本级通用画像。

**Good**：抓包分析同时核对 raw flow 与 JSONL/index；结构化索引完整不等于没有未完成的
零正文 message 或后台长连接尝试。

**Good**：标题可选 token 的三种已观察组合由脱敏 fixture 固定预期；后台端点同时断言
UA 和 beta，覆盖两种入口及无 beta 的删除行为。

**Good**：原生 Sonnet 4.5 请求带 `message-threads-2026-08-12` 时保留，未带时省略；
不根据正文 `thread` 或猜测的 feature flag 补齐。API 生成模式继续使用默认 beta。

**Base**：HTTP/1 业务请求把有序头名和 `Content-Length` 传给 `http1_header_casing`，
再按同一列表设置头值；`Content-Length` 的值由发送库计算，测试读取原始 TCP 字节。

**Bad → Correct**：仅调用 `.header("User-Agent", value)` 并断言 HeaderMap，不能证明
实际发送大小写；应同时启用请求级 casing，并断言线上编码中的 `User-Agent` 大写和
`anthropic-beta` 小写。不要用全局 Title-Case 覆盖所有头名。

**Base**：只升级一个 patch 版本，也必须至少验证 `/v1/messages` header、body keys、billing header、bootstrap 和 telemetry metadata 是否变化。

**Bad**：只把 `DEFAULT_CLAUDE_CODE_VERSION` 改成新版本，未同步 `User-Agent`、账号迁移、CCH 输入 profile 和 beta 顺序。

**Bad**：只迁移 `allowed_claude_code_versions`，但没有把旧默认 `claude_code_version_profile` 迁到新默认，导致启动时继续按旧 profile 刷账号 env。

**Bad**：看到 Fable 抓包里有 `flags=model`，就把它硬编码成所有 Fable telemetry 字段。

**Bad**：把 bootstrap cwk 按 Fable family 合并，导致 2.1.257 Fable 5 的 `marigold`
被 Fable 5.1 的 `sorrel` 覆盖，或漏掉 2.1.260 Sonnet 5 的 `pewter`。

**Bad**：把 `context-1m-2025-08-07` 放进 Fable 必需 beta，导致无 1M 设置时也开启 1M beta。

**Bad**：用 `/v1/messages` 前缀匹配动态 fallback beta，导致 count_tokens 请求继承消息生成专用 token。

**Bad**：为了消除理论误判，在没有覆盖历史 title 变体的抓包和测试时收窄 Haiku 兼容
marker，导致原有标题生成请求落回通用 beta。

**Bad**：看到模型 ID 包含 `haiku` 就给所有 Haiku main 套用最新 beta，导致未观察模型
获得新 beta，却没有对应的 thinking、body 和 CCH 子画像。

**Bad**：把 200 response headers 当成流已成功；没有首个 SSE chunk 时仍可能在客户端
watchdog 前后报 `No response from API`。

**Bad**：因为模型请求链路是 `Claude Code -> new-api -> cc2api`，就假设 hello 也会使用同一 base URL，并在 new-api 中臆造渠道路由。

### 6. Tests Required

- `cch_initial_seal_preserves_user_placeholder_before_billing`、
  `cch_retry_refresh_preserves_user_hex_before_billing` 与
  `cch_placeholder_reset_preserves_system_document_and_reminder` 覆盖三处污染。
- `cch_billing_location_matches_independent_reference_and_exact_bytes` 使用合成夹具
  `cch-billing-location.json` 的独立 XXH64 期望断言五位值之外字节不变；
  `cch_billing_extra_fields_and_field_order_preserve_existing_compatibility` 覆盖附加字段与变序，
  相关回归另覆盖 API／CC、特殊路径、非法／重复目标、转义与缓存前置跳过条件。
- 280 非遥测请求头：messages 的 request-class/tool-duration 和代理关联头仅在精确 messages
  路径透传；Frame/MCP 专用头、后台 UA/beta、近似路径排除、旧版本 capabilities 均有正反例。
- Sonnet 4.5：客户端带/不带 token、重复 token、正文有/无 thread、API 默认值，以及
  Fast/1M 能力过滤分别断言；不得把 API 默认画像测试当作原生客户端透传测试。
- `http1_header_casing_test` 与网关实际发送回归：混合大小写、相对顺序、自动长度、
  clone/转换、重定向删除敏感头、HTTP 代理、非法名字和未启用请求的隔离；遥测路径保持原发送行为。

- API 参数组合回归必须通过真实 `rewrite_body` 入口并指定精确模型 ID，不能只用
  空请求或只断言字段存在：
  - Haiku 输出上限覆盖 `512/1024/1025/2048/4096/8192/32000/64000` 和缺省，
    自动预算满足 `1024 <= budget_tokens < max_tokens`，显式预算和 display 保留。
  - Haiku、Opus 5、Sonnet 5 的 disabled 不增加任何 thinking 子字段或默认 effort；
    覆盖调用方已有 effort 的保留行为。
  - Haiku 的 `auto/none/any/tool` 分别组合 thinking 缺省和 disabled；Opus/Sonnet
    adaptive 强制工具继续可用；2.1.257 API 及 2.1.260 原生 Claude Code 参数不变。
- `cargo fmt --check`
- `cargo test`
- `cargo test cch`
- 定向测试：
  - `cc_version_suffix_uses_string_indices`
  - `cc_version_suffix_source_uses_last_user_text_block`
  - `fable_messages_headers_use_fallback_beta_without_context_1m`
  - `fable_context_1m_beta_keeps_claude_code_order_when_allowed`
  - 2.1.260 Opus/Sonnet/Fable 5.1 使用 64000、adaptive display updates 和各自精确
    beta；Haiku 使用 32000、budget 31999、enabled display updates 且无 output_config
  - 2.1.260 Fable 5.1 使用 `fallbacks="default"`、per-turn beta，2.1.220 不识别该画像
  - 2.1.280 仅精确 `/v1/messages` 在非 null fallback 时动态加入 fallback beta；
    `/v1/messages/count_tokens` 带 fallback 时仍不包含两项 fallback token
  - 2.1.257 CCH 对 Fable 5 与 Fable 5.1 保留 top-level fallback，对其他模型删除
    fallback；2.1.260 对 Fable 5.1 保留 fallback
  - Haiku probe、结构化/旧 marker title、main 有无 diagnostics、non-stream aux 的 beta
    分类；保留兼容宽度的反例必须有回归断言；另需断言未观察 Haiku main 在存在精确
    `main_models` 的新画像中回退版本级通用 beta
  - `claude-code-2.1.260-header-compat.json`：标题基础/credit/server-side+credit 三种变体，
    重复、乱序、未知 token；257/260 两种入口一致，旧画像和 probe 保持窄集合
  - 后台 12 类路径逐项核对 UA/beta，传入主模型 beta 不得污染无 beta 端点；
    相似未知路径、空 session、尾斜杠和旧画像保持既有行为
  - Fable 5/5.1 与 `[suffix]` 命中 `seven_day_fable`，相似 preview 模型不命中
  - bootstrap 按精确模型断言 2.1.257 Fable 5=`marigold`、Fable 5.1=`sorrel`，以及
    2.1.260 Opus 5=`belladonna`、Sonnet 5=`pewter`、Fable 5.1=`sorrel`、Haiku=`null`
  - system-role 和 bootstrap 默认迁移只追加/替换历史默认，三个明确不迁移列表保持原值
  - 首字节 timeout、首 chunk 后 idle timeout、首 chunk 前无 keepalive、request ID 脱敏
  - bootstrap gzip 解码和 configured/hide_fable 行为
  - assembled Router 中无 token 的 GET/HEAD hello 返回 200，HEAD body 为空且长度为 20，其他 fallback 路径仍返回 401
  - telemetry 中 base beta 与 request beta 分离，Fable `betas`、`model` 正确，且不无条件
    写 `flags=model`
  - TokenTester 按账号选中画像生成 2.1.260、2.1.257、2.1.220 和旧回滚 profile 的 UA、
    Stainless package/runtime 和 beta
  - 旧默认 `claude_code_version_profile` + 旧默认 `allowed_claude_code_versions` 会升级到当前默认
  - 自定义 `allowed_claude_code_versions` 下的旧 profile 作为显式回滚保留
- 抓包回归：
  - 169 baseline CCH 命中旧完整 body 规则。
  - 172 Opus CCH 命中 `model + max_tokens` 排除规则。
  - 172 Fable CCH 命中 `model + max_tokens + fallbacks` 排除规则。
  - 257 Opus、Fable 5、Fable 5.1、Haiku 样本的 `cc_version` 与 CCH 全量命中；两个
    Fable 精确模型的 `fallbacks="default"` 都保留参与 hash。
  - 260 Opus、Sonnet、Fable 5.1、Haiku 共 117 条 billing 样本的 `cc_version` 与 CCH
    全量命中；删除 Fable 5.1 fallback 的错误算法必须全量不命中该模型样本。
  - 280 Opus 5.5、Sonnet 5、Fable 5.1、Haiku、Opus 4.8、Sonnet 4.5 的 billing 样本
    全量命中“相同 seed + 所有精确字符串 model 清空 + 顶层 max_tokens 删除 + fallback 保留”规则；
    初始请求的 `cc_version` 确定性复算命中，线程续轮后缀符合三位小写十六进制形状并在同一
    run 内保持一致。
- Fable `[1m]` 抓包 beta 是否包含 `context-1m-2025-08-07`、以及包含时的顺序，与目标版本代码输出完全一致。
- 远程部署验收：
  - `docker compose pull` 后必须 `up -d --force-recreate`。
  - `curl http://127.0.0.1:<port>/` 返回 200。
  - DB 中 `accounts.canonical_env.version/version_base/build_time` 分布全部为目标默认值。

### 7. Wrong vs Correct

#### Wrong: 标题精确画像始终删除全部客户端可选 beta

```text
标题携带 fallback-credit-2026-06-01 -> 仅输出固定基础 beta
```

#### Correct: 标题基础画像加版本化的已携带白名单

```text
标题携带 fallback-credit-2026-06-01 -> 基础 beta + credit（放在 cache-diagnosis 前）
标题未携带可选 token -> 基础 beta
```

#### Wrong: `cc_version` 固定取第一个 text block

```rust
for item in arr {
    if let Some(text) = item.get("text").and_then(|t| t.as_str()) {
        return text.to_string();
    }
}
```

这样会取到 Claude Code 注入的环境上下文 block，主请求后缀会和抓包不一致。

#### Correct: 对多 text block 取最后一个 prompt block

```rust
if let Some(text) = arr
    .iter()
    .rev()
    .find_map(|item| item.get("text").and_then(|t| t.as_str()))
{
    return text.to_string();
}
```

#### Wrong: 把客户端 1M beta 追加到末尾

```text
claude-code-20250219,oauth-2025-04-20,...,cache-diagnosis-2026-04-07,context-1m-2025-08-07
```

#### Correct: 按抓包把 1M beta 放到 oauth 后

```text
claude-code-20250219,oauth-2025-04-20,context-1m-2025-08-07,interleaved-thinking-2025-05-14,...
```

#### Wrong: 用 Fable family 前缀选择 wire 画像

```rust
if model.starts_with("claude-fable-") {
    apply_fable_5_profile(body);
}
```

这会把 `claude-fable-5-1` 错写成 Fable 5 的 fallback、beta 和 CCH 输入。

#### Correct: 版本画像内按精确模型 ID 查找

```rust
if let Some(fable) = request_profile.fable_model(model) {
    apply_fable_profile(body, fable);
}
```

family 判断只用于已确认共享的 `seven_day_fable` 配额；wire profile 仍由精确 ID 决定。

#### Wrong: Haiku main 只按 family 选择最新 beta

```rust
if model_id.contains("haiku") {
    return request_profile.haiku_main_beta_tokens;
}
```

这会让未抓包的 Haiku 模型获得最新 beta，但其它主请求字段仍走通用画像。

#### Correct: 新画像的 Haiku main 先精确命中

```rust
if let Some(main) = request_profile.main_model(model_id) {
    return main.message_beta_tokens;
}
return request_profile.message_beta_tokens;
```

probe、title 和 non-stream aux 继续走各自已验证的独立窄画像；旧画像没有精确主模型表时
保留历史兼容行为。

#### Wrong: 假设 hello 跟随模型 base URL

```text
Claude Code -> ANTHROPIC_BASE_URL -> new-api -> /api/hello 渠道选择
```

#### Correct: 先按目标版本验证真实请求边界

```text
Claude Code 2.1.220 hello -> https://api.anthropic.com/api/hello
Claude Code 2.1.220 messages -> ANTHROPIC_BASE_URL -> new-api -> cc2api
```

---

## Scenario: Auto/Plan 集成式 safeguards 协议

### 1. Scope / Trigger

- Trigger：Claude Code 2.1.280 的 `/v1/messages` 顶层包含 `safeguards` 数组，且其中存在
  `type="dangerous_tool_use"` 时适用。
- 目标：保持官方 Auto/Plan 请求体、精确 beta 顺序与流式分类结果；该协议与下方旧版独立
  classifier 请求是两个并存的 wire 协议。

### 2. Contracts

- 仅 2.1.280 已抓包确认的 `claude-opus-5-5` 与 `claude-opus-4-8` 命中 integrated safeguard
  子画像；`classifier_context.permission_mode` 可为 `auto` 或 `plan`，其他版本、模型或模式
  不得仅凭名称推断支持。
- `safeguards` 必须在请求体改写与 CCH 生成后保留，`classifier_context` 的未知字段不得删除、
  重命名或自行补值。
- 命中时 `anthropic-beta` 必须使用对应 safeguard 子画像的完整精确顺序，不合并客户端额外
  token，也不动态加入 fallback token。
- 上游 SSE `message_delta.delta.safeguard_results` 必须按原始字节透传；工具关联位于
  `status.tool_uses` 对象的键中。网关不得解析、改写或本地生成分类结论。
- Sonnet 4.5 的 2.1.280 抓包未出现 `safeguards` / `safeguard_results`，继续使用普通主请求
  分支。普通 beta 的 API 默认画像包含 `message-threads-2026-08-12`，原生请求只在客户端
  显式携带时保留；同版本成功样本存在带与不带两种形态。

### 3. Tests Required

- `integrated_safeguards_use_exact_beta_and_survive_body_rewrite`：覆盖 Auto/Plan 两种
  `permission_mode`、两个 Opus 精确模型、请求体保留、额外客户端 beta 不混入。
- `sonnet_4_5_uses_observed_message_threads_beta_without_safeguards`：覆盖 Sonnet 普通分支。
- `stable_stream_preserves_safeguard_results_event`：覆盖流式分类结果的字节级透传。
- 完整验证运行 `cargo fmt --check`、`cargo test`、`cargo test cch`。

---

## Scenario: Auto Mode classifier 版本化协议

### 1. Scope / Trigger

- Trigger：修改 `GatewayService` 对 Claude Code Auto Mode classifier 的识别条件、本地拦截顺序、Legacy Block / Severity 协议选择或 mock response 时适用。
- 目标：兼容新旧 Claude Code classifier，同时避免被审计 transcript 中的 XML 示例污染协议选择。

### 2. Signatures

- 检测入口：`detect_auto_mode_classifier_request(path, body, client_type) -> Option<WarmupInterceptType>`。
- 协议入口：`auto_mode_classifier_protocol(body) -> Option<AutoModeClassifierProtocol>`。
- Stage 1：`max_tokens` 在 `64..=2304`；Stage 2：`max_tokens` 在 `4096..=8192`。
- 公共请求特征：Claude Code、非流 `/v1/messages`、最后一条消息为 `user`、最后一条消息包含闭合的 `<transcript>...</transcript>`。

### 3. Contracts

| 协议 | 可信输出格式 | `mock_allow` | `mock_block` |
|------|--------------|--------------|--------------|
| Legacy Block | system 或 transcript 外指令同时定义 `<block>yes</block>` 与 `<block>no</block>` | `<block>no</block>` | `<block>yes</block><reason>blocked by local policy</reason>` |
| Severity | system 或 transcript 外指令定义完整 `<severity>...</severity>` 格式 | `<severity>0</severity>` | `<severity>100</severity>` |

- 协议只能由 `system` 或最后一条 user message 中 transcript 外的 classifier 指令确定；被审计 transcript 内的标签属于不可信内容。
- 不依赖整句 prompt 精确匹配，可信区域只要求协议自身的完整输出标记，避免文案微调导致漏命中。
- 可信区域同时出现两套完整协议、协议标记不完整或 transcript 未闭合时，必须视为非强命中并透传上游。
- 本地 mock response 必须保持 Anthropic message JSON 形状，`cache_creation_input_tokens` 与 `cache_read_input_tokens` 均为 `0`，并在账号选择、RPM 和并发槽位获取前返回。

### 4. Validation & Error Matrix

| 条件 | 期望行为 |
|------|----------|
| Legacy Block system，transcript 内出现 Severity 示例 | 仍选择 Legacy Block |
| Severity system，transcript 内出现 Legacy Block 示例 | 仍选择 Severity |
| system 无协议，只有 transcript 内存在协议标签 | 不命中 classifier，透传上游 |
| transcript 后的可信指令定义单一协议 | 按该协议命中，不要求 system 精确文案 |
| 可信区域同时定义 Legacy Block 和 Severity | 不猜测协议，透传上游 |
| transcript 缺少开始或结束标签 | 不命中 classifier，透传上游 |

### 5. Good/Base/Bad Cases

- Good：旧版 Block classifier 的 transcript 正在讨论 `<severity>0</severity>`，仍返回 `<block>no</block>`。
- Good：新版 Severity classifier 的 transcript 包含旧版 block 示例，仍返回 `<severity>0</severity>`。
- Base：可信 system 或 transcript 后置指令只定义一套完整协议，按 Stage token 范围正常识别。
- Bad：扫描 `request_text_items(body)` 的全部文本并让 Severity 固定优先，会让用户内容改变本地安全响应协议。
- Bad：硬编码完整 system prompt 文案，会因 Claude Code 轻微改词而漏掉真实 classifier。

### 6. Tests Required

- `auto_mode_classifier_detects_severity_stage1` / `auto_mode_classifier_detects_severity_stage2`：新版协议仍覆盖两个 Stage。
- `auto_mode_classifier_detects_protocol_from_post_transcript_instruction`：system 无协议标记时，可信后置指令仍可命中。
- `auto_mode_classifier_uses_block_protocol_when_transcript_mentions_severity`：transcript 不覆盖旧版协议。
- `auto_mode_classifier_uses_severity_protocol_when_transcript_mentions_block`：transcript 不覆盖新版协议。
- `auto_mode_classifier_ignores_protocol_markers_only_inside_transcript`：普通用户内容不能制造 classifier 命中。
- `auto_mode_classifier_ignores_conflicting_trusted_protocol_markers`：可信区域冲突时失败开放。
- 完整验证运行 `cargo fmt --check`、`cargo test`、`cargo test cch`。

### 7. Wrong vs Correct

#### Wrong: 从全部请求文本猜测协议

```rust
for text in request_text_items(body) {
    has_severity |= text.contains("<severity>");
}
if has_severity {
    return Some(AutoModeClassifierProtocol::Severity);
}
```

transcript 是被审计的用户输入，里面的示例标签不能决定本地 mock response 格式。

#### Correct: 只读取可信 classifier 指令

```rust
for text in system_text_items(body) {
    observe_protocol_markers(text);
}
let last_message_content = body
    .get("messages")
    .and_then(|messages| messages.as_array())
    .and_then(|messages| messages.last())
    .and_then(|message| message.get("content"));
let mut inside_transcript = false;
for text in content_text_items(last_message_content) {
    let mut remaining = text;
    loop {
        if inside_transcript {
            let Some(close_index) = remaining.find("</transcript>") else {
                break;
            };
            inside_transcript = false;
            remaining = &remaining[close_index + "</transcript>".len()..];
            continue;
        }
        let Some(open_index) = remaining.find("<transcript>") else {
            observe_protocol_markers(remaining);
            break;
        };
        observe_protocol_markers(&remaining[..open_index]);
        inside_transcript = true;
        remaining = &remaining[open_index + "<transcript>".len()..];
    }
}
match (
    has_block_yes && has_block_no,
    has_severity_open && has_severity_close,
) {
    (true, false) => Some(AutoModeClassifierProtocol::Block),
    (false, true) => Some(AutoModeClassifierProtocol::Severity),
    _ => None,
}
```

协议冲突或证据不足时透传上游，既不误拦截，也不向客户端返回错误协议。

---

## Common Mistakes

| 反模式 | 现象 | 怎么改 |
|--------|------|--------|
| 只改版本常量 | 请求 UA、账号 env、telemetry 或 access policy 仍停旧版本 | 搜索旧版本号并逐处确认 |
| 只看 CCH 不看 `cc_version` | CCH 命中但 billing header 后缀不真实 | 对每条主请求复算 suffix |
| 重新序列化 body 再算 CCH | 字段顺序或转义变化导致 hash 偏移 | 在最终 body 字节上做 top-level 裁剪 |
| Fable beta 无条件注入 1M | 不允许 1M 的账号也带 `context-1m` | 让客户端/白名单决定 1M |
| 只迁移 allowed range | 老库仍读取旧 `claude_code_version_profile`，账号 env 被刷新回旧版本 | 旧默认 profile setting 和旧默认 allowed range 必须成对迁移 |
| 部署后只看容器 Up | 账号仍可能停旧 `canonical_env` | 查 DB 版本分布 |

---

## Scenario: Claude Fast Mode 账号级透传控制

### 1. Scope / Trigger

- Trigger: 新增或修改 `fast-mode-2026-02-01`、根级 `speed: "fast"`、账号级 Fast 放行开关、`/v1/messages` / `count_tokens` 正文与 beta 协调，或 bench 创建 cc2api 账号的同步契约。
- 本场景属于跨层契约：账号模型、SQLite/PostgreSQL schema、Store、管理 API、Accounts UI、协议重写和 bench 同步必须保持一致。
- Fast Mode 的产品语义是允许客户端显式申请；禁止时回落普通模式，允许时不替普通请求主动开启。公开 API 的新机制可仅依赖 `speed: "fast"`，不能只靠删除旧 beta 表达禁止。

### 2. Signatures

账号与数据库字段：

```text
Account.allow_fast_mode: bool
accounts.allow_fast_mode INTEGER NOT NULL DEFAULT 0
```

管理 API 字段：

```json
{
  "allow_fast_mode": false
}
```

协议 token 与入口：

```text
fast-mode-2026-02-01
POST /v1/messages
POST /v1/messages/count_tokens
```

关键代码入口：

```text
src/model/account.rs
src/store/db.rs
src/store/account_store.rs
src/handler/router.rs
src/service/rewriter.rs
src/service/gateway.rs
web/src/api.ts
web/src/components/Accounts.vue
orchestrator/main.py::sync_account_to_cc2api
```

### 3. Contracts

- `allow_fast_mode` 默认必须为 `false`：Rust serde 缺省、管理 API 创建缺省、SQLite/PostgreSQL 建表和旧库迁移、前端新建表单都必须一致。
- 当 `allow_fast_mode=false` 时，按逗号拆分并精确删除完整 token `fast-mode-2026-02-01`；同时稳定删除 JSON 根级字符串精确等于 `"fast"` 的 `speed`，按普通模式发送，不新增 Fast 请求拒绝或重试。不得使用子串替换，其他 beta token 保持原始相对顺序。
- 正文过滤使用共享 `Rewriter::filter_account_fast_mode_body(body: &Value, account: &Account) -> Option<Value>`；仅实际删除时复制并返回新对象，`standard`、大小写／空白异常值、其它类型、嵌套同名字段及其它根键的值与相对顺序不变。无删除时不因该策略重新序列化。
- 当 `allow_fast_mode=true` 时，不删除客户端的正文 Fast 申请，Fast beta 沿用入口已有合并规则；版本画像和网关不得主动注入 Fast token 或 `speed: "fast"`。账号放行不扩大 API、title、精确 safeguard 的 beta 合并边界，也不按正文自动补 beta。
- 精确 `/v1/messages` 的 API／原生 CC、流式／非流式、普通／identity-only／classifier attribution 转发在账号确定后统一执行正文策略；其它路径与本地 mock／缓存命中不增加转发。
- `/v1/messages/count_tokens` 复用同一正文与账号 beta 过滤策略；`count_tokens` 过滤后仍必须合并 `token-counting-2024-11-01`，不改变专用入口与方法检查。
- 每次换号都从公共原始逻辑请求派生本次账号正文，不能让前次禁止删除污染后续允许账号，也不能继承前次放行。401 认证恢复复用当前账号正文，签名修复保持已应用策略，不恢复 Fast 字段。
- `context-1m-2025-08-07` 继续由 `allow_1m_models` 控制，Fast Mode 改动不得扩大或收窄现有 1M 白名单。
- 要求精确 beta 画像、不会合并客户端 beta 的特殊请求保持现有 required beta，不因账号开关主动增删 Fast Mode。
- 过滤发生在最终上游 header 生成之前，header 与观测使用本次账号最终正文。实际删减后通过 `Rewriter::refresh_message_body_policy_cch` 刷新已有合法唯一根级 billing CCH，包含 Strip／身份旁路；复用既有定位和版本算法，不新增 billing／CCH、版本或画像。仅该字段删除与必要 CCH 刷新可突破旁路的原始字节保留合同。
- 请求继续按原 Content-Encoding 链在实际发送前重编码，Content-Length 依据最终 wire bytes；冻结编码链覆盖认证、签名与换号重试，不复用首包压缩体。
- bench 首次创建 cc2api 账号时，payload 必须显式发送 `"allow_fast_mode": false`，不能只依赖 cc2api 默认值。
- bench 匹配既有账号或已绑定账号时，只校验身份、绑定并同步 OAuth 凭据；不得调用账号配置更新接口覆盖 `allow_fast_mode`。该配置的唯一权威来源是 cc2api，bench 数据库不复制该字段。

### 4. Validation & Error Matrix

| 条件 | 期望 |
|------|------|
| 客户端携带 `speed: "fast"`，账号字段缺失或为 `false`，入站有／无 Fast beta | 最终根级 speed 与完整 Fast token 均不存在，回落普通模式 |
| 客户端携带 Fast Mode，账号字段为 `true` | 正文申请保留；沿用入口已有 beta 合并，支持透传入口只出现一次 |
| 客户端携带 `fast-mode-2026-02-01-extra` | 不得误删，精确匹配只删除完整 token |
| 客户端未携带 Fast Mode，账号字段为 `true` | 不主动注入 Fast Mode |
| Fast Mode 与 1M token 同时出现 | 两个策略分别判断，保留 token 的相对顺序和 1M 抓包顺序整理规则 |
| `standard`／异常值／嵌套 speed | 不误删；无删除时保留原正文 bytes 路径 |
| `count_tokens` 默认禁止 Fast Mode | 根级 `speed: "fast"` 与 Fast beta 被删除，`token-counting-2024-11-01` 仍存在 |
| identity-only／classifier attribution，独立根键清理开关关闭 | 账号 Fast 策略仍生效；实际删除时已有唯一 CCH 有效，不启用其它通用改写 |
| 禁止→允许／允许→禁止换号，或当前账号 401 恢复 | 每次发送匹配实际账号的策略，不污染公共原文；压缩长度及 CCH 与本次正文一致 |
| 旧数据库新增列 | 历史账号得到 `0`，升级后默认禁止 |
| bench 创建新 cc2api 账号 | create payload 明确包含 `allow_fast_mode=false` |
| bench 匹配既有 cc2api 账号 | 不创建账号、不更新账号配置，管理员原值保持不变 |

### 5. Good/Base/Bad Cases

**Good**：管理员为账号关闭 Fast，客户端只有 `speed: "fast"`、没有旧 beta 时，上游仍按普通模式发送；允许后正文申请保留，beta 继续遵守已有入口规则。

**Base**：新账号、旧库迁移账号和 bench 首次同步账号全部默认禁止，普通请求的其他 beta、CCH 和 `cc_version` 保持不变。

**Bad**：把 Fast Mode 加进版本画像 required beta，导致管理员只是允许透传却变成所有请求主动开启。

**Bad**：bench 每次同步都更新 `allow_fast_mode=false`，覆盖管理员在 cc2api 中的显式放行。

**Bad**：使用 `replace("fast-mode-2026-02-01", "")`，误伤前后缀相似 token 或留下无效分隔符。

### 6. Tests Required

- Rewriter：默认删除、显式允许、精确 token 匹配、未携带时不注入、与 `context-1m` 组合后其他客户端 token 顺序稳定。
- 正文策略：精确根级字符串、嵌套／异常值、稳定删除与公共输入保留；实际 Gateway 覆盖 280/293、API／CC、stream 三态、有／无 beta、身份及归因旁路和已有 CCH。
- 重试与编码：允许／禁止双向换号、Messages／count_tokens 401 恢复、两阶段 signature 修复；本地 TCP 验证明文与已有支持编码的唯一长度、Content-Encoding、最终 JSON 和 CCH，不声明真实账号推理或费用结论。
- Count tokens：默认删除与显式允许各一例，并断言 `token-counting-2024-11-01` 保留。
- Store/DB：新账号默认 `false`、旧 SQLite 行迁移后为 `0`、更新为 `true` 后读取和列表返回正确。
- 管理 API：创建 payload 缺省时响应为 `false`，PUT 更新为 `true` 后 GET/list 往返一致。
- 前端：`cd cc2api/web && npm run build`，并确认新建默认“禁止”、编辑回填和保存 payload 一致。
- bench：首次创建 payload 明确包含 `allow_fast_mode=false`；匹配既有账号和重复同步不调用创建或账号配置更新接口。
- 回归门禁：`cargo fmt --check`、`cargo test`、`cargo test cch`、orchestrator 单元测试。

### 7. Wrong vs Correct

#### Wrong: 账号允许后主动注入 Fast Mode

```rust
if account.allow_fast_mode {
    required_beta.push_str(",fast-mode-2026-02-01");
}
```

#### Correct: 只过滤或保留客户端已有 token

```rust
let filtered = if account.allow_fast_mode {
    incoming_beta.to_string()
} else {
    strip_beta_token(incoming_beta, "fast-mode-2026-02-01")
};
```

#### Wrong: bench 同步既有账号时重置管理员配置

```python
cc2api_client.update_account(account_id, {"allow_fast_mode": False})
```

#### Correct: 只在首次创建时显式关闭

```python
cc2api_client.create_account({
    "email": profile["email"],
    "allow_fast_mode": False,
})
```

---

## Scenario: Claude Code currentDate 风险治理

### 1. Scope / Trigger

- Trigger: Claude Code 在非官方 `ANTHROPIC_BASE_URL`、代理、网关或中国时区画像下改变自动上下文中的 currentDate 标记。
- 该场景属于跨层契约：`/v1/messages` body 改写、settings、管理 API、前端设置页、telemetry 清洗和日志策略必须一致。
- 默认行为必须低风险：只观测和 telemetry 清洗；只有管理员显式选择 `normalize` 时才改写请求体。

### 2. Signatures

关键代码入口：

```text
src/service/rewriter.rs
src/service/gateway.rs
src/service/telemetry.rs
src/handler/router.rs
src/store/settings_store.rs
src/store/db.rs
web/src/components/Settings.vue
```

关键 setting：

```text
settings.claude_code_context_sanitizer_mode = off | report_only | normalize
```

### 3. Contracts

请求体治理契约：

- 仅对 `ClientType::ClaudeCode` 的 `/v1/messages` 改写链路生效；普通 API 客户端不触发。
- 只扫描 Claude Code 自动上下文位置：`system` text、`system[] .text`、带上下文 marker 的 `messages[].content` text、多 text block 中首个上下文 block。
- `report_only` 只记录脱敏摘要，不修改 body；`normalize` 才把命中句式统一为 `Today's date is YYYY-MM-DD.`。
- 规范化必须发生在最终 CCH / `cc_version` 刷新前，避免 hash 和 billing header 基于旧文本计算。
- 支持日期分隔符 `-` 和 `/`，但同一句中年月、月日分隔符必须一致。

currentDate 撇号契约：

```text
Today['\u{2019}\u{02BC}\u{02B9}\u{2032}]s date is YYYY[-/]MM[-/]DD.
```

已知变体：

| 字符 | 码点 | 日志类别 |
|------|------|----------|
| `'` | U+0027 | `ascii` |
| `’` | U+2019 | `right_single_quote` |
| `ʼ` | U+02BC | `modifier_letter_apostrophe` |
| `ʹ` | U+02B9 | `modifier_letter_prime` |
| `′` | U+2032 | `prime` |

日志和 telemetry 契约：

- currentDate finding 日志只能包含 `mode`、`action`、`path`、`date_separator`、`apostrophe_variant`、`text_len`、短 hash、`client_type`，禁止输出完整 prompt、system 或 request body。
- telemetry sanitizer 必须清洗非官方 `base_url` / `gateway` / `proxy` key/value 痕迹。
- 官方 Anthropic host 值允许保留：`anthropic.com`、`api.anthropic.com`、`claude.ai`、`console.anthropic.com` 及其子域。

### 4. Validation & Error Matrix

| 条件 | 期望 |
|------|------|
| `claude_code_context_sanitizer_mode` 是未知值 | `/admin/settings` PUT 返回 BadRequest，不刷新热路径 |
| mode=`off` | 不扫描、不打 finding 日志、不改写 body |
| mode=`report_only` 且命中 currentDate | 输出脱敏 warning，body 字节语义不变 |
| mode=`normalize` 且命中 `Todayʹs date is 2026/06/30.` | 改为 `Today's date is 2026-06-30.` |
| 非 Claude Code 客户端发送同样文本 | 不触发扫描或规范化 |
| 普通用户正文单 text block 包含 `Today's date is ...` | 不改写，避免误伤真实用户内容 |
| telemetry 中出现 `gatewayHost=https://internal.example` | 删除该字段 |
| telemetry 中出现 `baseUrl=https://api.anthropic.com` | 保留该字段 |

### 5. Good/Base/Bad Cases

**Good**：默认 `report_only` 上线，先通过脱敏日志确认 `date_separator` 和 `apostrophe_variant` 分布，再由管理员显式打开 `normalize`。

**Base**：中国时区下出现 `2026/06/30` 时，只在 `normalize` 模式改为 `2026-06-30`。

**Bad**：把所有用户消息中的 `Today's date is` 都替换，导致真实用户内容被静默修改。

**Bad**：只覆盖 `′` U+2032，漏掉 Claude Code 实际可能使用的 `ʹ` U+02B9。

**Bad**：在日志里输出完整 system prompt 或 request body，泄露工作目录、环境、token 或用户正文。

### 6. Tests Required

- `cargo fmt --check`
- `cargo test context_sanitizer`
- `cargo test telemetry_sanitizer`
- `cargo test`
- 涉及设置页时运行 `cd cc2api/web && npm run build`
- 断言点：
  - 默认 settings 返回 `report_only`。
  - `report_only` 不修改 body。
  - `normalize` 覆盖 `'`、`’`、`ʼ`、`ʹ`、`′` 与 `YYYY/MM/DD`。
  - 规范化后 CCH 占位符被最终刷新。
  - API 客户端和普通用户正文不被误改。
  - telemetry 清洗非官方 base URL / gateway / proxy，同时保留官方 Anthropic host。

### 7. Wrong vs Correct

#### Wrong: 只匹配 ASCII 撇号

```text
Today's date is 2026/06/30.
```

这样会漏掉 `Todayʹs date is ...`，其中 `ʹ` 是 U+02B9，不是 U+2032。

#### Correct: 明确列出已知 Unicode 变体

```text
Today['\u{2019}\u{02BC}\u{02B9}\u{2032}]s date is YYYY[-/]MM[-/]DD.
```

#### Wrong: report_only 中改写请求体

```text
mode=report_only, action=normalize
```

#### Correct: report_only 只输出脱敏摘要

```text
mode=report_only, action=report_only, apostrophe_variant=modifier_letter_prime, date_separator=/
```

---

## Scenario: Claude Code 版本画像切换

### 1. Scope / Trigger

- Trigger: 新增或修改 `claude_code_version_profile` 可选版本，或让系统设置切换 Claude Code 版本特征。
- 本场景属于跨层契约：settings、账号 `canonical_env`、访问策略、请求重写、telemetry、前端 Settings 必须一起更新。
- 版本画像切换必须只允许内置 profile key，不能接受任意版本字符串拼装请求特征。

### 2. Signatures

关键代码入口：

```text
src/service/version_profile.rs
src/store/settings_store.rs
src/store/account_store.rs
src/service/account.rs
src/handler/router.rs
src/service/rewriter.rs
src/service/telemetry.rs
web/src/api.ts
web/src/components/Settings.vue
```

关键 setting：

```text
claude_code_version_profile=<profile key>
allowed_claude_code_versions=<客户端模式独立准入范围；账号模式为目标画像范围>
allowed_user_agents=<管理员自定义值，版本切换不得覆盖>
```

账号身份字段：

```json
{
  "version": "<profile.identity.version>",
  "version_base": "<profile.identity.version_base>",
  "build_time": "<profile.identity.build_time>",
  "node_version": "<profile.identity.stainless_runtime_version>"
}
```

### 3. Contracts

- `src/service/version_profile.rs` 是唯一版本画像注册表。新增版本必须声明 `identity`、`access_policy`、`request`、`billing`、`telemetry`、`endpoints` 及可选 `tls_profile` 绑定；TLS 未采样时留空并按下方默认规则兼容，不宣称已验证。
- `claude_code_version_profile` 保存时必须校验为内置 profile key；未知 key 返回 `BadRequest`，不能落库。
- 切换 profile 必须在同一事务中完成：
  - 写入 `settings.claude_code_version_profile`。
  - 客户端模式保存显式提交的 `allowed_claude_code_versions`；profile-only payload 保留存量范围。账号模式覆盖为目标画像范围。
  - 批量覆盖所有账号 `canonical_env.version/version_base/build_time/node_version`。
- 本次提交的其它 settings 也必须在同一事务中提交；任一写入失败，settings 与账号软件字段整体回滚。
- 切换 profile 不得覆盖 `allowed_user_agents`，该 setting 仍由管理员独立维护。
- 新账号创建必须读取当前 `claude_code_version_profile`，再把目标 `identity` 写入 `canonical_env`。
- 客户端模式下，请求入口冻结原始 UA 对应的内置画像或配置的默认画像，使用请求级账号副本完成重写和 telemetry；账号模式沿用账号 `canonical_env.version`。映射失败只能回退内置画像，不能拼出未验证特征，具体规则见下方「按客户端 UA 选择请求画像」。
- 只提交 `claude_code_version_profile` 的 settings payload 时，也必须调用 `reload_access_profile_config` 原子刷新准入与画像选择；未匹配 UA 的默认画像需要立即生效，账号模式还会同步改写允许范围。
- 前端 Settings 保存成功后必须重新加载 settings，回显实际落库值；客户端模式的版本范围可编辑，账号模式只读。

### 4. Validation & Error Matrix

| 条件 | 期望 |
|------|------|
| settings 提交未知 `claude_code_version_profile` | 返回 `BadRequest`，不更新 settings 和账号 env |
| 客户端模式只提交 `claude_code_version_profile` | 保留存量允许范围，原子 reload 准入与画像选择 |
| 账号模式提交 `claude_code_version_profile` | 同步目标画像允许范围，原子 reload 准入与画像选择 |
| 切换 profile 时存在自定义 `allowed_user_agents` | 原值保持不变 |
| 切换 profile 后已有账号仍保留旧 `canonical_env.version` | 视为失败，检查事务内账号批量更新 |
| 账号 env.version 不是内置版本 | 热路径回退默认 profile，避免组合未验证请求/telemetry 特征 |
| 新增 profile 只填版本号 | 视为不完整，必须补齐 request/billing/telemetry/endpoints 子画像和测试 |

### 5. Good/Base/Bad Cases

**Good**：新增 `2.1.xxx` 时先把抓包差异整理成 profile 子画像，补 settings 切换测试、账号 env 批量更新测试、rewriter/telemetry shape 测试，再开放前端选项。

**Base**：两个版本暂时共享 request/billing 子画像，也要在 profile 中显式声明共享字段，便于后续版本局部拆分。

**Bad**：在 `telemetry.rs` 或 `rewriter.rs` 里散落 `if version == "2.1.xxx"`，导致新增版本需要多处猜测。

**Bad**：允许管理员输入任意版本号，并用该字符串直接生成 UA、billing header 或 telemetry payload。

### 6. Tests Required

- profile registry：
  - profile key 唯一。
  - 默认 profile 存在。
  - 每个 profile 的 identity、access policy、telemetry UA、endpoint 字段非空。
- settings：
  - 未知 `claude_code_version_profile` 返回错误。
  - 切换 profile 后 settings 与所有账号 env 在同一事务结果中一致。
  - 客户端模式的显式范围与 profile-only 存量范围保留；账号模式使用目标画像范围。两种模式均保留未提交的 `allowed_user_agents`。
  - settings 任一写入失败时，配置与账号软件字段整体回滚；SQLite/PostgreSQL 都需覆盖。
  - profile-only payload 触发 access policy reload 的可观察行为。
- account：
  - 新账号使用当前 profile 的 `identity`。
- protocol：
  - rewriter 按请求级账号副本的 env.version 选择 UA、beta、billing/CCH 子画像；账号模式沿用持久账号。
  - telemetry 按 profile shape 切换 event logging 和 GrowthBook payload。

### 7. Wrong vs Correct

#### Wrong: 任意版本字符串直通

```rust
settings.insert("claude_code_version_profile".into(), user_input_version);
```

这会让请求和 telemetry 进入没有抓包验证的组合状态。

#### Correct: 只能选择内置画像

```rust
let profile = profile_for_key(&user_input_version)?;
settings.insert("claude_code_version_profile".into(), profile.key.to_string());
```

随后由 `upsert_many_with_profile(&settings, Some(profile))` 在同一事务内按生效模式处理允许范围与账号软件字段。

#### Wrong: 切版本时顺手覆盖 UA 白名单

```rust
settings.insert("allowed_user_agents".into(), profile_default_user_agents);
```

这样会覆盖管理员的独立安全策略。

#### Correct: 不顺带写入 UA 白名单

```rust
settings.insert(
    "claude_code_version_profile".into(),
    profile.key.to_string(),
);
```

---

## Scenario: 按客户端 UA 选择请求画像

### 1. Scope / Trigger

- Trigger：修改请求版本选择、默认回退、配置热刷新，或同账号多版本遥测与缓存时适用。
- 客户端模式精确适配 `2.1.260`、`2.1.280`、`2.1.293`；出厂默认画像为 293。版本匹配仅依赖原始 Claude UA。请求体版本字段不参与选择，新增版本必须先补齐抓包证据和内置画像。
- 画像表示软件协议特征，账号设备身份、凭证和总容量仍由同一持久账号承载，防止两版交错请求互相覆盖或扩大容量。

### 2. Signatures

```text
GET /admin/settings -> JSON 字符串映射
PUT /admin/settings <- JSON 字符串映射
ClaudeCodeProfileSelectionMode::parse(value: &str) -> Result<Self, AppError>
ClaudeCodeProfileSelectionConfig::resolve(self, user_agent: &str) -> Option<&'static ClaudeCodeProfile>
account_for_request_profile(account: &Account, profile: Option<&'static ClaudeCodeProfile>) -> Account
GatewayService::reload_access_profile_config(&self) -> Result<(), AppError>  // async
GatewayService::reload_profile_selection_config(&self) -> Result<(), AppError>  // async
TelemetryService::get_session_expires_at(&self, account_id: i64) -> Option<DateTime<Utc>>  // async
```

配置字段的类型均为字符串：

```json
{
  "claude_code_profile_selection_mode": "client_version",
  "claude_code_version_profile": "2.1.293"
}
```

### 3. Contracts

- `claude_code_profile_selection_mode` 仅接受精确值 `client_version` 或 `account`，默认前者；不 trim、不接受空白变体。GET 补齐默认值，PUT 在任何写入前校验。无需新增环境变量。
- 客户端模式只识别以 `claude-code/` 或 `claude-cli/` 开头的原始 UA，前缀不区分大小写；取斜杠后第一个空白分隔 token，只有精确 `2.1.260`、`2.1.280`、`2.1.293` 自动匹配。
- 缺少 UA、非法 UA、Bun/axios 等辅助 UA，以及未匹配版本，均使用 `claude_code_version_profile` 指定的内置默认画像，出厂为 `2.1.293`。不得按邻近版本、请求体 `appVersion` 或其它字段推断。
- 准入策略先检查原始 UA，再于读取 body 和账号重试前冻结画像。默认回退不绕过 `allowed_user_agents`、`allowed_claude_code_versions`；准入拒绝的请求仍被拒绝。
- `account` 模式的 `resolve` 返回 `None`，沿用最终选中账号的持久 env 和旧选择规则；换号后使用新账号原有画像。客户端模式冻结的 `Some(profile)` 在 401、签名重试、换号和配置热刷新期间保持一致。
- 每次选定账号后调用 `account_for_request_profile` 生成副本，只覆盖 `version/version_base/build_time/node_version` 软件字段。旧账号 env 无法反序列化时，先使用既有 `device_profile` 归一化已知字段并保留未知字段，再覆盖软件版本；副本不得写回存储。
- 原账号用于调度、sticky、RPM/并发 admission、凭证和上游 Session 池；副本用于 headers/body、模型/beta、billing/CCH、count_tokens、bootstrap、内部 Hello、原生及自动遥测。公开 `GET/HEAD /api/hello` 继续保持无状态，不选择账号。
- 启动和 mode/default/允许范围/禁止版本/允许 UA 保存后，通过 `reload_access_profile_config` 从同一次 `get_all` 读取准入与选择配置，并在 `AccessProfileConfig` 的一把 `RwLock` 中原子替换。写锁覆盖读取和替换，防止并发 reload 的旧读取覆盖新快照；policy 解析失败保留旧快照。请求在同一读锁内先准入、再冻结画像。
- 非法存量 mode 回退 `client_version`，非法存量默认 key 回退 `2.1.293`；已冻结的客户端画像不受后续 reload 影响。旧 reload 方法委托给组合刷新。
- 数据库仅补齐缺失的 mode key：SQLite 使用 `INSERT OR IGNORE`，PostgreSQL 使用 `ON CONFLICT (key) DO NOTHING`，保留显式值。只切 mode 不写账号 env；保存默认 profile 执行上方全局事务，允许范围按模式处理。出厂组合升级边界见 [Settings & Database](../backend/settings-database.md#迁移规则)。
- 自动遥测以 `(account_id, profile_key)` 分容器，创建时固定账号副本；续期仅更新 token 和 10 分钟 TTL，不重读账号替换软件画像。请求结果和流结束回调携带同一副本，payload 与 UA 从同一容器生成。
- run/GrowthBook 运行 ID 的种子包含 profile key，同秒两版也不相同；device ID 和账号 UUID 继续共享。管理端过期时间取该账号各画像容器的最大值，发送计数仍按账号累计；容器过期只清理自身 key。

版本相关缓存必须使用以下维度；延迟提交沿用请求阶段已经捕获的 key：

| 状态 | key 契约 |
|------|----------|
| Stateful blocks | `<account_id>:<profile_key>:<real_session_id>`，保留真实下游 Session，不改成上游池 Session |
| Hello 状态和 singleflight | `session_hello_probe:v3:<account_id>:<profile_key>:<tls_profile_id>:<sha256(upstream_session_id)>:<sha256(proxy_url)>` |
| 非流式探针 | 既有 JSON key 增加 `profile` 字段，即使两版 headers/body 相同也隔离 |

sticky、RPM、并发与上游 Session 池容量不得因 profile 增加独立配额。

### 4. Validation & Error Matrix

以下选择行为以请求通过原始 UA 准入检查为前提：

| 条件 | 期望 |
|------|------|
| `claude-code/2.1.260 (external, cli)` 或大小写变体 | 使用 260；body 声明 280 也不覆盖 |
| `claude-cli/2.1.280` | 使用 280 |
| `claude-cli/2.1.293` | 使用 293 |
| 缺少 UA，body 声明 260 | 使用配置默认画像，出厂 293 |
| Bun/axios、`2.1.294`、`2.1.2600`、`2.1.260-beta` | 使用配置默认画像，不自动适配新版本 |
| 默认画像改为内置 260，UA 未匹配 | 新请求使用 260；原有已冻结请求继续原画像 |
| PUT mode 为 `invalid`、` account ` 或非字符串 | 参数错误；校验失败不得更新 settings 或账号 env |
| PUT profile 为未知内置 key | `BadRequest`，不落库 |
| 账号模式，持久账号为 280，UA 为 260 | 继续账号 280；切回客户端模式后新请求使用 260 |
| 原始 UA 被访问策略拒绝 | 按既有准入错误返回，不因默认回退放行 |

### 5. Scenarios and Examples

**正常场景**：同一账号接收交错或并发的 260/280/293 请求，每次上游 headers、body 和 CCH 都使用对应画像；持久设备身份和账号容量共享。既有遥测容器隔离契约继续适用，本轮不扩展遥测。

**边界场景**：无 Claude 版本 UA 的 GrowthBook/event logging 请求使用配置默认画像；body 中版本字段仍按所选画像重写，不能充当选择依据。

Gateway 在读取 body 和开始账号循环前固定选择，在最终账号选出后生成副本：

```rust
let request_profile = {
    let snapshot = self.access_profile_config.read().await;
    if let Err(rejection) = snapshot.policy.check_user_agent(&ua) {
        return Ok(access_policy_error_response(&rejection));
    }
    snapshot.selection.resolve(&ua)
};
// 每次选定最终账号后，协议改写使用副本；调度和存储继续使用原账号。
let request_account = account_for_request_profile(&account, request_profile);
```

**错误用法**：用请求体 `attributes.appVersion` 选择画像，或将请求副本写回账号表；前者破坏 UA 唯一来源，后者导致交错请求污染持久身份。

**正确处理**：入口仅从原始 UA 冻结选择；所有异步发送、重试与缓存提交使用该选择对应的副本和 key，始终保留原账号供容量与存储操作使用。

### 6. Tests Required

- Resolver：前缀大小写、260/280/293 精确 token、缺失/非法/未匹配 UA、非默认回退、body 不参与选择、账号模式与非法 mode。
- Settings/迁移：缺失 key 补齐、显式 `account` 保留、非法参数写入前失败、GET 字符串默认、mode/default 热刷新；两种数据库插入语法保持兼容。
- Gateway mock：同账号交错与并发的各版本 headers/body/billing/CCH 一致，持久身份未变；401 期间 reload、签名重试、换号保持客户端画像；覆盖 count_tokens、bootstrap 和辅助遥测准入。
- Telemetry/identity：同秒运行 ID 隔离、设备身份共享、交错续期不覆盖画像、延迟结果正确归属、UA/payload 一致、单容器 TTL 清理与账号过期时间/计数聚合。
- 缓存：同账号同真实 Session 的两版 stateful 状态隔离，反序延迟提交不串版；同上游 Session 两版 Hello 各探一次；非流式探针在相同 headers/body 时仍分 key。
- 保留旧版本 fixture、CCH 和未知字段/SSE 行为回归；执行 `cargo fmt --check`、`cargo test`、`cargo test cch`，设置页变更还需 `npm run build`。

---

## Scenario: Claude Code 2.1.293 画像与 280/293 准入预设

### 1. Scope / Trigger

- 修改 293 软件身份、精确模型、标题、beta、线程/CCH、后台端点、默认配置或管理页时适用；旧画像必须保持独立，不能因切换默认画像而改变 280 wire。
- 证据来自正式抓包任务的 25 轮、四模型六权限模式，112 条 billing 的 CCH/后缀全部独立复查命中。矩阵固定 xhigh；其它 effort 以及同时带 safeguard 与 fallback 的组合不计入真实采集覆盖。合成测试不能替代抓包。
- 原始正文只留受限远端；仓库 fixture 使用合成文本和身份，保留协议形状、顺序及独立期望值。遥测扩展与自动部署不属于本次升级。

### 2. Signatures

```text
GET /admin/settings -> JSON 字符串映射
PUT /admin/settings <- JSON 字符串映射
SettingsStore::upsert_many_with_profile(
    &self,
    items: &HashMap<String, String>,
    profile: Option<&'static ClaudeCodeProfile>,
) -> Result<(), AppError>  // async
GatewayService::reload_access_profile_config(&self) -> Result<(), AppError>  // async
is_structured_haiku_title_request_for_profile(
    body: &serde_json::Value,
    request_profile: &RequestProfile,
) -> bool
upgrade_default_profile_setting(pool: &AnyPool, driver: &str) -> Result<(), sqlx::Error>  // async
use280293AccessPreset(): void
```

请求相关结构分别由 `ClaudeCodeProfile.request/billing/endpoints` 声明；293 使用 `HaikuTitleProfile::ClaudeCode21293`、`MessageBodyOrderProfile::ClaudeCode21293`、`EndpointHeaderProfile::ClaudeCode21293` 与 `CchProfile::ClaudeCodeAllModelValues`，不新增自由输入版本或环境变量。

### 3. Contracts

**身份与模型**

| 字段 | 293 值 |
| --- | --- |
| version / version_base / 默认 profile key | `2.1.293` |
| build_time | `2026-10-07T06:36:42Z` |
| Stainless SDK / Node / timeout | `0.128.0` / `v26.3.0` / `600` |
| Hello UA | `Bun/1.4.3` |
| 出厂允许范围 / 禁止版本 | `2.1.89-2.1.293` / 空字符串 |

257/260/280 的 SDK 固定为 `0.112.1`，不能引用已经切换为 293 的全局默认 SDK。260/280 的 registry、精确 UA 映射、页面选项与旧模型处理继续保留。

| 精确主模型 ID | 默认 max_tokens / 293 API 上限 | thinking | 默认 effort | bootstrap cwk |
| --- | --- | --- | --- | --- |
| `claude-opus-5-5` | 128000 | adaptive，display=updates | xhigh | saffron |
| `claude-sonnet-5-5` | 128000 | adaptive，display=updates | xhigh | cardamom |
| `claude-haiku-5-5` | 128000 | adaptive，display=updates | xhigh | lovage |
| `claude-fable-5-1` | 64000 | adaptive，display=updates | xhigh | sorrel |

只对这些精确 ID 使用新表；其它模型和旧画像沿用已有行为，旧画像 API 的 64000 上限保持原契约。已有显式 effort 选择规则保留，不能宣称所有档位都已抓包。Fable 的 CLI `[1m]` 后缀不证明 wire 存在 context-1m 或 fallback，本矩阵没有观察到这两项；不自动补入。bootstrap 的 `client_data.cedar_basin=2027-08-31`，未涉及的上游字段保留。

**Beta 与标题**

Opus/Sonnet/Fable 普通主请求的基线按如下顺序维护，不包含自动启用的 context-1m：

```text
claude-code-20250219,oauth-2025-04-20,interleaved-thinking-2025-05-14,thinking-token-count-2026-05-13,context-management-2025-06-27,prompt-caching-scope-2026-01-05,mid-conversation-system-2026-04-07,per-turn-control-2026-07-01,mid-conversation-tool-changes-2026-07-01,inline-tools-2026-09-15,advisor-tool-2026-03-01,advanced-tool-use-2025-11-20,mid-conversation-system-clear-at-2026-08-21,effort-2025-11-24,thinking-binding-controls-2026-08-01,thinking-display-updates-2026-08-18,extended-cache-ttl-2025-04-11,cache-diagnosis-2026-04-07,message-threads-2026-08-12
```

- Haiku 5.5 普通主请求从 oauth 开始，`claude-code-20250219` 位于 mid-conversation-system 后、per-turn-control 前，其余顺序与基线一致。原生客户端的 claude-code 与 extended-cache-ttl 两个 token 按入站是否携带决定，不依据权限模式、diagnostics 或 thread 猜测；293 API 缺少该客户端选择信息时使用完整基线。
- 四模型 Auto/Plan 已观察 safeguards：dangerous-tool-use 插在 effort 后，afk-mode 插在 thinking-display-updates 后、extended-cache-ttl 前。使用精确 safeguard 表，不能合并任意未知 beta；已验证的客户端可选 token 按原位置保留。
- Opus 原生 context-1m 需要客户端已携带 token 且账号允许 1M；位置在 oauth 后。不得从账户权限单独推断启用。
- 已观察 Opus 普通 `fallbacks="default"`：server-side-fallback、fallback-credit 依次位于 effort 后、thinking-binding-controls 前；保留 fallback 参与 CCH。不得据此自动生成其它模型的默认 fallback 或声称 safeguard+fallback 组合已采集。
- 293 标题必须为精确 `claude-haiku-5-5`、stream=true、tools 为空或缺省、max_tokens=128000、thinking 字段缺省，且 `output_config.format` 的 schema 仅要求 title。不得用旧 32000 token 标题判定把它归到主请求。
- 标题的精确 beta 顺序如下；旧 Haiku 4.5 自动单 token 探测仍使用原有窄表，不属于新主模型升级。

```text
oauth-2025-04-20,interleaved-thinking-2025-05-14,redact-thinking-2026-02-12,thinking-token-count-2026-05-13,context-management-2025-06-27,prompt-caching-scope-2026-01-05,mid-conversation-system-2026-04-07,per-turn-control-2026-07-01,mid-conversation-tool-changes-2026-07-01,inline-tools-2026-09-15,advisor-tool-2026-03-01,mid-conversation-system-clear-at-2026-08-21,effort-2025-11-24,structured-outputs-2025-12-15,cache-diagnosis-2026-04-07
```

**字节与会话**

293 顶层已知字段顺序为 `model,messages,system,tools,metadata,max_tokens,thinking,context_management,fallbacks,safeguards,output_config,thread,diagnostics,stream`；缺省字段不因排序而插入，未知字段保持相对顺序，SSE 与 safeguard_results 保持字节透传。

CCH 使用 `0x4D659218E32A3268`：在最终序列化字节上将唯一受管理根级 system billing 的 CCH 替为占位值、删除顶层 max_tokens、清空全层级精确字符串 model 值，保留 fallback，再取 xxhash64 低 20 bits。禁止 JSON 往返重排。初始后缀仍以 salt `59cf53e54c78`、首条 user 的最后一个 text block、UTF-16 code units `[4,7,20]` 与版本计算 SHA256 前三位；缺失索引按既有 `0` 规则，孤立代理项按既有替换字符语义处理。续轮使用当前入站 billing 后缀；审计通过 previous_message_id 对应前一 SSE message_start.id 逐链检查，同 run/model 不构成唯一会话键，也不新增全局后缀缓存。 CCH 原始 JSON 字符串中的目标偏移必须单次扫描映射，不能为每个同名示例重复解析完整前缀；转义边界无法安全映射时失败开放并保留原字节。

**后台端点**

以下为本轮已观察的精确分支；其它路径不得按 293 版本号套用旧版后台端点分类。

| 端点 | 方法 | UA | beta | Content-Type | anthropic-version |
| --- | --- | --- | --- | --- | --- |
| `/api/hello` | HEAD | Bun/1.4.3 | 无 | 无 | 无 |
| `/api/eval/*` | POST | claude-code/2.1.293 | oauth-2025-04-20 | application/json | 无 |
| `/api/claude_code_grove` | GET | claude-cli/2.1.293 (external, cli) | oauth-2025-04-20 | 无 | 无 |
| `/api/claude_code_penguin_mode` | GET | claude-code/2.1.293 | oauth-2025-04-20 | 无 | 无 |
| `/api/claude_cli/bootstrap` | GET | claude-code/2.1.293 | oauth-2025-04-20 | application/json | 无 |
| `/v1/mcp_servers` | GET | claude-code/2.1.293 | mcp-servers-2025-12-04 | application/json | 2023-06-01 |

Hello/eval 的 Accept 为 `*/*`、Accept-Encoding 为 `gzip, deflate, br, zstd`；其余四项为 `application/json, text/plain, */*` 与 `gzip, compress, deflate, br`。MCP capability 沿用280常量，协议版本为 `2025-11-25`。280 的 eval Bun 与 penguin/MCP Axios 身份保持原样。

**配置与管理页面**

预设 `use280293AccessPreset` 只填入以下四个表单字段，保存后才生效；不得顺带改 UA、遥测开关或删除260选项：

```json
{
  "claude_code_profile_selection_mode": "client_version",
  "claude_code_version_profile": "2.1.293",
  "allowed_claude_code_versions": "2.1.89-2.1.293",
  "blocked_claude_code_versions": "2.1.89-2.1.279,2.1.281-2.1.292"
}
```

禁止规则优先于允许范围，准入通过后才选择画像。默认回退无法放行被禁版本。客户端模式允许范围独立保存；账号模式使用目标画像范围并只读回显。主动保存画像仍在同一事务中更新全部账号四项软件字段；启动迁移仅处理客户端模式的精确旧出厂组合，账号模式和自定义策略保留，详见 [Settings & Database](../backend/settings-database.md)。账号页基础版本来自持久环境，模式/默认回退来自实际配置，显示「准入通过后」，不得当成最近请求画像。

### 4. Validation & Error Matrix

| 条件 | 期望 |
| --- | --- |
| 目标预设保存后 UA 为 280 / 293 | 分别放行并选择对应画像 |
| 目标预设下 UA 为 260、279、281、292、294 | 准入拒绝；260底层画像仍存在 |
| 缺失或未匹配 UA | 先遵守原有准入，通过后回退配置默认293 |
| 客户端模式 profile-only 从293切280 | 保存默认280，存量允许/禁止/其它UA不变 |
| 账号模式的旧出厂260/280组合启动 | 不自动迁移为293 |
| 客户端模式画像或范围之一已自定义 | 保留显式组合，不新增260专用迁移 |
| PUT非法mode/profile/准入语法 | 写入前失败，账号与配置不变 |
| 事务内任意setting写入失败 | 已写settings与账号软件字段整体回滚 |
| Haiku标题出现thinking字段或主请求结构 | 不命中新标题分类；不得丢失thinking |
| 同一run两条Haiku Plan会话交错 | 按各自previous_message_id与入站billing继承后缀 |

### 5. Scenarios and Examples

**正常**：点击「仅允许 280、293（默认 293）」只改变表单，保存并刷新后四项值一致、其它UA不变；同一账号并发280/293请求使用各自SDK/beta/CCH，持久设备身份与总容量共享。

**边界**：客户端模式管理员只修改默认画像为280，准入范围仍可包含293；原始293 UA仍选293，准入通过的无版本请求才使用280。账号模式则继续使用最终选中账号画像。

**错误**：为达到两版本准入删除260注册，或在启动时无条件填入禁止区间。**修正**：保留画像能力，由管理员显式保存目标允许/禁止配置，保护原有自定义策略与账号模式。

**错误**：按run/model缓存一个后缀，或把Haiku可选beta是否存在归因于权限模式。**修正**：线程按响应身份逐链核对，网关复用每条入站billing后缀；可选beta依据原始客户端头并保持表内位置。

### 6. Tests Required

- `version_profile.rs`：精确260/280/293 UA、未知版本/缺失UA默认293、显式回退与账号模式、注册表与身份完整性、旧SDK固定。
- `rewriter.rs`：`native_293_headers_match_every_observed_variant`、`cch_293_fixture_matches_independent_bytes_and_interleaved_suffixes`、`auxiliary_293_header_sets_match_captured_endpoints_and_keep_280_identity`、`safeguard_293_context_beta_requires_incoming_token_and_account_permission`、`api_293_model_limits_title_and_order_follow_capture`。
- `tests/fixtures/claude-code-2.1.293-profile.json`：11组独立字节/UTF-16/交错后缀、22种原生beta形状、6个后台端点；只含合成正文和身份。
- `tests/version_profile_settings_test.rs`：SQLite和显式本地PostgreSQL的事务回滚、四软件字段与未知字段保留、profile-only准入保留、目标预设、客户端出厂迁移、自定义与账号模式260/280保护、迁移幂等。
- `gateway.rs`：三版本交错/并发、401/签名重试保持冻结画像、同快照先准入后选择、目标规则放行280/293并拒绝边界版本、count_tokens/bootstrap、共享身份/容量与现有版本缓存隔离。
- 管理页本地实际验证：预设不自动保存、保存/刷新回显、其它UA保留、260选项保留、账号模式范围只读、账号页基础版本及默认回退来自真实配置。
- 执行 `cargo fmt --check`、`cargo test`、`cargo test cch`、`npm run build`；PostgreSQL场景以临时本地库显式运行 `postgres_profile_settings_and_rollback`，默认忽略不等于已验证。

## Scenario: Messages 保留调用方流式选择

### 1. Scope / Trigger

- Trigger：修改 `/v1/messages` 的 API mimicry、原生 CC 正文改写或最终响应转发时适用。
- 同一请求的流式选择必须贯穿最终上游正文，不能因软件画像而把非流请求强制变成 SSE。

### 2. Signatures

- 入口：`POST /v1/messages`，JSON 顶层 `stream` 为可选布尔值。
- `detect_client_type` 按原始 UA 的 `claude-cli/`／`claude-code/` 前缀识别 CC，其余为 API；使用 cc2api APIKey 不决定客户端类型。
- 正文改写位于 `Rewriter`；响应由 `GatewayService` 转发实际上游协议，不新增聚合器、设置项或数据库字段。

### 3. Contracts

- API 与 CC 均保留 `stream=false`、`stream=true` 和字段缺省三种状态；缺省不补 true。
- API 画像的系统提示词、tools、默认模型参数与顶层字段排序继续执行，但排序不能额外生成 stream。
- false／缺省交给上游按非流默认处理，true 请求流式；Gateway 转发上游实际返回的 Content-Type 和正文，不自行把 JSON 转为 SSE。
- `Body::from_stream` 只描述 HTTP 字节传输，不能据此判断应用协议为 SSE。
- 最终 CCH 仍基于实际序列化正文计算。本项不增加 stream 类型纠正或非法值处理，沿用上游校验。

### 4. Validation & Error Matrix

| 调用方 stream | 最终上游字段 | 本地协议感知上游的响应 | 下游结果 |
| --- | --- | --- | --- |
| false | false | application/json | 完整 JSON Message |
| true | true | text/event-stream | 保留 SSE，包含 message_stop |
| 缺省 | 缺省 | application/json | 完整 JSON Message |

上述矩阵同时覆盖 API 与 CC。协议感知上游是 loopback 合成服务，不等于已对真实账号完成推理验证。

### 5. Scenarios and Examples

- 正常：普通 SDK 发送 `{"stream":false}`，改写后仍为 false，Gateway 返回上游完整 Message。
- 边界：请求省略 stream，最终正文仍无此字段；Haiku probe 的顶层顺序断言也不得要求额外 stream。
- 错误用法：因为 API 请求需要 CLI 画像就无条件补 `stream=true`，使非流调用方收到 SSE。
- 正确处理：软件画像适配与流式选择独立，直接保留调用方字段，让上游选择对应响应形式。

### 6. Tests Required

- `messages_rewrite_preserves_explicit_stream_preference`：260／280／293 × API／CC × false／true，通过公共改写入口断言最终序列化值。
- `messages_rewrite_preserves_missing_stream_preference`：相同版本与客户端矩阵断言缺省 stream 未被新增。
- `gateway_preserves_stream_preference_through_upstream_and_response`：真实 Gateway + loopback 上游，按上游实际接收参数选择 JSON／SSE；覆盖 API／CC × 三种状态，断言最终参数、Content-Type、完整 JSON 的内容和结束原因或 SSE 结束帧。
- Rust 格式检查与完整 `cargo test --locked` 必须通过；不以仅检查内部 Map 的测试替代出站／返回契约。

## Scenario: Messages 固定顶层字段清理开关

### 1. Scope / Trigger

- Trigger：修改 Messages 顶层清理、全局开关、classifier 旁路或最终 CCH 时适用。
- 固定集合为 `MESSAGE_TOP_FIELD_DROP_KEYS` 的 56 个精确键，与 `tests/fixtures/messages-top-field-drop-keys.json` 逐项一致；来源 VM 版本固定，不在线同步、不生成官方字段白名单。

### 2. Signatures

- 持久化键 `message_top_field_filter_enabled`，默认常量 `DEFAULT_MESSAGE_TOP_FIELD_FILTER_ENABLED="true"`；管理 GET/PUT 沿用 `SettingsMap = Record<string,string>`。
- `Rewriter::filter_message_top_fields(body: &Value, path: &str, enabled: bool) -> Option<Vec<u8>>` 仅在真正删除根键时返回 Some。
- `Rewriter::refresh_message_body_policy_cch(&self, body: Vec<u8>, account: &Account) -> Vec<u8>` 复用唯一根级定位、版本化私有刷新与请求账号画像，供根字段清理及 Fast 账号策略的实际删除共用。
- `GatewayService::reload_message_top_field_filter_enabled(&self) -> Result<(), AppError>` 为 async，使用独立 RwLock 缓存；main 启动与 PUT 后调用。

### 3. Contracts

- 精确 `/v1/messages` 的普通 API／CC、classifier attribution 与 identity-only 三条转发分支统一消费可选过滤正文。count_tokens、其它路径、本地 mock／拒绝／缓存命中不扩大。
- 保留原始 body_map/body_bytes 用于准入、sticky、RPM、classifier、会话池和诊断；请求在重试循环前冻结一次开关，换号／401 等重试复用。
- 仅删除精确根键，使用稳定 `shift_remove`；保留其它根键相对顺序、未知扩展、嵌套同名键、metadata.user_id、工具 schema／输入与文本。不展开 extra_headers/extra_body，不提升认证，不做协议转换。
- 关闭、无命中、非对象或不可解析时不生成过滤正文，保留原字节路径；不得无条件再做全量 JSON 往返。
- 普通／归因分支先清理再按既有逻辑封口；实际删除后统一对最终输出刷新已有唯一受管理 CCH。缺失／非法／歧义目标按 F01 失败开放，不新增 billing／identity／CCH。
- 窄刷新不经过旧公开签名重试刷新入口的 CC Strip 门禁，但不能改变该旧入口语义。identity-only 函数本身仍只改身份；新增过滤阶段在外部处理必要的已有 CCH 刷新，不扩展 detector。
- classifier 的这一独立清理例外不启用 expansion、thinking、TTL、缓存断点、通用排序或完整日志；无实际删除时保持原旁路字节行为。
- SQLite／PostgreSQL 默认插入只补缺键，保留显式 false。PUT 仅接受精确字符串 true/false，在任何写入前校验；GET/reload 对缺失和历史非法值统一回退 true，读取失败保留旧缓存。保存后新请求生效。
- UI 默认开启，读写真实 key，保存字符串值；开关 false 可回滚新增清理。stream 三态、身份与 Session 策略继续独立适用。

### 4. Validation & Error Matrix

| 条件 | 结果 |
| --- | --- |
| 开启＋命中根键 | 稳定删除，最终已有 CCH 匹配正文 |
| 关闭或无命中 | 不新增序列化／CCH 刷新 |
| 嵌套同名键／未知扩展 | 保留内容和相对顺序 |
| classifier Strip／归因失败开放 | 独立清理生效，只刷新已有唯一合法目标 |
| 缺键／历史非法设置 | GET 与运行时统一开启 |
| 显式 false／重复迁移 | 保留关闭 |
| 非法 PUT 与其它合法键一起提交 | BadRequest，均不落库 |
| 401 等重试期间切换开关 | 本请求复用原快照，下个请求使用新值 |

### 5. Scenarios and Examples

- 正常：删除根级 `settings`，保留 `metadata.user_id` 和工具 `input_schema.properties.settings`。
- 边界：原始 JSON 无待删键时，identity-only 继续使用原字节；已有 billing 没有 CCH 时不补 CCH。
- 错误：只在普通 rewrite 分支删键，漏掉 classifier；或先封好 CCH 再删键且不刷新。
- 正确：三分支共同入口过滤，有删除才最终刷新已有目标，保留原公开刷新门禁和探针 detector。

### 6. Tests Required

- `gateway_message_top_field_filter_covers_frozen_keys_and_nested_data`、`message_top_field_filter_preserves_order_and_no_change_boundary`：56 键逐项／混合、开关、精确匹配、未知／嵌套与顺序。
- classifier bypass／existing_cch、普通 final_cch_profiles_and_modes、最终组合入口和失败开放测试：280／293、Rewrite／Strip、已有／缺失／非法／歧义 CCH；区分实际 Gateway 与组合入口证据。identity-only 加独立 billing 当前不能通过窄 detector，不声称该组合端到端可达。
- settings 与 DB 测试：默认、幂等迁移、显式 false、非法原子拒绝、GET/reload 一致、读取失败、热刷新和请求快照；核查两种 SQL 方言。
- count_tokens／其它路径隔离、stream 三态、会话身份、工具顺序及 F01 CCH 回归。
- Rust 格式／全量／CCH、前端 TypeScript/Vite 构建和真实 SFC setup 读写断言；后者不冒充浏览器 DOM 点击验证。

## Scenario: Messages beta 多值与查询参数规范化

### 1. Scope / Trigger

- Trigger：修改 Gateway 的重复 anthropic-beta 收集、Messages URL 的 beta query 或 count_tokens 共用入口时适用。
- 修复调用方等价 beta 集合因多行头而丢值，以及 beta=false 与追加的 true 并存；不改变账号能力或版本画像。

### 2. Signatures

- `extract_headers(headers: &HeaderMap) -> HashMap<String, String>` 为普通 Gateway 与 count_tokens 共用入口。
- `merge_anthropic_beta(required: &str, incoming: &str) -> String` 继续按逗号拆分、trim、精确去重并保留首次顺序。
- `upstream_url_with_base(upstream_base: &str, path: &str, query: &str) -> String` 构造通用出站 URL。
- `is_beta_query_key(key: &str) -> bool` 只执行一次解码后的精确键比较。
- `requires_upstream_beta_query(path: &str) -> bool` 只匹配精确 `/v1/messages` 与 `/v1/messages/count_tokens`；后者的专用发送入口仍由 `count_tokens_upstream_url_with_base` 固定唯一 `?beta=true`。

### 3. Contracts

- 仅 anthropic-beta 使用 `HeaderMap::get_all(...).iter()` 按同名值插入顺序合并全部可转字符串的值；头名大小写由 HeaderMap 处理，token 仍大小写敏感且完整匹配。
- 有效空 beta 保留“头存在”的语义；全部无法转字符串时跳过。其它头保留既有覆盖与非法字符串跳过策略，不新增 UA、request-id 或 Authorization 的逗号拼接规则。
- 收集后继续经过账号 1M／Fast 过滤和版本画像合并。1M 仍要求客户端携带且账号允许，并按画像放在 oauth 后；Fast 不主动开启。API、293 safeguard／title／后台窄表不因本修复扩大。
- 目标路径对解码后精确小写键 beta 归一成唯一 `beta=true`，替换首个同名项并删除后续重复；不存在则追加。只对键一次百分号解码，覆盖 false、空、无等号、编码同名与混合重复，不递归解码。
- 其它 query 片段及值的原始编码、大小写、顺序、空片段和重复保留；畸形或双重编码键若不精确匹配 beta，仍按其它原始片段保留。非目标路径不扩大改写，count_tokens 专用 URL 保持既有合同。
- 不建立全局 query 白名单，不以样本未出现为由删除未知扩展，也不把研究夹具的 synthetic_client_id 当作原生 CLI 必须删除的参数。
- 本修复只改头收集与 URL，不改 body、CCH、stream、R2 根键清理开关或 Session／探针／池优先级；没有新 setting、依赖或迁移。

### 4. Validation & Error Matrix

| 条件 | 结果 |
| --- | --- |
| beta 拆成两行、重叠或有空白 | 有效 token 合并去重，首次顺序保留 |
| 交换两行，账号允许／禁止 1M 或 Fast | token 集合不再因覆盖丢失，能力过滤仍独立生效 |
| 两行 beta 在 API／title／safeguard／后台入口 | 沿用各自画像，不混入未允许的 token |
| 目标 query 缺 beta、false、空或重复冲突 | 最终只含一个 beta=true |
| 一次编码的 beta 键 | 与字面同名项共同归一 |
| 非 beta 原始片段／非目标路径 | 保留其原始形式及既有路径行为 |

### 5. Scenarios and Examples

- 正常：两行分别包含 1M 与普通 beta，合并后再按账号权限过滤；未知 token 相对顺序仍按首次出现，不承诺任意换行后最终字节完全相同。
- 边界：`x=%2f&%62eta=false&beta=true&x=%2F` 变为 `x=%2f&beta=true&x=%2F`，其它编码和重复值保留。
- 错误：只在缺少原始字面 beta=true 时追加，留下 false/true 冲突；或整条 URL 解析再序列化，改变其它原始参数。
- 正确：仅识别同名键并替换 beta 片段，不用 VM 重建全部 query 的行为替代本地兼容合同。

### 6. Tests Required

- `gateway_beta_headers_merge_before_account_filters`：实际 Gateway＋loopback 覆盖 280／293 普通重复头交换、重叠空段、头名大小写、相似 token、1M／Fast 允许和禁止；观察最终 beta 集合及既有已知 token 顺序。
- `gateway_beta_headers_preserve_special_and_api_profiles`、`gateway_beta_count_tokens_merges_before_account_filters`：实际 API、293 safeguard／title／后台和 count_tokens 验证窄画像／计数专用 beta 保留；其它单值头仍按原策略。
- `gateway_beta_query_normalizes_keys_and_preserves_raw_fragments`、`gateway_beta_query_preserves_non_target_paths`：实际上游 URI 覆盖缺省／true／false／空／无等号／重复／百分号同名键、畸形与双重编码、其它 raw 参数重复和空片段、非目标路径及 count_tokens 专用入口；不以中间 Map 断言替代。
- `gateway_beta_headers_preserve_empty_invalid_and_single_value_semantics`：实际区分空 beta 与缺头／非法值，验证其它单值头和入站认证过滤策略。
- R2 清理／Session（含边缘 SP／HTAB）、stream 三态与 CCH 回归、Rust 格式及全量测试通过；仅使用本地合成上游。
- 抓包事实仅保证已读取的 592 条原生 Messages，均为唯一 beta=true；280 已用七份原件复核，293 原件未读，不外推。

## Scenario: Git 用户名提醒替换的边界与字面量

### 1. Scope / Trigger

- Trigger：修改 Claude Code 原生消息的 Git 用户名提醒脱敏、匹配正则或账号显示名称替换时适用。
- 目标是只替换已有提醒内的用户名文本，保留提醒结束标签、相邻结构及账号名称原文；不扩大消息位置或日期 normalize 的处理范围。

### 2. Signatures

```rust
fn scrub_git_user_in_reminders(body: &mut serde_json::Value, replacement_name: &str)
```

- `rewrite_messages` 的 `ClientType::ClaudeCode` 分支传入 `Account.name: String`，API 注入分支不调用该处理。
- `SYSTEM_REMINDER_REGEX` 匹配完整 `<system-reminder>...</system-reminder>`；内部 `GIT_USER_REGEX` 为 `r"Git user:[ \t]*[^\r\n<]+"`。
- 使用现有 regex 依赖的 `NoExpand` 写入替换字符串，没有新依赖、配置或数据库字段。

### 3. Contracts

- 仅处理顶层 `system` 字符串及数组文本块；数组块存在 `cache_control` 键即跳过，包括值为 null 的情况。messages、tools 和提醒外文本保持原有边界。
- `Git user:` 后的可选空白限定为 SP／HTAB，用户名匹配遇到 CR、LF 或 `<` 即结束；不能吞掉同行结束标签、内嵌其它标签或下一行环境字段。
- 账号名称按字面量替换，`$1`、`$0`、`${name}`、`$$` 及 Unicode 不得按正则捕获组语义解释；不新增账号名称转义或字段校验策略。
- 替换仍发生在现有最终序列化与 CCH 封口之前；版本化 CCH 算法、请求编码、缓存、Session 和响应处理不变。
- 匹配仍按既有顶层位置与提醒标签进行，不额外推断文本来源；日期规范化模式及候选识别保持原有逻辑，R14-04 另行评估。

### 4. Validation & Error Matrix

| 条件 | 结果 |
| --- | --- |
| 用户名与 `</system-reminder>` 同行 | 替换名称，结束标签保留 |
| 相邻两段提醒或用户名后存在其它标签 | 每段仅替换用户名，邻接结构不丢失 |
| LF／CRLF／CR 换行、用户名为空并紧跟换行 | 保留原换行，不把下一行当作用户名 |
| 账号名包含 `$1`、`$0`、`${name}` 或 `$$` | 保留全部原字符 |
| 缓存块、提醒外文本、messages 或工具描述 | 不扩大替换 |
| 280／293 原生正文改写 | 提醒标签及名称正确，最终已有 CCH 有效 |

### 5. Scenarios and Examples

- 正常：`<system-reminder>Git user: caller</system-reminder>` 使用账号名 `合成$1账号` 后，得到 `<system-reminder>Git user: 合成$1账号</system-reminder>`。
- 边界：`Git user:` 后立即换行时，不消费下一行；缓存块继续保留其原文。
- 错误：`[^\n]+` 吞掉同行闭合标签；直接把账号名作为正则替换模板会展开美元表达式。
- 正确：将用户名匹配限制到行或标签边界，并按字面量传给替换函数：

```rust
GIT_USER_REGEX.replace_all(&caps[0], NoExpand(replacement.as_str()))
```

### 6. Tests Required

- `cargo test git_user`：同行闭合标签、相邻提醒、其它标签、美元表达式及 Unicode 名称、三种换行、空用户名、非目标位置及缓存块。
- `git_user_scrub_keeps_profile_cch_valid`：实际 Rewriter 正文链路验证 280／293 的完整提醒和最终 CCH，不以字符串局部断言代替封口校验。
- `cargo fmt --check`、`cargo test cch`、完整 `cargo test` 和 `git diff --check`；仅使用合成身份与资料，不新增正式抓包或模型效果结论。

## Scenario: 统一出站 TLS 对齐原生 293 主请求

### 1. Scope / Trigger

- 修改 `src/tlsfp/tlsfp.rs` 或 `craftls/rustls` 的 ClientHello、密钥交换和会话恢复时适用。共享工厂同时服务正式网关与 v3 account-sender，TLS 模板独立于 HTTP 版本画像。
- 当前基线为原版 2.1.293 主 messages：58 条 HTTP 关联握手中有新建／恢复主请求各 6 条；原版精确二进制在无外网、空 HOME、合成凭据、无 MITM 的回环监听中再次确认 offer。证据见[任务研究](../../../tasks/10-29-cc2api-native-tls-fingerprint-alignment/research/alignment-findings.md)。
- 当前唯一正式 TLS 模板为原生293主请求，版本按下方绑定规则选择，客户端按代理及 TLS ID 隔离。辅助接口另有两种实测形状，280／303 尚无正式绑定；不得把兼容使用该基线宣称为原生已验证。

### 2. Signatures

```rust
get_request_client(proxy_url: &str) -> Result<reqwest::Client, reqwest::Error>
make_request_client(proxy_url: &str) -> Result<reqwest::Client, reqwest::Error>
// craftls 内部：仅显式覆盖 key_share 时优先模板首个真实组。
CraftOptions::initial_key_share_group(&self) -> Option<NamedGroup>
```

- 统一定义为 `CLAUDE_CODE_293_CIPHERS`、`CLAUDE_CODE_293_EXTENSIONS` 与 `CLAUDE_CODE_293_FINGERPRINT`；生产与测试均经 `build_tls_config_with_roots` 构建。
- 不新增设置、环境变量或数据库字段。版本绑定入口见下方「TLS 画像版本绑定与冻结传输」；本轮没有按辅助端点选模。

### 3. Contracts

- 有序 cipher：`4865,4866,4867,49195,49199,49196,49200,52393,52392,49161,49171,49162,49172,156,157,47,53`。
- 新连接有序扩展：`0,23,65281,10,11,35,16,5,13,18,51,45,43`；签名算法：`1027,2052,1025,1283,2053,1281,2054,1537,513`；groups：`4588,29,23,24`；版本：`772,771`；legacy version：`771`；点格式：`0`；ALPN：`http/1.1`。
- 初始和恢复连接 key_share 均为 `4588:1216` 后接 `29:32`。SNI 使用真实目标，随机和密钥每次真实生成；JA3 新连接为 `1523504b38f0fae0d881d4b6554aac1b`，实际 TLS1.3 恢复时末尾增加 PSK 41，为 `ae5f2d34331c18f27df379f7d4b72e35`。票据、binder、Cookie 仅保留协议实际生成的值，不硬编码票据长度。
- 混合组 4588 的 client 为 ML-KEM768 公钥 1184 字节接 X25519 公钥 32 字节；server 为密文 1088 字节接公钥 32 字节；秘密为 ML-KEM 32 字节接 X25519 32 字节。实际 Provider 只保留可执行的 4588、X25519、P256、P384。
- 显式覆盖 key_share 时初始组优先模板，不能因缓存 hint 改变顺序；关闭覆盖时沿用 hint。HRR 明确请求组时仅发送该组，不强行重发初始双 share；PSK 保持最后，binder 由 rustls 计算。
- 保持公有根和主机名验证、30 秒建连、30 秒 TCP 保活、无整体长流超时。同代理复用、异代理隔离，非空非法代理错误向上传播，不回退直连。

### 4. Validation & Error Matrix

| 条件 | 结果 |
|---|---|
| 无恢复材料的新连接 | 13 项扩展、双 share 和新连接 JA3 匹配基线 |
| 服务端实际发票据后的 TLS1.3 第二连接 | 真实 `session_reused`，PSK 最后，双 share 顺序保持 |
| 缓存 hint 为 X25519 或 P256 | 显式模板仍先 4588；关闭覆盖的配置沿用 hint |
| HRR 请求 P256 | 单一 P256 share 65 字节，完整 HTTPS 成功 |
| 混合 server share 长度不为 1120 或 X25519 秘密全零 | 返回错误，不产生可用共享秘密 |
| 非信任证书、错误主机名、非法代理 | 明确失败，不绕过验证或切直连 |

### 5. Scenarios and Examples

- 正常：生产工厂经代理向 `api.anthropic.com` 建连，独立解析实际字节对照 fixture 全部字段；现代 TLS1.2／1.3 完成 HTTPS，同连接可复用。
- 边界：第一连接协商 X25519 后，新连接仍发原生双 share；服务端要求 P256 时按 HRR 完成交换。混合交换另以独立服务端封装验证双方 64 字节秘密一致。
- 错误用法：仅把 JA3 字符串改成目标值、填充相同长度的假 key_share，或从 MITM 出口推断原生 CLI。正确处理：核对真实发送字节、真实密钥交换与成功握手，保留方向／版本和来源证据；原生回环 offer 对照本身不冒充完整 HTTPS 成功。

### 6. Tests Required

- `cargo test --lib tlsfp`：独立 `tests/fixtures/tls_clienthello.py` 对照脱敏 `claude_code_293_tls.json`，验证完整字段、公开扩展内容、缓存 hint 与关闭覆盖兼容分支。
- `local_https_native_fingerprint_tls12_tls13_resumption_and_hrr`：TLS1.2／1.3、同连接复用、第二 TCP 真实恢复、末尾 PSK，以及 P256 HRR 完成 HTTPS。
- `hybrid_exchange_matches_independent_server_and_rejects_invalid_peers`：真实 ML-KEM 封装及独立 X25519，秘密一致；错误长度和全零 peer 拒绝。
- 保留 `runtime_transport::tests::local_https_*` 的字节、证书／主机名失败与流取消，以及代理池回归；完整 `cargo test`、`cargo fmt --check` 和 `git diff --check`。SQLite 夹具发生高并发锁冲突时可用 `cargo test -- --test-threads=4` 完整重跑，不能忽略失败。
- 发布后用同批真实 account-sender 镜像在 `network=none` 容器经回环 CONNECT 取得 ClientHello 并独立解析；此操作只验证正式二进制 offer，完整 TLS 可用性由上述 HTTPS 测试证明。

## Scenario: TLS 画像版本绑定与冻结传输

### 1. Scope / Trigger

- 修改 TLS 选择、版本绑定、默认回退、客户端缓存或 gateway → sender 元信息时适用。流程固定为实际采样确认 → 新增或复用 TLS 模板 → 绑定版本，不能从版本号推导模板。
- 不改变现有客户端 UA／账号两种 HTTP 画像规则；普通网关和 v3 sender 使用同一 TLS 工厂，原生 CLI 仍自行发起握手。

### 2. Signatures

```rust
ClaudeCodeProfile::tls_profile: Option<TlsProfileId>
ClaudeCodeProfileSelectionConfig::default_tls_profile(self) -> TlsProfileId
tls_profile_for_version(version: &str, fallback: TlsProfileId) -> TlsProfileId
tls_profile_for_account(account: &Account, fallback: TlsProfileId) -> TlsProfileId
get_request_client_for_profile(proxy_url: &str, profile: TlsProfileId)
    -> Result<reqwest::Client, reqwest::Error>
configured_default_tls_profile() -> TlsProfileId
set_configured_default_tls_profile(profile: TlsProfileId)
PreparedRequest::tls_profile: TlsProfileId
```

- `src/tlsfp/profile.rs::TlsProfileId` 是模板 ID 注册表；正式枚举目前仅 `ClaudeCode293`，传输字符串 `claude-code-2.1.293`。`TestReordered` 仅 `cfg(test)`，正式报文不能选择它。
- 原 `get_request_client(proxy_url)`／`make_request_client(proxy_url)` 保持兼容，使用当前配置默认 TLS。

### 3. Contracts

- 版本293显式绑定原生293；其他既有版本留空。解析先使用版本的显式绑定，再用请求入口冻结的系统默认版本 TLS；未知、空版本和未绑定版本都沿该兜底，空版本不能先被 HTTP 的归一化函数补成293。
- 系统默认版本未绑定时，由 `default_tls_profile` 集中沿内置默认版本的已验证绑定兼容。未来默认版本绑定新 TLS 后，所有未绑定版本自动跟随；调用点不得硬编码293或自行选最近版本。
- messages/count_tokens 在准入快照的同一读锁内冻结 HTTP 选择和默认 TLS。选账号后按请求级账号副本解析绑定；401、signature、429及换号沿同一入口默认。配置 reload 仅影响后续请求；后台 telemetry 的后续轮次可换客户端，不中断正在发送的响应。
- `reload_access_profile_config` 在写锁内解析成功后同步工厂默认并替换选择快照；解析失败保留旧值。没有版本的 OAuth 使用该配置默认；TokenTester、Prime 和 Hello 沿实际版本或账号绑定。Hello 接收业务冻结的 TLS，其缓存/singleflight key 同时包含 HTTP profile 和 TLS ID；旧 v2 key 不复用，自然到期。
- TokenTester 的 TLS 选择读取 `canonical_env.version` 原始字符串；空值、`null`、未知或未绑定版本沿调用方冻结的配置默认，HTTP 请求头仍可单独使用归一化后的默认版本。不得先调用 HTTP 版本归一化再选择 TLS。
- `REQUEST_CLIENT_CACHE` key 为 `(proxy_url, TlsProfileId)`；每个客户端构建独立 rustls 会话存储。相同 ID 的不同版本可共享同代理连接，ID 不同必须隔离连接和恢复票据；关闭池每次新建，非法代理继续失败关闭。
- 网关将确定的 ID 放入认证保护的 `x-v3-request` 元信息，最终 body 原字节独立传递。直连 `send_direct` 与 sender 都使用该 ID，不从 body／HTTP UA 重选；调用方提供的同名入站头不能替换网关构造的元信息。
- `PreparedRequest.tls_profile` 使用枚举反序列化和 `serde(default)`：旧报文缺字段沿内置兼容默认，显式未知／null 拒绝。sender 先鉴权再解析，错误发生在递增 active/submitted 前，返回400和 `x-v3-transport-error: before-send`，不接触上游；未知ID不能静默兜底。
- v3 按联合清单同批更新 gateway/sender；保留账号、generation、release、origin及路径校验。原生293算法、双share、PSK末尾、HRR、证书、代理、长流和取消合同保持。

### 4. Validation & Error Matrix

| 条件 | 结果 |
|---|---|
| 生效293，配置默认另有已验证绑定 | 使用293明确绑定 |
| 生效280／未知／空版本未绑定 | 使用配置默认 TLS；默认也无绑定时沿内置兼容值 |
| 默认在请求读体期间变化 | 本次仍用冻结 TLS，后续请求使用新默认 |
| 账号模式且UA版本不同 | 按最终账号版本绑定，缺失时用入口默认 |
| 同代理不同TLS ID | 不同实际ClientHello与独立恢复存储 |
| sender收到注册ID／缺字段 | 使用指定ID／历史兼容默认 |
| sender收到未知显式ID或null | 鉴权后400、before-send，active不增加，无上游提交 |

### 5. Scenarios and Examples

- 正常：293已采样并绑定；未来版本经过验证可绑定已有ID或新增模板。相同模板无需复制cipher和扩展列表。
- 边界：280未采样、系统默认暂选280时，仍沿内置293兼容；未来默认版本有新绑定后，280随默认切换，不能继续在工厂写死293。
- 错误用法：sender按自己的CLI版本重选，或切换默认后仍按代理单维度复用旧连接。正确处理：网关冻结ID、跨进程原样传递，工厂按代理与ID隔离。

### 6. Tests Required

- `tls_bindings_use_configured_default_without_inventing_native_versions` 和 `tls_default_snapshot_survives_change_and_shared_profiles_reuse_id`：绑定、空／未知／未绑定、默认变化及共享ID；正式模板不含测试ID。
- `gateway_messages_and_count_tokens_select_actual_tls_by_effective_profile`：两个入口、客户端／账号模式，读体期间切默认后的本次与下一次实际ClientHello。
- `sender_preserves_tls_profile_legacy_default_and_rejects_unknown_before_submission`：真实HTTP传输、不同ID实际wire、缺字段默认，以及未知ID400、before-send和active=0。
- `same_proxy_different_tls_profiles_emit_distinct_actual_clienthellos`、`distinct_tls_configs_keep_resumption_tickets_separate`：实际工厂分池及真实恢复状态 `[false,true,false,true,true]`，禁止只断言常量或缓存条目数量。
- 原293完整握手／恢复／HRR和Hello去重、代理、证书、流取消及改写回归；`cargo fmt --check`、完整 `cargo test -- --test-threads=4`、`git diff --check`。正式镜像无外网验证显式ID、旧报文与未知ID拒绝，不能用测试替身冒充模型成功。

## Scenario: 原生 Messages 代理关联头透传

### 1. Scope / Trigger

- 修改 `Rewriter::rewrite_headers` 的原生头白名单、大小写或发送边界时适用。
- 根因是仅放行 request-class 会保留 subagent 分类，却丢失调用方提供的代理身份和 prompt 关联。本合同为现有透传的定向补全，不切换全局黑名单策略。

### 2. Signatures

- `Rewriter::rewrite_headers(&self, headers: &HashMap<String, String>, path: &str, account: &Account, client_type: ClientType, model_id: &str, body_map: &Value) -> HashMap<String, String>`。
- `ordered_anthropic_headers(path: &str, headers: &HashMap<String, String>) -> Vec<(String, String)>` 继续组织发送头；`PreparedRequest.headers` 承载同一列表。
- `path` 为已剥离 query 的路径；不新增设置、环境变量、数据库或 sender 协议字段。

### 3. Contracts

- 仅 `ClientType::ClaudeCode` 且 `path == "/v1/messages"` 时，保留调用方实际提供的 `x-claude-code-agent-id`、`x-claude-code-parent-agent-id`、`x-claude-code-agent-type`、`x-claude-code-prompt-id`。
- 头名匹配大小写无关，输出使用以上小写拼写，值原样保留；与既有 request-class、prev-tool-durations 适用相同端点边界。
- 这四项各自可选，缺失保持缺失。主请求可以只带 prompt-id；不能从正文的 subagent/Explore 字样、模型或父请求推断并补造身份。
- `/v1/messages/count_tokens`、账号设置、hello 等其它端点不继承这些头；API 模拟入口沿用既有生成规则，不从这次修复补造代理关联。
- 不改入站 request-class，也不把子代理强制转成 main；不重铸 agent、parent 或 prompt ID。现有 Session、正文 billing、metadata 与 CCH 改写规则继续各自生效，本次不新增身份映射。
- 正常网关与账号 sender 共用改写后的 `PreparedRequest.headers`；不在 sender 再过滤这些合法字段。保持既有头序、HTTP/1 大小写机制及 HTTP/2 小写规则，不宣称新增了未采样的完整子代理头序画像。

### 4. Validation & Error Matrix

| 条件 | 结果 |
| --- | --- |
| 原生 messages 提供代理关联头，含大小写变体 | 对应字段和值保留，名称使用规范小写 |
| 主请求只提供 prompt-id，或全部可选字段缺失 | 保留已提供项，缺失项不生成 |
| 相同入站头用于 count_tokens、设置或 hello | 不透传这四项 |
| API 模式收到这些头，或正文只提到 subagent | 沿用原 API 分类和生成行为，不据此注入代理身份 |

### 5. Scenarios and Examples

- 正常：原生请求带 `request-class=subagent`、合成 child/parent、`agent-type=Explore` 与 prompt UUID，出站仍保留这些字段和值。
- 边界：`request-class=main` 只带 prompt-id，出站保持 main 和该 prompt-id，不增加 agent-id、parent-agent-id 或 agent-type。
- 错误用法：只允许 request-class 后以“subagent 已透传”判断关联完整；正确处理是逐项核对四个关联头，并确认真实发送字节而非只看内部 HashMap。

### 6. Tests Required

- `messages_agent_context_headers_are_preserved_only_for_native_messages`：280/293、原生/API、messages/count_tokens/设置/hello 矩阵，大小写、值和端点隔离。
- `native_main_prompt_id_is_preserved_without_inventing_agent_identity`：缺省和仅 prompt-id 的 main；正文标记不触发分类或身份猜测。
- `business_forwarding_preserves_actual_http1_casing_and_telemetry_default`：保留原 280 主请求与其它端点回归，追加 293 子代理真实 TCP 验证，四个头各出现一次，count_tokens 不泄漏，原生大小写机制生效。
- `cargo fmt --check`、完整 `cargo test`、`cargo test cch`、`git diff --check`；测试使用合成身份和本地模拟上游，不自动调用真实账号。
