# 项目迭代模式契约

内容 schema 3 的完整需求／BUG 周期复用 policy 3，见末节；历史内容 schema 1／2 继续遵守各自冻结版本。

## Scenario: legacy 内容 schema 1 的线性步骤与计划执行

本节的单步与同 CLI 多步分别指无 schema 的旧执行策略与 policy 2；其中历史“schema 2”均指执行策略版本，不是内容 schema 2。共享停止、鉴权及文件交接继续适用；新场景使用后节 policy 3 契约。

### 1. Scope / Trigger

- 修改 `orchestrator/project_{library,iteration,plans,verifier}.py`、`images/account/project_plan.py`、`run_kind='project_iteration'`、项目管理 API、`#projects` 页面或项目内容打包时适用。
- 项目调用 `orchestrator/main.py` 的共享停止入口、决定文件跨 UID 交接时也适用。
- 本模式依赖 v3 固定账号运行环境；普通题库、批次、养号、抓包和续聊继续使用原有身份及状态语义。
- 内容、路线和业务验收归本文件；Docker 账号角色、租约、认证及原额度恢复继续遵守 [account-runtime-v3.md](./account-runtime-v3.md) 与 [database-guidelines.md](./database-guidelines.md)。

### 2. Signatures

控制端入口：

```python
ProjectLibrary(root, minimum_projects=100, minimum_steps=20)
ProjectLibrary.install(data)
ProjectIterationManager.create_batch(account_id, name, project_keys=None, policy=None, scenario_entries=None)
ProjectIterationManager.transition(batch_id, action)
ProjectIterationManager.prepare_workspace(row, run_id, environment_root)
ProjectIterationManager.execution_released(run_id, quota_attempt, error=None)
initialize_plan_schema(connection)
ProjectPlans.execution_configuration(run_id, source, quota_attempt,
                                    native_directory, request_path, decision_path, cwd)
ProjectVerifier.verify(candidate, cases, timeout=30)
write_document(path, value, *, mode=0o600, owner=None) -> None
_stop_project_run(rid) -> dict
```

账号侧 `images/account/project_plan.py` 使用 `_read(path, maximum=65536) -> dict` 读取控制文件；仅原子替换引起的旧 fd 链接数归零允许有限重开。

API 均位于原 cookie 鉴权下：

| 方法／路径 | 输入或结果 |
| --- | --- |
| `GET /api/project-catalog` | `version,digest,projects`，项目摘要含 `project_key,seed_digest,step_count,milestones` |
| `GET /api/project-catalog/{key}` | 公开目标与依赖，不返回参考实现 |
| `POST /api/project-iteration-batches` | 原账号、名称和项目键，加严格整数策略字段；按内容版本创建 policy 2 或 policy 3，不接受调用方直接指定 schema |
| `GET /api/project-iteration-batches[/{id}]` | 批次的 `status,policy,counts,scheduling`；详情另含 `instances`，实例含 `in_pool` |
| `POST /api/project-iteration-batches/{id}/{start\|pause\|stop}` | 返回最新批次详情 |
| `GET /api/project-instances/{id}` | 路线、尝试和 `plans`；计划含固定范围、完成步数和关联 `runs`，执行状态、`validation_status` 分开 |
| `GET /api/project-instances/{id}/usage` | 按步骤聚合尝试，缺失证据为 null；`complete` 仅表示各尝试都有记录 |
| `GET /api/project-step-attempts/{id}/artifacts` | 固定报告、摘要、文件清单和可用的版本差异 |
| `GET /api/project-step-attempts/{id}/file?path=...` | 清单内文件的有界文本预览 |
| `GET /api/project-iterations-stream?batch_id=...&instance_id=...` | `project-state` SSE；实例必须属于所选批次 |

`name` 默认“项目迭代批次”，去除首尾空白后为 1～120 字符；项目选择不可空、重复、超出 100 项或不属于当前版本。省略项目键表示全选。

新策略字段拒绝 bool、字符串和小数，不静默夹取显式非法值：

| 字段 | 默认 | 范围与边界 |
| --- | --- | --- |
| `concurrency` | 2 | 1～2 且不超过账号与有效活动池；省略时按实际容量取默认 |
| `active_projects` | 3 | 1～100，有效值不超过所选项目数 |
| `rotation_steps` | 5 | 正整数，不超过所选路线最大步数，只计验收通过 |
| `steps_per_plan` | 2 | 同一 CLI 内的计划步数；正整数，不超过所选路线最大步数 |
| `timeout_sec` | 1800 | 60～86400，覆盖整个本次计划执行 |
| `interval_min_sec/interval_max_sec` | 0／0 | 0～86400，最大值不小于最小值；只作用于计划补位 |

`scheduling` 返回 `account_concurrency_limit,configured_concurrency,active_runs,running_count,wait_reasons,admission,next_launch_at`；公开计划不返回原生 session、PID 或进程证明。额度来自账号设置，不另存一套批次阈值。

SQLite 的 `PROJECT_SCHEMA` 由 `init_db()` 幂等执行，新增：

- `project_catalog_releases`：`digest UNIQUE`，固定发布路径。
- `project_iteration_batches`：账号、创建时身份、内容版本、`policy_json,generation,status,active_instance_id`。
- `project_instances`：`UNIQUE(batch_id,project_key)`，冻结 manifest、基线／路线摘要、`next_step_index,workspace_relative,started_at,checkpoint_digest,visit_order`；新增 `initial_order,in_pool,visit_completed`。
- `project_step_attempts`：保留 `UNIQUE(instance_id,step_id,attempt_no)`；保存代次、预期 checkpoint、执行释放证据、候选／报告／已接受摘要。迁移解除 `run_id UNIQUE`，增加 `plan_id,phase_seq,expected_prompt,native_start_json,native_end_json,fenced_at,fenced_source`；`validation_status='passed'` 的实例与步骤仍有部分唯一索引。
- `project_execution_plans`：固定 `start_index/target_index`（后者为排他上界）、`completed_steps,session_id,execution_json,generation,status`；每实例至多一个 ready／running／finalizing／quota_wait 计划。
- `project_plan_executions`：`run_id UNIQUE`，记录计划、当前尝试、source／额度代次、阶段、决定和严格释放；每计划至多一个未收口执行。

迁移事务复制全部旧列、ID、索引和自增序列，重复初始化幂等。schema 2 正常每个计划创建一组原 `tasks/runs`，多步及本次业务修复共用 Run；超时恢复另建 Run 并关联原计划。`runs.run_kind='project_iteration'`；来源题号只满足旧 `topic_no` 非空契约，原 `topic_id/batch_id` 留空，不加入旧路线或补充调度。无策略 schema 的旧批次继续单步 Run；内部 `create_batch(...,policy=None)` 保留该兼容入口，新 API 传入策略字典。

### 3. Contracts

**legacy 内容与版本**：内容 schema 1 的 `catalog.json` 为 schema 1；每个项目包含 `project.json`、可运行 `seed/` 和控制端 `verification/`。当前适配协议固定为 `python3 app.py`，逐行输入／输出 JSON。基线代码必须具有自己的业务核心；通用算法与启动脚手架可以复用。每步依赖紧邻前一步并属于明确阶段。

旧 100 个生成项目、生成器和参考运行时保持退役。当前源码 catalog 为内容 schema 2，实际版本和项目／场景／任务数量、原生适配与场景执行见后节。legacy 调度回归由 `orchestrator/project_test_content.py` 在临时目录构造夹具；源码变更不代表生产已部署，不删除历史发布及实例成果。

内容首次注册到 `BENCH_DATA/project-library/releases/<digest>`，旧批次固定旧版本。账号只复制 `seed/`，不挂载参考器或冻结验收目录。内容摘要覆盖相对路径和字节，不包括账号、mtime；拒绝链接、特殊文件及越界路径。快照上限为 128 MiB／10,000 文件，JSON 文件上限为 4 MiB。

**自动调度**：创建批次默认 `paused`，只建立元数据。schema 2 在创建时洗牌一次并持久化初始队列；池首批来自队头，完成或局部阻塞后从原队列补池。默认并发 2、活动池 3，Tasks 与项目共用账号真实容量并尊重 `PER_ACCOUNT_CONCURRENCY`；同实例只有一个在途写入执行。没有活动名额时不提前开始第四个项目。

连续通过默认 5 步后轮换，同一次 CLI 计划默认 2 步，实际范围受本轮余量和路线尾部截短，因此一轮为 2＋2＋1；修复不计步，每步首轮加最多两次修复。旧 schema 1 保持按内容阶段轮换和单步 Run。局部失败保留现场并切换；认证、身份变化或严格清理失败阻断批次。路线耗尽完成，不无限生成后续任务。

先填满初始并发窗口，执行严格收口后抽取计划补位间隔并持久化 `next_launch_at`；重启不重抽，一个截止只消费一次补位，等待不持有 CLI 许可。5h／7d 自设比例或当地时段只阻止下一计划及新恢复执行；当前已投放计划继续冻结范围，真实耗尽、认证及停止仍使用原强门禁，不新增 usage／模型探测。

批次状态为 `paused/active/pausing/stopping/stopped/blocked/completed`。暂停禁止新投放，已投放计划可以完成并验收；额度等待的原尝试保留，恢复沿用同一 Run。停止先持久化意图并增加 generation，终止在途执行；停止、阻塞、完成的批次不再启动，须另建批次。

**共同门禁与目录**：新类型通过 `_execution_workload` 映射到 `normal` 额度策略。窗口等待、账号信号量之后、凭据与环境准备之后、实际 exec 之前均复核门禁；不得创建独立模型调用通道。`can_start` 还核对账号可用性、冻结身份和父批次代次。

实例的 `workspace_relative/started_at` 初始为 NULL。只有进入实际启动才从控制端 staging 发布到 `environments/<environment_id>/projects/<alias>`；alias 由环境与实例 ID 固定派生。发布标记保存实例、基线摘要和目标路径，代次由尝试表及发布前检查约束。发布中断后核对已有归属，不删除或覆盖未知目录。后续步骤只复用原目录；暂停、阶段切换、完成、停止和服务重启均不清理项目文件。

**会话和用量**：schema 2 一个计划固定 session、cwd、版本／模型／effort，正常同一 CLI 进程和 tmux 逐步交接，不把独立 Run 归组冒充。提示只包含当前步骤、近期成果和有界失败证据。第 1 步通过、第 2 步半成品超时后，旧 Run 保留 timeout、计划为 1／2，目录和半成品保留；新 Run 接续原 session，只补原计划剩余一步。真实 quota_wait 使用原 Run／尝试，仅增加额度执行代次。schema 1 的新步骤／业务修复继续使用新主会话。

每步尝试保存自己的原生字节起止；已通过步骤的终点不能被最终 Run 释放覆盖，额度暂停也封存未完成步骤的边界。响应按 message ID 去重，排除 sidechain/meta。步骤不能重复累计整 Run 总量；缺起点、截断或无可靠统计时显示未知，页面不主动探测模型用量。

**验收与成果**：schema 1 仍须等待整次执行严格释放。schema 2 由 driver 在正常最终回复后提交候选通知，控制端核对 source／generation／阶段／session、实际 user 输入及 assistant 父链，再定向冻结完整作业树；稳定内核暂停证明成立后才封存并独立验收。接受检查点和下一决定同事务持久化，恢复同一个 CLI 后才投递下一步；最后一步通过仍须等该 Run 严格释放才收口。单有退出码零不能推进，验收不修改持续工作副本。

输入发送意图先持久化；确认丢失时先读实际原生 user，已消费不能重发。超时恢复若既无消费证据、又无检查点接受后尚未准备本步的明确证明，则阻塞实例。恢复前核对原 session 的持久字节位置和检查点清单／对象摘要；缺失、截断或冲突时保留现场并阻塞，不换会话、不重建 seed。

**决定文件交接**：`write_document` 默认仍为私有0600。决定专用调用传 `mode=0o640,owner=(0,1000)`，在临时fd完成归属、权限、完整写入和fsync后再replace，不能发布后才chown/chmod。已存在的普通、单链接文件若内容及root:1000 0640均相同，`_decision()`不替换inode；缺失或决定变化时重发。driver保留NOFOLLOW／NONBLOCK、普通文件及字节上限检查，只有fstat发现nlink=0时关闭旧fd重开，最多打开3次；硬链接、特殊文件、超大内容和持续替换仍失败，所有fd均关闭。

**停止与局部故障**：项目使用 `_stop_project_run()`，观察到终态或已认领stopping时返回 `{ok: true}`，不改写结果、不重复清理，也不生成释放证明；公开 `POST /api/runs/{rid}/stop` 对初始已终态请求仍400。长IO之后在短DB锁内重读，以quota_attempt及queued/running/quota_wait状态条件认领stopping并检查rowcount，只有认领者清理；竞争终态保留，代次变化拒绝409。清理后的stopped写入同样限定原代次及stopping状态。局部blocked导致的定向停止仍保留blocked及首次具体原因，不能泛化为人工cancelled；父代次变化／批次停止仍按取消处理。`is_executing`、最终释放代次及execution_error的门禁保持独立，认证／严格清理失败仍阻断批次。

整个本次 CLI 计划共用工作超时，逐步通过和修复均不重置；管理暂停及验证另有有界时间。tmux 交互 shell 启动前 `set +m`，防止冻结／恢复后 shell 作业控制把终端改回规范输入，导致下一步不能被 CLI 消费。

验证容器复用同批 account 镜像，显式覆盖入口、UID 1000、无网络、只读根、无账号 HOME／凭据／Docker socket；候选只读挂载，复制到临时可写目录运行。默认 30 秒，内存 256 MiB、PID 64，输入及输出有界。控制端比较行为结果并回归基线和此前全部已接受能力，不能信任程序自行宣告通过。

`validation_status` 为 `pending/running/passed/failed/error/cancelled`。程序超时／错误输出属于业务失败；验证基础设施故障最多在本地验证两次，不投递模型修复。通过后事务同时校验父状态、generation、步骤下标和预期 checkpoint，并依赖唯一约束防止重复接受。失败快照和最后通过版本同时保留，历史文件通过清单读取，不能用当前目录冒充旧成果。

**集成与交付**：项目 API 的五类资源必须同步加入 `cc2api/src/service/runtime_bridge.rs` 白名单，保留内部路径和编码穿越拒绝；不得扩展鉴权豁免。`#projects` 复用 `RUNTIME_BASE`、API helper、主题变量及转义；离开页签关闭 EventSource，推送重绘保留滚动位置和路线展开状态。

批次调度提示按七种状态分别显示：仅active使用实时wait_reasons或自动推进提示；暂停、收尾、停止、阻塞及完成各自说明。`next_launch_at`只有active且仍在未来时显示，终态不显示等待启动或失效投放时间。

control 镜像的项目库、`images/v3/Dockerfile.dockerignore` 放行项、`deploy/v3/manage.py` 的源码快照列表须同步。`PROJECT_LIBRARY_DIR` 可覆盖内容路径，容器默认 `/repo/project_library`；当前 catalog 损坏只使目录／新建准入返回 503；历史从冻结 release 读取，普通题库保持原入口。账号删除引用计数包含新批次，不能将尚无 run 的项目批次变成孤儿。

### 4. Validation & Error Matrix

| 条件 | 行为 |
| --- | --- |
| `account_id=true` 或键列表类型不合法 | Pydantic 422，不写批次 |
| 项目选择为空／重复／未知、名称非法、账号不可用 | 创建返回 400，不建目录 |
| 新模式未就绪或内容损坏 | 项目 API 503，旧模式继续可用 |
| 目录／批次／实例／尝试不存在 | 对应查询 404 |
| 恢复已停止／阻塞／完成或身份不符批次 | 409，保留成果 |
| 从旧 task 再次运行、旧 run 人工续聊项目步骤 | 409，引导通过项目批次推进 |
| 窗口／额度等待、暂停、未通过准备后门禁 | 不发布未开始的项目目录，不绕过门禁 |
| schema 1 未严格释放／schema 2 无匹配暂停证明 | 不封存、不验收、不投递下一步 |
| schema 2 最后一步通过但 Run 未释放 | 保持 finalizing，同实例不得开始下一计划 |
| 合法原子替换使已打开fd的nlink=0 | 关闭旧fd有限重开；超过3次或其他文件校验失败则拒绝 |
| 内部停止已终态／已认领停止的Run | 幂等确认；结果和释放证明保持，公开初始终态仍400 |
| 停止认领前出现终态／新额度代次 | 保留终态且不清理；新代次拒绝409，不停止新执行 |
| 局部blocked定向停止执行 | 保留首次原因，严格释放后健康项目继续，不能改成cancelled掩盖故障 |
| 会话／检查点缺失、截断或输入消费不确定 | 保留代码与失败现场，阻塞该实例，不盲发或重建 |
| CLI 退出正常但行为失败 | 不推进，在原目录有限修复；用尽后阻塞实例并切换 |
| 验收期间停止或旧 generation／checkpoint 回包 | 不接受结果，不增加进度 |
| 已发布目录缺失、归属不明、链接或快照损坏 | 保留现场并阻塞，不重置 seed |
| 请求历史文件越界或文件不在清单 | 404；不读任意宿主路径 |

### 5. Scenarios and Examples

- 正常：创建 `{ "account_id": 1, "name": "本地迭代", "project_keys": ["project-001", "project-002"] }`，两个实例路径均为空。实际启动后才创建各自目录；账号有容量时两个项目真正并行，每个计划在同一个 Run 内验收两步。
- 边界：一轮 2＋2＋1 通过后轮换；第 2 步半成品超时显示 1／2，原 timeout Run 不变，恢复 Run 只补该步。暂停和额度等待保存进度，停止后目录仍可检查。
- 错误用法：每个新 Run 重新复制 seed，或直接用退出码零推进步骤。正确做法是按实例复用目录，按 schema 取得严格释放或逐步定向暂停证明，再验收冻结候选。
- 错误用法：用整个共享 cwd 的 JSONL 计作本轮 token，或把参考路线通过称为真实模型完成。正确做法是使用 run 字节边界；真实模型通过率和用量单独观察。
- 边界：决定文件重复发布保持同一inode，文件缺失则补发；另一个连接先把Run写成success时，停止请求不能覆盖成stopped或执行第二次清理。
- 错误用法：replace后才给决定文件改权限，或为处理nlink=0而接受所有链接。正确做法是发布前设置权限，仅对已打开旧inode归零有限重试，继续保留全部校验和阶段归属核对。

### 6. Tests Required

- `python3 scripts/validate-project-library.py --root <本次测试夹具目录> --all`：数量、依赖、摘要；全部 seed 真正运行；待开发步骤不能在基线通过；所有测试参考断言可达到。该命令仅用于显式 legacy 夹具；当前正式根静态校验输出 3／13／20，新内容原生校验使用 `validate-project-scenarios.py`，不将临时夹具回写为正式内容。
- `test_project_iterations.py`：同账号不同批次及不同账号基线一致、修改隔离；100 元数据零目录；两步累积、失败修复与旧能力回归；三项目阶段轮换返回；重复接受、停止竞争、额度暂停恢复及重启；认证／清理失败阻断；不可变历史、路径和主日志边界。
- `test_project_plans.py`：严格策略、实际容量 1、固定随机队列、2＋2＋1 轮换、共享容量与持久间隔；同 Run 两步、逐步 token、业务修复、停止竞争、重复决定及父链乱序；1／2 超时接续、原 Run quota_wait、检查点／会话缺失与截断、确认丢失和禁止盲发；旧结构主键／索引／序列幂等迁移。
- 文件／停止回归：发布边界实际UID1000读取、相同决定inode不变、缺失补发、普通文档0600；open与fstat间替换、持续替换上限、非法文件与fd关闭；初始终态／SQL认领前独立连接终态／新代次／清理中终态不覆盖，不重复清理、不伪造释放，局部blocked首次原因与健康补位。
- `ProjectVerifier`：独立 Docker 正例／反例、程序超时与基础设施错误区分；控制端 umask 不影响 UID 1000 读取候选。
- `deploy/v3/run_local_verification.py --manifest <清单> --project-iterations-only`：合成 CLI 经过真实 Scheduler、driver、会话、清理和 Docker 验收的两步闭环。不得当作真实模型能力证据。
- `deploy/v3/run_local_verification.py --manifest <清单> --project-scheduling-only`：真实 Docker／driver／tmux 中两个 CLI 重叠、冻结 A 时 B 继续、同 Run 两步及 60 秒真实 timeout 后只补剩余一步；Tasks 两 CLI 和既有 passthrough 长连接跨补位／清理保持。多个验收入口顺序创建独立网络，避免测试子网竞争。
- `deploy/v3/verify_stack.py --manifest <清单> --browser --project-iteration`：真实 UI/API/SQLite，目录等待与重启保留、XSS、SSE 状态保持、1280/390px 明暗主题。
- `--project-scheduling-only`还须验证定向局部阻塞后兄弟及原队列后续项目继续。`--project-catalog-only --evidence-dir <新目录>`为可选100×20长测，保持默认10秒稳定等待并独立对账；部分运行不能记为全库通过。中断先停止本次标签下的写入容器，再清临时目录，保留证据及精确清理结论。
- 原 `--run-boundaries`、`--topic-followups` 分别回归；新管理桥运行 `cargo fmt --check` 与 `cargo test --locked`，保留内部路径拒绝断言。

## Scenario: 内容 schema 2 的真实项目多场景任务与 policy 3

### 1. Scope / Trigger

- 修改 `project_scenario_content.py`、`project_scenarios.py`、`project_evaluation.py`、`project_scenario_usage.py`、`project_review_runtime.py`、`project_native_regression.py`、原生验证器、场景 API／页面或正式内容时适用。账号角色、租约、唯一凭据所有者仍遵守 account-runtime-v3；旧线性模式按前节版本读取。
- 当前源码内容为 `real-project-scenarios-v37-en`：保留原10项目／45场景／107任务，三个阶段分别新增30仓／126场景／244任务、30仓／134场景／192任务、30仓／121场景／183任务，合计100项目／426场景／726任务，其中689个非修改任务、37个修改任务。第三阶段新增180个非修改任务、3个修改任务；数值来自实际manifest，不是未来阶段的固定配额。本地内容通过不代表已部署。任务类型固定 `understand/consult/diagnose/plan/modify`，不要求每项目20步。内容就绪、本地模拟机制、真实模型完成及生产部署分别计数。

### 2. Signatures

```python
ProjectIterationManager.create_batch(account_id, name, project_keys=None, policy=None, scenario_entries=None)
initialize_scenario_schema(connection) -> None
normalized_scenario_policy(values, project_count, account_limit) -> dict
ProjectVerifier.verify_native(candidate, project_root, specification, environment_root, profile,
                              *, answer='', regression=False) -> dict
ProjectScenarios.finish_captured_quota(run_id) -> bool
observed_model(directory, response, session_id) -> str
serial_review_limits(memory: str, swap: str = '0') -> tuple[int, int]
ProjectReviewRuntime.pending(account_id: int | None) -> bool
ProjectReviewRuntime.serial_state(row: dict) -> dict | None
ProjectReviewRuntime.serial_layout(row: dict, cli) -> dict
ProjectReviewRuntime.prepare_serial(job: dict, cli, layout: dict) -> None
ProjectReviewRuntime.restore_serial(job: dict) -> None
ProjectReviewRuntime.clear_serial(job: dict) -> None
_suite_paths(suite: dict) -> tuple[Path, Path]
_bind_source(project: Path, import_root: Path, cleanup: ExitStack, *, console: bool = False,
             distribution: tuple[str, str] | None = None,
             executables: list[tuple[str, str, str]] | None = None,
             entry_points: dict[str, dict[str, str]] | None = None,
             license_expression: str | None = None,
             project_urls: dict[str, str] | None = None,
             console_scripts: dict[str, str] | None = None,
             metadata_fields: dict[str, str] | None = None) -> dict
_subtest_results(reports: list[dict], node_ids: list[str]) -> list[dict]
_subtest_contract(subtests: list[dict], format: str | None = None) -> list[dict] | dict
_subtest_evidence(directory: Path, subtests: list[dict]) -> dict
_process_pool_workers(workers: int) -> Iterator[None]
_fixture_aliases(baseline: Path, project: Path, suite: dict) -> list[dict]
_build_native_extension(project: Path, suite: dict, environment: dict, evidence: Path, timeout: int) -> dict
_system_libraries(specification: tuple[str, str]) -> list[dict]
source_snapshot_ignore(directory: str, names: list[str]) -> set[str]  # deploy/v3/manage.py
_public_source_directory_digest(root: Path) -> str  # deploy/v3/manage.py
restore_upstream_checkout_bytes(root: Path) -> list[str]  # deploy/v3/manage.py
```

受控回归 CLI 为 `project_native_regression.py --project <SUITES中的key> --baseline-root <原版> (--freeze-baseline-contract <新合同> | --contract <冻结合同> --candidate-root <候选>) --evidence-dir <空目录> [--timeout-sec 600]`，超时范围为1～1800秒。校准与候选回归互斥，不能覆盖既有合同或非空证据目录。

| API | schema 2 内容的公开契约 |
| --- | --- |
| `GET /api/project-catalog` | `content_schema,version,digest,scheduling_defaults,projects`；项目有 `scenario_count/task_count`。 |
| `GET /api/project-catalog/{key}` | 一个项目的白名单摘要，附场景及任务 `id/kind/goal/requires`，隐藏 prompt／分支／rubric；不返回目录顶层 version/digest。 |
| `POST /api/project-iteration-batches` | 原账号／名称／project_keys及严格整数策略；`scenario_entries` 为 `{project_key:{scenario_id:entry_id}}`，省略选固定默认入口。DTO `exclude_unset=True` 后依内容版本归一默认。 |
| `GET /api/project-instances/{iid}` | `content_schema=2`，场景、选中任务、结果／phase、candidate/review预算、实际Run与评测状态、逻辑plans；不复用 next_step_index 表示任务进度。 |
| `GET /api/project-instances/{iid}/scenario-tasks/{tid}/attempts` | 实际业务尝试及 candidate／review 执行；tid 是数据库任务ID，与稳定 task_key 分开。 |
| `GET .../scenario-tasks/{tid}/artifacts`、`GET .../file` | 可选 `evaluation_id` 定位固定回答；file另需清单内 `path`，有界读取；强制归属 iid/tid。 |
| `GET /api/project-instances/{iid}/usage` | `tasks` 按 candidate/review 角色累计、`by_kind` 分类；输入／输出／缓存读写分别统计，已知小计带覆盖标记，全未知为null。 |

沿用原项目资源前缀、Cookie、SSE与桥白名单，不增加鉴权豁免。新持久表均由 `init_db()->initialize_scenario_schema()` 幂等创建，不改写旧行／ID：

| 新表 | 关键身份／持久边界 |
| --- | --- |
| `project_scenario_instances` | instance＋scenario_key唯一；entry_key、独立workspace/session、seed与当前accepted checkpoint。 |
| `project_scenario_tasks` | 场景＋task_key唯一；selected、kind、phase、turn_no、attempt_count、infra_recoveries、input／accepted checkpoint。 |
| `project_task_attempts` | task＋attempt_no唯一；实际消费才创建，最多3，结束原因独立记录。 |
| `project_task_executions` | run_id唯一；task/attempt/plan、candidate/review、generation、session、delivery及review逻辑尝试。 |
| `project_execution_sources` | execution＋quota_attempt＋source唯一；逐代原生起止、start_permitted、work文件及真实released_at／execution_error。 |
| `project_task_deliveries` | task＋phase_key唯一；固定prompt摘要、真实input_key和consumed_source_id，不盲重发。 |
| `project_evaluation_jobs` | source＋response_key＋version唯一；回答／输入／rubric／candidate摘要、evidence_json、机械／语义结果、评审恢复及回答预算。 |
| `project_work_segments` | source＋segment_seq唯一；boot／monotonic、reserved／confirmed、高水位与settled／uncertain。 |
| `project_scenario_plans` | 场景至多一个未结束逻辑计划；明确task_ids／passed_ids，不按数组前缀猜范围。 |

### 3. Contracts

**内容与离线环境**：内容 schema 2 项目必须固定上游HTTPS GitHub URL、40位commit、seed内许可、seed_digest、environment及可变scenarios/tasks。entry列必要task_ids；branch只选固定披露材料／setup／同场景activate_tasks。requires精确声明answer或code依赖，首版仅同场景无环，code仅引用modify。公开materials与控制verification隔离；setup来源固定，目标仅app/。每项目源码对象上限128MiB／10000文件；环境wheel独立存放，逐制品hash、精确requirements及Python版本冻结，business/regression资源分开，不能把venv放进源码快照。

**材料与评审证据**：首问尚未消费的隐藏复现或业务决策，不能提前写成通用 rubric 的具体事实，也不能无条件放入 `source_evidence`。披露判断依据实际消费对话和公开源码。`allow_candidate_evidence=true` 不仅允许引用候选文件，还会让 satisfied／violated 判定必须给出证据；只读任务没有候选修改文件，不能以空静态 evidence 加该 flag 构造无法满足的规则。确有文件交付的修改任务仍须按冻结清单引用 `candidate:<path>`。

**模型输入与页面语言**：正式内容的 `task.prompt`、`branches[].when`、rubric 的自然语言规则、业务材料中的指令与说明，以及候选的材料包装、quota／timeout／infra 接续、补充与修正、`review_prompt` 均使用英文。`title/category/description`、场景及任务 `goal` 是中文页面字段，`scenario_summary(..., include_tasks=True)` 的浏览项目与路线投影保持中文。固定业务字面、原始代码、报错、帮助与证据原文不翻译；例如英文首问要求 status 为 `已校对`，不能把该验收值替换成英文，也不能仅凭出现汉字拒绝原始资料。语言修正发布新内容版本与评审版本，由内容树重算摘要；不原地改写已冻结的问题、回答或历史发布。schema 2 的通用结构校验不自动推断语言，正式内容需另行逐项核对指令与业务数据边界。

**发布与状态**：新批次paused且只写元数据，首次实际启动才物化场景独立工作区／候选session。同项目至多一个候选写入；逻辑计划默认2任务、通过5任务或局部收口轮换，活动池默认3，共享并发最多2并受账号真实容量约束。任务通过、代码接受、场景收口与批次运行完成分开；只读任务不会创建代码检查点，completed可包含明确失败／耗尽／受阻。

**新任务输入与代码依赖接受来源**：未声明 code 依赖的新任务从场景已接受状态开始；尚无接受代码时使用初始基线及启动前冻结的入口材料。旧任务未接受改动封存到交接备份，不进入新任务输入；同任务 ready 标记接续保留当前半成品。code依赖必须对应前置task的passed与accepted_checkpoint_digest，并定位该摘要的passed评测作业。`project-artifacts/task-inputs/<task_id>/code-dependency.json` 保存dependencies作业ID→摘要、base_checkpoint_digest、base_checkpoint_job_id及ready／replacing状态。多依赖须沿评测evidence中的 `parent_code_job_id` 属于同一已接受父链；不能用摘要相同折叠回退后的不同分支，更不能猜测合并。工作区非所需版本时先保存原现场，再从已核对对象物化；交接中断受阻。候选evidence冻结 `parent_code_digest,parent_code_job_id,input_checkpoint_digest`；授权范围验收使用该作业冻结输入，不能使用后来变化的任务checkpoint代替。

**严格释放与接受**：真实父链／输入消费／source/generation核对后定向冻结、封存回答和候选，并先持久waiting_release与complete决定。driver正常退出，精确来源严格释放后才排机械验收；需要评审时经原Scheduler／normal额度及 `claim(shared_cli=False, exclusive=False)` 创建project_review，同账号其他CLI互斥且不排空API，候选不持名额等待评审。评审结果封存后也须严格释放，CAS核对父generation／状态、最新作业及未收口执行后才接受或披露／有限修正。重复候选／评审通知重放已落决定，不重复freeze；迟到旧代结果不推进。完整输出遇quota／重启只续验收，不再重问；旧Run终态保留。

**同实际模型评审**：场景冻结原账号身份、CLI版本、effort和配置execution_model（空串也是合法配置快照）。候选封存时从已核对主assistant精确原生位置读取 `message.model`，存evidence `resolved_model`；私有评审用该值作 `CLAUDE_MODEL_OVERRIDE`，评审结果再核实际原生模型完全一致。禁止因CLI默认／全局设置变化静默换模型，也不调用模型清单探测。评审使用独立session／PID／mount／HOME／input／日志，原账号netns、AT-only副本和唯一刷新所有者；候选无法从其共享目录读取隐藏材料。

**串行资源交接**：新环境不预留常驻评审份额；`serial_review_limits` 返回普通三角色预算中CLI剩余RAM，MemorySwap与Memory相等，额外swap只归固定CLI。旧schema1预留布局核对原固定CLI的实际限额，仍可借用原账号总预算扣除network/sender后的RAM，固定CLI配置不改写。评审CPU沿原固定CLI的有限NanoCpus，公共角色合计不得超 `V3_ACCOUNT_CPUS`（默认2）；私有容器仍为UID1000、根只读、PID128、tmpfs64MiB。

评审在环境锁内认领非共享CLI并确认无未知进程，先持久意图再停止固定CLI，reload确认为exited/dead/created后才能创建私有容器。清理始终先停止并核验私有容器，再恢复同一固定CLI并核验画像／公共角色，最后退租、删除交接记录及执行记录。网络和sender全程保持，API可继续使用原发送连接。普通CLI从串行状态检查、画像探针到认领连续持同一环境锁，版本安装在锁外；共同认领边界对全部同账号活动批次的当前generation、evaluating且review_ready/review_queued工作优先，paused和旧代不阻新作业。

`runtime/execution.json` 保存非共享评审及 `resource_mode='serial-v1'`；历史无mode评审仍按旧清理路径读取。root私有0600的 `runtime/project-review-serial.json` 用atomic_json/fsync发布：

| 字段 | 归属与边界 |
| --- | --- |
| schema、environment_id、environment_generation、container_id | schema=1，绑定原固定CLI及当前环境代次 |
| source、run_id、review_intent | 绑定本次执行；intent为64位十六进制摘要 |
| phase、cli_was_running | prepared/cli_stopping/cli_stopped/review_running/review_stopping/cli_restoring；本次负责恢复为true |
| cli_limits | 原Memory、MemorySwap、NanoCpus、PidsLimit有限正整数快照，恢复前核对实际配置 |
| review_limits | 本次Memory及MemorySwap有限串行预算 |
| review_container_id | 创建ACK可用时写入；ACK丢失按原intent标签找回 |

有效交接期间 `ensure` 只提供原API环境，不唤醒固定CLI；CLI准备返回RuntimeBusy等待。恢复失败、未知running孤儿、代次／限额冲突或缺少执行登记保留记录和占用；串行执行仍登记但交接记录丢失时，只有原CLI实际运行且私有容器停净才允许退租。回退前必须停净私有评审并完成原CLI恢复；旧版缺少串行协议，不能删记录或在回退后承诺普通布局仍可评审。

评审包冻结完整已消费当前任务对话、回答、rubric、真实源码事实、程序结果及实际交付candidate_files（逐对象摘要核对），总上限512KiB，超限受阻不截断。输出最多64KiB的单JSON，身份字段为 `job_id/task_id/turn_no/response_digest/basis_digest`；decision限disclose/pass/fail/uncertain，逐criterion恰好一次，证据必须在冻结清单且candidate引用获显式许可，反馈限白名单。程序失败不能被语义覆盖；合法uncertain直接受阻，不重抽。modify仅在native及适用regression通过后接受；声明semantic的交付要求还须评审。共用解析器的展示与冗余规则字段兼容边界见[验收反馈与自动复验](#scenario-验收反馈与自动复验)。

原所有者刷新待办位于 `project-review-owner-refresh/<account_id>.json`，绑定 request_id／原身份／environment_id与generation／被拒AT摘要。旧身份、旧环境或原所有者已发布不同且未过期AT的请求不阻新准入；新请求把旧记录归档为superseded并保留previous_status。当前被拒AT的error仍阻断；双参数 `refresh(account, request)` 在原owner锁内重读身份／环境／request_id，迟到写回用request_id CAS，不能刷新或覆盖新请求。私有作业未停净时保留holder及创建意图，未知running孤儿阻止第二评审。

**预算与恢复**：policy3候选 `timeout_sec=600`、`task_budget_sec=1800`；业务首轮加最多2次继续／修正，实际输入消费才扣，正常澄清与额度接续不增业务尝试。`review_timeout_sec=180` 限同一逻辑评审跨Run/source累计；同回答最多首次＋1次错误重评且回答总上限为其2倍；`review_budget_sec=720` 限任务全部回答轮次累计。单次领取三层剩余量最小值，infra恢复对业务任务／冻结回答各最多2次，不重置余额。候选及任务累计、任务review累计公开范围60～86400秒；review单次60～600；实际剩余不足公开最小值也不能向上补发。boot＋monotonic片段启动前预留，退出按真实高水位结算，尾段不明保留预留且受阻，不伪造耗时或清零。token按精确source字节区间、session/message去重，统计complete与任务passed不同。

**原生验证**：`verify_native` 在同批account镜像、UID1000／network none／只读根／无账号凭据内执行；源码、baseline、offline、控制脚本与输入只读，临时运行树隔离。离线准备阶段证明与业务时限分开；pip使用`--no-index --no-deps --no-compile`，避免重复编译缓存占满受限tmpfs，不缩减实际依赖或测试。环境error只本地有限重试，不投递业务修正。工程回归从固定baseline恢复上游适用集合，核Python／插件／baseline与节点contract，业务通过后真实执行，不只检查声明或退出码0。新原生验证的并发名额覆盖容器清理；清理无法确认时保留阻断记录。内容复制、Docker忽略与源码快照须一致；Typer及Decouple固定公开.env、Docutils固定.log与target夹具按精确路径及文件／完整目录摘要保留，未知文件和链接仍拒绝，不放开其他环境文件或构建产物。

**原生套件布局与校准**：`SUITES.package` 是可导入模块名，`implementation_dir` 默认按模块点号转路径，`import_root` 默认为 `.`；两路径必须相对、无 `..`，实现路径只允许导入根拼接模块路径或对应`.py`单文件。Jinja 固定 `package=jinja2,implementation_dir=src/jinja2,import_root=src`；只叠加实际实现，拒绝实现及父目录链接，恢复baseline测试／配置并拒绝新增pytest控制声明。`test_roots`显式指定实现包内的固定测试与数据，候选不能替换PETL／Toolz／JSONschema／Cerberus包内验收。实际import必须落在受控测试树。新套件在目标镜像收集非空、无重复的真实节点并完整执行，冻结schema／project／baseline_digest／python／plugins／nodes；候选逐节点及结果精确匹配合同。旧三个suite保留原硬固定计数和默认布局。每个新增小批的私有回归副本与当时共享实现逐SHA一致，后续新增套件不原地升级此前已冻结的私有脚本。

**原生框架与补充入口**：`framework`缺省为pytest，Python-Markdown／Docutils／Icecream使用上游unittest发现，Dpath使用真实nose2发现、结果事件及官方JUnit插件；不能以unittest发现替代nose2的函数测试。冻结合同额外保存框架与原始skip原因，结果、导入来源、XML逐项核对，夹具异常与未知结果不能当通过。ConfigObj的`supplementary`分别执行上游脚本及模块doctest入口，保留原初始化、逐例source／want摘要、flags与结果，不能只调用testmod而漏掉脚本初始化。动态导出示例从隔离原版解析并恢复到候选；类方法写回底层函数，Toolz动态文档描述符只更新classval，保留实例行为。PETL的收集阶段skip单列`collection_skips`冻结身份／行号／原因；JUnit元素数等于主项加收集skip，不混为执行后的skip。

**固定工具、元数据与夹具**：Click离线less工具先核制品路径／SHA，再排他复制到本次独占venv；`distribution`只生成已核原版名称／版本的dist-info，`entry_points`与`license_expression`从冻结pyproject读取，不安装第二份候选实现，退出清理。Docutils的`cwd`为固定相对测试目录；`fixture_aliases`只把已核Git链接blob目标在私有运行树复制成普通数据，原seed保留目标文本。别名、目标、父目录越界或链接均拒绝；不能修改原生预期数据制造通过。

**第二阶段原生入口与元数据**：Simplejson沿官方`simplejson.tests._cibw_runner`执行C／纯Python两轮及index.rst；在本次`/work`私有树真实编译候选扩展，并逐例核编码、解码、扫描接线及扩展来源。节点仍恰为id／kind／outcome，身份以实际mode＋原始ID区分，`unittest_contexts`保留并精确比对；官方skip表只按身份排序，不改变其集合。Marshmallow的固定两项当前时间参数仅按原参数位置规范ID，原值另存`parameter_identities`；不改输入或时钟。Babel真实重复doctest节点按occurrence区分，原始身份／次数／父对象保留在`duplicate_identities`；目录收集skip仅允许已列目录且存在原conftest。sqlparse仅允许逐名冻结的原版非strict XPASS，身份增加、丢失、替换或新XPASS均拒绝，候选节点结果仍必须逐项匹配。

私有分发可从固定pyproject读取脚本／链接／描述；legacy Babel则显式冻结真实入口字典，不猜测不存在的`project`表。命令排他创建于独占venv，候选实现仍来自受控`.pth`；Summary／Author-email仅允许非空单行白名单值，Project-URL保留原声明顺序。Tk共享库仅从已核离线制品逐SHA读取，版权随制品保存，不改系统安装。Dateutil保留warnings-as-errors，通过实际pytest-cov登记no_cover；时区仅取冻结离线tzdata。业务与回归预算分别实测，Packaging的1024MiB／600秒回归不扩展其256MiB业务或账号容量；旧四十仓冻结私有runner不原地更新。

**第三阶段原生扩展与只读夹具**：Pyrsistent、Python-Constraint和Wrapt只在本次`/work`受控树从实际候选C／Python源码强制构建；setup、配置、测试和构建脚本从固定baseline恢复。`extra_implementation_files`仅允许原版已有的精确路径，拒绝缺失、链接、越界及pytest控制注入。`native_modules`逐个核当前解释器EXT_SUFFIX、实际路径和SHA，不能以同名Python模块冒充扩展；另核Pyrsistent／Wrapt默认对象确实绑定C实现。Cython只读docstring与原文相同时不重复赋值，变化仍须恢复或拒绝。Pendulum的固定Rust原件明确`rebuilt_in_current_run=false`，本轮分别核Rust绑定与完整Python模式，不声称重建Rust或允许未重建的源码修改。

`_system_libraries`只接受固定清单SHA及`artifacts/tk-libs`、`artifacts/gettext-libs`、`artifacts/graphviz-libs`内同一目录的普通成员，逐成员SHA校验，拒绝跨目录混用和链接；LD_LIBRARY_PATH来自实际已核清单父目录。Graphviz工具、插件、对应版权及完整源码原件随环境封存。仅Pendulum的两条固定时区fixture启用`fixture_symlink_semantics`：核原Git目标文本、内部普通目标及SHA后，在独占私有测试树恢复相对链接；正式seed及只读baseline保持原link blob文本，其他别名仍复制普通文件。不得创建外部目标或链接父目录。

**dotenv CLI与第二批套件**：dotenv固定 `package=dotenv,implementation_dir=src/dotenv,import_root=src`；TOMLKit／sqlite-utils／Tenacity导入根为`.`。sqlite-utils显式启用已冻结Hypothesis分发的 `_hypothesis_pytestplugin`，不依赖关闭autoload后消失的隐式插件。Typer与dotenv的子进程绑定只写`/work`下本次独占venv的纯路径`.pth`，purelib须位于该venv，系统或外部共享解释器拒绝。dotenv额外以排他创建生成该venv `bin/dotenv`，固定目标 `dotenv.__main__:cli`、0755；已有入口或链接拒绝覆盖。路径文件及新入口注册退出清理，直接CLI测试实际导入受控src；不能用安装发行包或仅`python -m`代替原生可执行入口。

**真实子测试合同**：仅显式`subtests=True`的套件冻结子项；pytest取真实`SubtestReport.context._to_json()`，unittest取原生addSubTest／addSkip回调。条目为`parent_nodeid,ordinal,when,context,outcome`，context恰为`msg`（null或字符串）及`kwargs`（字符串键／序列化字符串值）。同父节点按实际出现ordinal保留重复context，不折叠；仅允许已收集主节点的call阶段。schema1合同新增可选subtests，旧suite保持原行为；启用套件的候选合同缺少／为空须拒绝，候选完整子项与冻结集合逐项相等，失败／xpass不能被父项passed遮蔽。unittest子项跳过可能省略父项addSuccess，须保留父项已执行与各子项skip；子项失败仍使父项失败。主节点、子项、收集skip和JUnit元素分别对账，不能用suite汇总tests属性替代。Tenacity真实185主项／15子项、XML185元素及汇总200是独立口径，不重复计数。

**大集合子项表示**：`subtest_contract`未指定时继续冻结及输出原完整列表。显式`sha256-v1`保存完整有序记录的数量及SHA；仅SQLGlot使用`sqlglot-subtests-v1`，保留完整父项、阶段、上下文、结果和重复次数，只移除观察ordinal并排序多重集。唯一地址规范化限`tests.test_expressions.TestExprs.test_convert`中完整匹配的PointClass默认repr；SQL十六进制字面、其他msg及kwargs不得改写。摘要头为`format,count,sha256`，全部实际子项仍先经过既有校验及合法结果检查，再逐SHA匹配，不能采样、去重或忽略失败。

原始观察全部写入私有`subtests.json.gz`，元数据为`file,sha256,count,bytes,expanded_bytes,observed_order_sha256`；拒绝覆盖。校准时将完整原件及SHA封存进项目verification，运行结果只返回摘要头和原件元数据，保持4MiB合同及2MiB产品输出上限，不把完整大列表塞进stdout。独立审计须同时核冻结控制器、完整基线原件、数量、父项及全量摘要，旧列表比较不变；从已核源码字节加载控制器，避免冻结输入中的pyc读写。SQLGlot原生发现和loader不改，只将缺省或显式None的ProcessPoolExecutor默认并发设为2，显式非None参数保持并在finally恢复构造器；完整原测试仍全部执行。其业务512MiB／30秒、回归3072MiB／360秒是当前镜像实测值，不增加账号资源或平台上限。

**上游文件表示与运行取证**：来源清单同时记录Git blob及mode；内容快照禁止真实symlink时，上游文档link blob可按原目标文本字节存普通文件，明确表示差异并保留完整许可／文档原件，不能伪称原类型未变。普通上游执行位在源码Git／Docker交付保持；既有快照只按路径／字节／大小封存并统一物化0644，不承诺模式保真。TOMLKit固定测试子模块独立来源／许可、完整展开，不能用空目录或Python3.12 TOML1.0解析器否决TOML1.1语料。私有评审挂载检查先将runtime私有根按data相对路径映射到host_data，再与Docker Mounts.Source双向比较父子重叠，不能跨命名空间直接比路径。source.created_at／released_at包含启动配置及释放后取证收账，不能当精确holder占用区间；实际工作窗口、进程清理、holder采样和源码门禁分别报告，缺逐holder事件不得声称完整时序已重建。

**Git 字节保真**：正式 `project_library/**` 使用 `-text eol=lf`，本任务冻结研究证据使用`-text`。嵌套上游`text=auto`继承LF导出规则，显式binary仍保留字节；不修改上游属性文件。Dateutil的NEWS／docs/make.bat另被上游显式指定CRLF，普通Git检出可能转换。官方CI使用manage.py build，该入口只在临时源码副本调用`restore_upstream_checkout_bytes`：仅这两个精确路径的已核原blob SHA或整份CRLF转换SHA可接受，全部预检后恢复原blob字节；未知修改、文件或父目录链接拒绝，执行位不变，缺少整个项目时不增文件。Git证据沿真实checkout-index后使用相同恢复函数，分别记录`raw_checkout_bytes_equal`与`production_source_restoration`，不得把恢复后相同说成原始检出相同；Docker COPY验证正式恢复后的完整树。

Dynaconf的76份和Flask的一份固定公开.env原件沿既有精确路径／SHA与Docker逐文件放行列表交付，不放开其它环境文件。python-frontmatter固定`seed/library/AGENTS.md`按来源清单精确保留，本地工具AGENTS.md仍忽略。提交前从索引导出内容，按上述生产恢复规则逐文件核清单／字节／执行位，并重新加载`ProjectLibrary`比较摘要；工作区校验不能替代Git导出校验。上游空白、原始帮助输出及补丁上下文原样保存，原创实现仍做空白检查。

### 4. Validation & Error Matrix

| 条件 | 结果与边界 |
| --- | --- |
| 新内容省略预算／显式合法预算 | 依内容选择600等新默认／按原值冻结；不能被DTO旧1800覆盖。bool/string/float/null预算与未知字段拒绝。 |
| 旧内容提交新专用预算或入口字段 | 明确拒绝；旧无schema／policy2语义保留。 |
| 当前catalog损坏，历史release完整 | catalog／新建503，历史批次／回答／文件仍按固定release可读。 |
| 缺依赖、跨场景依赖、环、code引用非modify | 内容准入拒绝；未选分支不计本次必要任务分母。 |
| code依赖无接受作业／父链不一致／交接replacing | 保留现场并受阻，不以当前cwd或相同摘要猜测继承／合并。 |
| 候选完整但未严格释放、评审未释放 | 保持等待，不能接受、重问或开始相冲突执行；容量1也不持候选holder等待评审。 |
| 已有CLI／有效交接时的评审准入，或待评审时普通CLI认领 | admission等待且blocked=false／RuntimeBusy，不把竞争标为业务失败；已认领作业可完成。 |
| 固定CLI停止未确认、未知运行评审或原配额／代次冲突 | 不创建下一私有评审或恢复CLI，保留占用与持久意图。 |
| 交接记录丢失且固定CLI仍停止 | ValueError，保留执行记录；不能假报恢复或释放。 |
| 完整候选／评审输出后quota或重启 | 只续收口与验收，保留Run中断事实，不重复模型输入或计量。 |
| 新source未许可／许可后尾段不明 | 前者有持久证明可结算未投递；后者保留预留并受阻，不盲给新预算。 |
| 原生准备异常／业务断言或已进入业务后的超时 | error／failed，前者本地有限重试，后者可用有限业务修正。 |
| suite 模块／相对路径不匹配、实现或父目录链接、候选错导入安装库 | 拒绝回归；候选源码违规为 failed，不借环境重试接受。 |
| 冻结合同来源不符／Python或插件漂移／空节点或节点结果不符 | 拒绝；环境漂移须重新校准原版，候选不能靠删测试或退出码零通过。 |
| dotenv系统或外部venv／已有CLI入口；Tenacity缺失子合同、非法父节点或子项不匹配 | 拒绝；不覆盖未知入口，不以主项pass或XML汇总替代子项证明。 |
| nose2函数用例遗漏／框架漂移、包内测试被改、补充doctest或收集skip合同缺失／变化 | 拒绝；必须沿原入口完整校准，不能靠换发现器或少跑节点通过。 |
| 固定工具SHA不符、源码别名目标越界、公开夹具多文件／改字节／换链接 | 拒绝；不借精确原件例外放入其他工具、配置或构建产物。 |
| 官方双模式缺一轮／扩展来源或接线不符；重复doctest身份或冻结原始XPASS变化 | 拒绝；不能折叠次数、缺失节点或让新XPASS借原版例外进入。 |
| 额外C实现缺失／链接／越界，原生模块实为Python文件，离线库跨目录或SHA不符 | 拒绝；只允许固定构建控制、真实本次扩展及精确只读库清单。 |
| Pendulum固定时区别名变化、内部目标缺失或沿链接越界 | 拒绝；只在私有测试树恢复已核相对链接，正式快照不创建链接。 |
| 大集合子项缺失、摘要／数量／重复次数／结果不符，完整私有见证或控制器被改写 | 拒绝；不得用摘要表示规避全量检查或提高JSON／日志上限。 |
| Dateutil已核CRLF检出／未知修改或链接 | 前者只在交付副本恢复已核blob，后者拒绝且预检失败不写任何文件；不能通用换行归一化或改上游属性。 |
| 评审实际模型不一致／格式或身份错误 | 评审error，最多一次错误重评，不算业务失败；合法uncertain直接blocked。 |
| 次数或累计预算先到上限 | exhausted／最终failed或评测blocked，独立任务继续，真实后继依赖受阻。 |
| 停止、旧generation、非最新作业迟到结果 | 留历史不接受；认证／真正严格清理失败沿原强门禁阻断批次。 |
| artifact跨实例、非清单path、对象摘要不符 | 拒绝读取或接受，不回退到当前目录；预览最多65536字节。 |

### 5. Scenarios and Examples

- 正常：创建 `{"account_id":1,"project_keys":["python-frontmatter"],"scenario_entries":{"python-frontmatter":{"FM-S02":"diagnose_only"}}}`，服务端生成policy3和600秒默认；FM-S02按diagnose_only入口选择任务，其余场景使用默认入口。正确无BUG／信息不足／方案可通过而不增加代码checkpoint。
- 恢复：前两任务passed、第三任务半途timeout时，旧Run保持timeout，新Run复用第三任务session与半成品，消耗原剩余任务预算；若回答已封存则只续原验收，不新建一次业务询问。
- 串行正常：1536m RAM＋2048m额外swap的新登录保存同环境；network256m／sender128m保持，固定CLI为Memory1152m／MemorySwap3200m。停止CLI后评审使用1152m／1152m，评审停净后恢复原CLI；旧预留CLI640m仍保持原限制。
- 错误用法：只在画像检查前看一次交接标记，随后无锁调用探针和claim，评审可插入停机产生Docker409。正确处理：状态检查、画像exec及认领共同持环境锁，忙碌沿RuntimeBusy重排队；不要靠吞掉409掩盖竞争。
- 代码依赖边界：A接受为作业10、B接受为作业11；以后另一作业把源码回退成A相同字节，不能因此声称B与该回退分支有共同接受父链。使用parent_code_job_id逐作业追溯，无共同链则受阻。
- 错误用法：配置execution_model为空便让评审使用当前全局默认，或给review另开供应商调用；正确做法是沿原Scheduler，冻结候选实际message.model并在review原生日志再次核对。
- 错误用法：CLI success、问答passed或批次completed都算代码成功；正确做法是分别显示执行、任务、代码接受及收口分布。固定测试／模拟CLI通过不计真实模型完成数。
- 正常与边界：TinyDB 的两个修改位于不同场景，分别从原版开始；Jinja M02 声明本场景 M01 的 code 依赖，必须承接真实已接受作业。37 个唯一任务的默认与分支试跑可形成66条路径、10次接受，仍只计37任务与6个唯一修改目标。
- 错误用法：把 `src/jinja2` 当模块名或使用已安装的 Jinja 代替候选。正确配置模块 `jinja2` 与相对导入根 `src`，并以实际 `__file__` 和完整节点合同核对；只读咨询没有候选文件时，移除不适用的候选证据 flag，保留可由公开资料支持的规则。
- 正常与边界：第二批50唯一任务形成114路径／16次接受，仍只计8唯一修改；八修改从各场景原版独立开始，只有TK-P01真实消费TK-D02的answer。四仓D01按实际请求披露，材料不足合法结案；不能把澄清或分支另计任务。
- 错误用法：Tenacity的200汇总当200主节点，或source收账三重叠直接当三个holder。正确做法是185主项＋15真实子项分别核合同，并按实际工作、严格清理和门禁证据说明并发口径及事件留存限制。
- 正常与边界：第一阶段30仓新增244唯一任务，其中9修改；15批mock会重复覆盖入口与分支，重复路径和代码接受次数不增加任务数。完整Git／Docker导出11374文件一致，原3069文件字节及执行位保持；证据见本阶段`research/delivery-first-thirty.json`，不代表真实模型或生产上线。
- 正常与边界：第二阶段30仓新增192唯一任务、8修改，15批mock覆盖562路径／22次接受，仍只计192任务／8唯一修改。完整原生98,924主执行分别为98,459通过、400 skip、64 xfail及1原始XPASS，doctest已含、subtest和收集skip另列。正式22,623文件在Git导出沿生产恢复后与Docker COPY一致，旧11,373文件保持；原始Git检出两份Dateutil CRLF差异明确记录，不代表真实模型或部署完成。
- 正常与边界：第三阶段30仓新增183唯一任务、3修改，15组mock为567路径，其中18条是既有Arrow控制重跑，新增任务路径549条；9次代码接受仍只计3个修改目标。完整原生85820主项为77533通过、6537原skip、1750原xfail，24183子项另列。32188文件经同生产恢复及Docker COPY核字节／权限一致，旧22622文件保持；8960项页面检查和494截图只证明本地模拟机制。
- 错误用法：把SQLGlot的摘要头三个字段当成三个子项，或删除重复context压缩合同。正确做法：1500主项与21780子项分别核实，完整原始观察私有归档，按固定规则对全部记录计算SHA；三组产品链真实回归均须匹配同一合同。
- 错误用法：Dpath以unittest发现得到少量类用例便报完整通过，或将PETL的12个收集skip混入923主项。正确做法是实际nose2完整79项；PETL分别记录923主项与12收集skip，JUnit为935元素。数值只适用于冻结提交与当前环境。

### 6. Tests Required

- 内容／历史／DTO：`test_project_scenario_content.py` 覆盖可变任务、非紧邻DAG、入口可达、隐藏投影、wheel损坏／链接、注册复开摘要、坏catalog历史可读、新600／旧1800默认及显式值／非法null；旧schema夹具回归保留。
- 语言修正：穷举正式首问、分支、材料说明、rubric 与运行时提示，核对英文语义及原授权／验收约束；比较修正前后的中文 `summary(include_steps=True)` 完全相等，新旧内容分别 install／复开仍按各自摘要读取。seed、固定业务输入、原生检查和 wheel 字节保持不变；Unicode 测试夹具与证据原文不作为必须翻译的正式指令。
- 状态／恢复／父链：`test_project_scenarios.py` 覆盖实际消费认领、澄清不加attempt、3次上限、工作高水位／崩溃预留、review三层预算、候选与review严格释放、完整输出quota／重启只续验收、迟到结果、文件交付进review包、局部轮换／分支激活、代码依赖恢复与不兼容／相同字节回退分支、实际模型漂移不扣业务修正。
- 协议／用量／私有运行：`test_project_evaluation.py` 覆盖严格单JSON／错误身份／重复项／未知证据／程序失败不能被pass覆盖、合法uncertain、显式candidate证据许可及缓存字段去重／未知；`test_project_review_runtime.py` 覆盖owner刷新身份、创建／停净／缺失／孤儿、清理失败保留holder及资源份额；`test_project_native_verifier.py` 覆盖准备阶段error、业务exit80为failed、清理前不放slot、合法等价程序提取。
- 串行回归：`test_project_review_runtime.py` 核普通／旧布局不改限额、停止／恢复／退租失败、缺记录及错误代次、同账号竞争与不同账号独立；`test_review_cannot_stop_cli_between_profile_check_and_claim` 固定检查窗口交错，旧实现409、修复后竞争者RuntimeBusy且安装不占环境锁。`test_project_scenarios.py` 核跨活动批次优先及paused／旧代排除。
- 实际Docker：`run_local_verification.py --manifest <隔离验证清单> --project-scenarios-only --scenario-capacity 1 --scenario-failures` 与容量2的 `--scenario-browser` 核新登录同环境、三阶段预算、无候选／评审重叠、私有挂载及原API流。`--scenario-recovery-only` 核真实画像探针与认领竞争、running/exited/missing恢复及缺交接记录阻断；real_model_calls=0，真实OAuth／模型闭环留到部署后独立验收。
- 原生内容：`python3 scripts/validate-project-library.py` 仅静态摘要／当前100-426-726；`scripts/validate-project-scenarios.py --project <key> --task <key> --image <隔离账号镜像>` 真实业务，按需 `--candidate/--answer/--entry/--branch/--expect failed`；`--regression-only` 或 `--with-regression` 使用独立回归资源。保留适用工程目标的原版失败／参考通过／错误候选拒绝、原生完整集合与skip/xfail证据，不用宿主旧基线替代。
- 套件适配：`test_project_native_regression.NativeRegressionTests` 断言 src 叠加恢复原测试／配置、新 pytest hook 拒绝、旧默认不变、父链接与非法路径／模块拒绝、安装库错导入拒绝。目标镜像实际冻结并执行全部节点，再对每个参考候选跑完整适用回归；首批新增原版集合为228／911／81，数字是首批实测记录，不作为后续套件的通用硬编码。
- 第二批适配：同测试类核dotenv受控src／0755入口与退出清理、拒覆盖／系统venv；子测试保留重复context和失败、未知父节点／非call／未序列化值拒绝。当前镜像四仓完整集合为288、1203、1513（1497通过／16冻结skip）、185主项＋15子项，逐参考完整核对；数值是实测，不能硬抄为未来版本通用分母。Git／Docker导出另核来源全集／双SHA、原执行位和link blob表示，私有mount比较核host路径双向重叠。
- 第一阶段适配：同测试类31项覆盖单文件、包内冻结测试、真实unittest／nose2、重复／跳过／失败子项、补充doctest、动态文档描述符、收集skip、离线工具及元数据清理／拒绝边界。当时136项`test_project_*.py`与28项`deploy/v3/test_manage.py`通过；后者核真实上游夹具及未知文件／改字节／链接拒绝。逐仓30原生合同、268业务／回归收据和15批实际产品链审计独立保存；不把本地单测替代镜像内完整原生与业务验收。
- 第二阶段适配：当前原生适配39项、`test_project_*.py`144项、部署30项分别通过。核官方C／Python模式、参数身份、元数据顺序／命令绑定与清理、目录收集skip、重复doctest和唯一原版XPASS拒绝边界；部署核公开.env精确列表及已核CRLF恢复、幂等、模式不变、未知修改／父链接拒绝和预检不部分写入。三十仓204业务／候选路径与15批产品链独立保存；Git证据明确恢复前后口径，沿同生产函数后再核完整Docker交付。
- 第三阶段适配：同类48项包含候选C源码、只读docstring、真实扩展后缀、受控私有链接、库目录绑定、进程池默认值／恢复和大集合完整性拒绝边界；153项项目单测（含该48项）、30项部署测试及最终目录单项回归分别留证。六项审计适配测试基于真实SQLGlot产品结果，拒绝错误数量／SHA／匹配证明、原件／控制器篡改和链接，并核冻结输入文件全集及字节不被写入。完整30仓主集合、170业务控制和15组真实产品链原件独立保存，不以单测代替原生或产品验收。
- 内容评审协议：逐任务及必要披露／无材料路径构造真实 `review_package` 并执行 `parse_review`，核证据标识与候选文件存在性；隐藏具体事实只有实际消费后可用于相应结论。模拟对账同时统计唯一码、路径、披露消费、业务尝试和接受父链，不能把分支或补充材料当作独立任务。
- Git 交付：`git check-attr text`核对冻结数据`unset`、普通代码保持原规则；`git check-ignore`核精确上游例外与本地工具文件仍忽略。被通用规则忽略的其他上游原件，仅在固定Git来源、逐文件SHA／执行位证明后列出精确force-add路径，不宽泛放开目录。用`git checkout-index`导出拟提交内容并按上文同生产函数精确恢复，分别留存恢复前后事实；核文件全集、逐文件字节／执行位及catalog摘要，再沿正式快照过滤器与Docker忽略文件实际COPY核相同集合；工作区摘要不能替代导出证据。
- 真实调度与UI：`deploy/v3/run_local_verification.py --manifest <隔离清单> --project-scenarios-only --scenario-capacity 1`，另测容量2；需要UI与失败恢复时加现有 `--scenario-browser`／`--scenario-failures`。核原Scheduler／driver／SQLite、holder容量、私有挂载与AT-only、超时半成品、仅续验收及页面状态／预算／用量对账；模拟CLI证据明确real_model_calls=0。旧project-iterations／project-scheduling、quota／window及普通题库适用回归继续保留。


## Scenario: 真实 GitHub 项目逐仓研究与百项目扩展 SOP

### 1. Scope / Trigger

- 选项目、研究 GitHub 仓库、编写场景与任务、扩充／替换项目库时适用。历史 100×20 工程路线研究作为来源保留；当前内容池方向为约 100 项目、600～800 场景／2,000 独立任务，每项目数量由真实场景决定，旧生成内容保持退役。
- 本节定义研究与准入流程；legacy `app.py` 协议与新场景原生适配分别按前述版本契约执行。正式接入以逐仓真实准入与当前目录为准，历史研究完成、本地内容可用、模型完成及生产上线分别记录。
- 研究可以复用记录模板与取证工具；源码分析、改进需求和验收目标必须逐仓形成。一个仓库、它的 fork、不同目录副本或改名版本不能计为多个独立项目。

### 2. Signatures

- legacy 入口为 `ProjectVerifier.verify(candidate, cases, timeout=30)`；内容 schema 2 使用 `verify_native(...)` 和场景 manifest。研究文档不直接当作可执行内容；新内容按实际就绪项目加载，不继承 legacy 100／20 的最小数量门槛。
- 单仓研究报告：`research/github-projects/<slug>.md`；二十步路线：`research/github-projects/<slug>-roadmap-20.md`。slug 冲突时包含 owner，不复用不同仓库的报告。
- 原始证据保存于项目外或被忽略的本地证据目录；报告必须给出实际位置和可重跑命令。记录完整上游提交，例如 `git -C <checkout> rev-parse HEAD`，不能仅记录 branch/tag。日志和依赖环境不混入待运行的源码快照。
- 下述研究记录不能替代可执行 manifest、离线环境与独立验收；接入契约见前述内容 schema 2／policy 3。

### 3. Contracts

**每仓固定流程**：

1. **核对来源**：访问官方仓库，确认用途、许可证、上游 URL 和实际存在的提交。保留许可证及必要的归属信息；无法确认可复用条件时暂缓准入。不能只凭仓库名、星数或搜索摘要入库。
2. **检出并读源码**：固定完整 commit，记录真实文件数、源码规模、模块职责和主要入口，读取相关类／方法定义。不得把原工程改写为几十行同构 app.py，再称为真实项目。
3. **验证轻量程度**：在隔离环境安装实际依赖并运行原生入口。记录 Python／Node 等运行版本、依赖锁定依据、系统包、必需服务、安装耗时、环境大小、测试耗时及可取得的内存指标。轻量由实际运行成本判断；需要云凭据、额外服务或较高资源的项目说明限制，不能隐藏成本。
4. **建立原生基线**：优先运行上游适用测试并执行至少一个真实使用场景。记录命令、通过／失败／跳过数、跳过原因、警告和资源配置；未跑的检查明确保留为未验证。依赖缺失不能等同于产品缺陷，部分测试通过不能冒充全套通过。
5. **发现真实改进**：结合上游 issue、文档承诺、实际使用路径和源码缺口。缺陷要在固定提交上复现；新增能力要确认公开入口尚不提供目标能力。记录已有替代方式，区分缺陷、增强提案、已存在功能和待决定的兼容行为。
6. **形成真实场景任务**：逐项记录用户问题、原版现状、交付目标、材料分支、授权范围、兼容边界、正常／反例验收及真实依赖。理解、咨询、诊断、方案和修改按需要选择；任务数可变，不用追问、重试或实现／测试拆分凑数。已有二十项工程路线保留为候选来源，逐项判断是否适合新任务。
7. **独立验收后接入**：控制端持有冻结用例，确认运行时加载候选源码，实际调用原生 API／CLI／UI 并观察文件／数据库等业务效果；累计回归此前已接受能力。依赖提前按固定版本准备，验收期间离线使用；候选不可通过删除自身 tests 或自报成功放行。

**可选私有外部测试的范围**：固定主仓包含不可取得的可选私有测试Gitlink时，先核原生loader是否条件加载，并保存父提交、子模块路径／提交、不可取得证据及完整公开主仓。只有用户明确确认以公开主仓为本轮交付范围后，才按该范围建立准入；私有内容、许可及测试必须明确未验证，不计通过，不修改原loader、设置跳过开关或替换固定项目。可取得的公共测试子模块仍完整导出；不能把这一例外推广到必要源码、许可或测试缺失。

**步骤计数**：一个步骤是一次完整用户可见改进，包含实现、测试、文档及失败修复。同一缺陷的测试矩阵、改代码／写测试／更新文档、失败重试不拆成多个步骤。相关症状可合并，例如 sqlite-utils 两种部分 upsert 问题归为一个保留省略字段的交付。工程修改按接受作业保留检查点；问答通过只记任务结果。只记录真实 answer／code 依赖，不为数量目标强造依赖。

**进度统计**：历史 100×20 工程研究保留其原完成口径。当前新增内容分别统计来源核对、原生基线、场景／任务定义、冻结验收与平台接入；就绪还须固定材料、离线环境及独立适配实际通过，不设每仓 20 任务门槛。生成名称或 clone 数量不等于完成内容；研究完成、验收可用、模型完成和生产部署分别报告。

**旧内容退出**：正式源码中的 `project_library/projects/project-001` 至 `project-100` 及旧目录清单退役，移除正式批量生成入口；不得改名、换 README 或增加 GitHub URL 后继续充当真实项目。为调度器回归需要的合成内容只能在隔离测试目录临时构造，明确标记测试用途，不作为正式 catalog 或交付统计。已冻结的发布目录、实例工作目录、历史 DB 和成果不因源码清理被批量删除。源码清理与实际部署分别报告，不能以本地删除推断线上已清除。

**空库与接入**：真实内容尚未就绪时，不自动重新生成旧项目补足 100。内容 schema 2 允许部分就绪项目接入；空库或不合法内容拒绝新准入，历史 reader 与当前 catalog 分离，旧题库保留原入口。保留已经完成的真实项目研究；原生入口、离线依赖、独立验收和预算适配完成之前，不把它包装成 legacy app.py 协议接入。

### 4. Validation & Error Matrix

| 条件 | 处理与计数 |
| --- | --- |
| 只有名称／URL，未读源码或未检出固定 commit | 保持候选，不计研究完成 |
| 许可证、必要服务或依赖条件尚未查清 | 记录原因，暂缓准入 |
| issue 在冻结提交上无法复现，或目标能力已存在 | 重新分析／移除该步骤，不计有效缺陷 |
| 新接口仅检查到缺失，尚未实现 | 记录增强提案，不能声称修复验收通过 |
| 基线失败、系统依赖缺失、网络不可达或测试被跳过 | 保存实际结果和原因，不伪报通过；未解决的适用基线失败不计研究完成 |
| 场景目标／独立验收尚不明确 | 继续研究，不拆追问、测试或重试凑任务数 |
| 100 条模板或同源副本 | 不计为 100 个真实项目 |
| 原生基线通过，但未接入适用原生适配器 | 研究与平台接入分别记录，不冒充可运行内容 |
| 删除旧源码目录后，当前运行实现拒绝空库 | 明确报告项目入口暂不可用，不恢复旧生成内容兜底 |
| 清理命令指向已冻结发布、实例成果、生产 DB 或未知目录 | 停止扩大范围，按实际环境与归属另行处理 |

### 5. Scenarios and Examples

- 正常：`simonw/sqlite-utils` 固定 `9c66bafa52ae23d40499c74b0db3b635bcddb876`，原版全套测试 1,497 通过、16 跳过；相关原生测试在正式账号镜像隔离运行 75 项通过。二十步路线含9步已复现问题修复和11步功能增强提案，研究本身不等于实施；第二批现已另行接入本仓4场景／13任务和两个独立修改验收，不表示原二十步已全部实施。
- 证据入口：[单仓审查](../../../../research/github-projects/sqlite-utils.md)、[二十步路线](../../../../research/github-projects/sqlite-utils-roadmap-20.md)。原始 JSON／脚本位置以报告为准，不能将本地证据目录可用性当作跨机器保证。
- 边界：前 2 步闭环通过只证明这 2 步完成；后 18 步仍按各自状态记录。一个适用基线通过、20 步研究齐备但未接入的项目，只增加研究完成数。
- 错误用法：批量生成 100 个 44 行 app.py，给每项拼接 20 个通用操作，再声称真实 GitHub 项目库扩充完成。正确做法：逐仓读取真实代码、执行原生基线、核实需求和路线；未满足条件的保持候选状态。
- 错误用法：删掉旧正式目录后，为使数量检查／测试通过重新写回同一批合成项目。正确做法：正式目录只接入已就绪真实内容，调度测试显式使用临时合成夹具；历史成果单独保留。

### 6. Tests Required

- 单仓审查：核对仓库归属、完整 commit、许可证、源码规模、真实入口、依赖版本与测试日志；至少一个原生使用场景实际运行，报告中的通过／失败／跳过数与原始输出相符。
- 场景审查：可变任务数量、稳定 ID、同场景真实 DAG、入口／分支可达、材料披露和分类验收均合法；缺陷原版复现，增强核对实际缺口，不重复计算追问或重试。历史二十项文档单独保留其数量审计。
- 独立验收：正例、反例、基线和此前已接受能力均实际运行；核对候选加载路径、真实业务副作用、超时、依赖不可用及输出边界，禁止候选修改冻结验收。完整原生集合和单步集合的资源预算分别实测。
- 进度对账：来源不同的仓库去重；候选、研究完成、验收就绪、模型完成及生产发布各自统计。未解决的适用基线失败或未完整定义的步骤不得进入研究完成计数。
- 退役回归：正式库无旧 100 项和正式生成入口；合成夹具只在测试临时目录出现；旧库不能被默默重建。调度／验证测试改用显式夹具，保留目录接续、检查点、停止和并发回归；确认源码清理未修改历史发布与实例数据。

## Scenario: 内容 schema 3 的完整开发周期与动态需求方配置

### 1. Scope / Trigger

- 修改 `project_dialogue.py`、`project_development.py`、`project_requester_settings.py`、完整任务恢复／验收、`#projects` 配置表单或 schema 3 内容时适用。
- 一个需求或 BUG 对应一个完整任务；源码调查、追问、方案确认、实施、交付和修复属于同一任务、同一开发者会话与工作区。普通交流不启动独立评分。
- 原账号身份、运行时段、额度、执行许可、严格释放和私有最终评审继续遵守既有账号契约。

### 2. Signatures

```python
ProjectLibrary(root, minimum_projects=100, minimum_steps=20, catalog_name='catalog.json')
ProjectDialogueClient(base_url, api_key, model, fallback_model='', *, timeout=30,
                      opener=None, additional_models=None, revision='environment')
ProjectDialogueClient.generate(context, preferred_model=None, timeout_sec=None)
ProjectRequesterSettings(path, environment=None)
ProjectRequesterSettings.public()
ProjectRequesterSettings.save(base_url, models, api_key=None, *, compaction_threshold_tokens=None)
ProjectRequesterSettings.reset()
```

- `GET /api/settings/project-requester`：读取脱敏配置。
- `PUT /api/settings/project-requester`：`{base_url: string, models: string[], api_key?: string|null, compaction_threshold_tokens?: integer|null}`；未知字段拒绝，Pi 阈值见下文 token 摘要契约。
- `DELETE /api/settings/project-requester`：清除页面覆盖并恢复环境初始值。
- 响应字段为 `base_url`、`models`、`api_key_configured`、`source`（`page/environment/invalid`）、`revision`、`ready`、`error`、`compaction_threshold_tokens`；不返回 `api_key`。
- `project_dialogue_jobs` 以 `evaluation_job_id UNIQUE` 绑定冻结回答，保存 `task_id/generation/status/phase/request_json/result_json/attempts_json/model/work_sec/reserved_sec/recoveries/retry_at/error` 及时间；不新增需求方 CLI 作业角色。

### 3. Contracts

**配置与请求**：

- 页面仅管理一个 HTTPS Base URL 和按优先级排列的 1～8 个不重复模型。首个主用，后续按序降级。模型使用 `MODEL_NAME` 校验；地址不含认证、query 或 fragment；地址和模型名不得混入密钥。
- 环境初始值使用 `PROJECT_REQUESTER_BASE_URL`、`PROJECT_REQUESTER_API_KEY`、`PROJECT_REQUESTER_MODEL`、`PROJECT_REQUESTER_FALLBACK_MODEL`。页面覆盖原子保存到 `BENCH_DATA/settings/project-requester.json`，文件 0600、创建的父目录 0700；保存密钥留空时沿用服务端当前值。保存不发出连通请求，`ready` 只表示配置语法完整。
- 保存成功后替换管理器的后续请求客户端；在途客户端保留开始时的地址、模型与配置版本，已生成有效消息继续复用。配置版本变化后重新按新列表选模；同一版本内当前任务沿用已选模型，避免每轮重试已耗尽的主模型。
- `POST <base_url>/chat/completions` 使用 Bearer、非流式 `messages` 和 `max_tokens=1024`；禁止自动重定向。一次生成对每个模型最多尝试一次；单模型默认网络超时 30 秒，控制端共用最多 60 秒预留及任务剩余预算。
- 402／明确额度错误、429、500／502／503／504 和传输故障可有限降级；认证、参数和无效回复错误不通过换模型掩盖。主备均失败有限等待恢复；未知在途结果保留预留并阻塞盲重发。
- 严格 JSON 只有 `action` 和 `message`；动作只允许 `reply/implement/verify`，前两种消息非空。重复字段、截断、工具调用、拒绝、额外评分字段和密钥反射均拒绝。
- 请求只含任务、可披露业务材料、真实对话和已确认方案，业务上下文不超过 512 KiB、响应不超过 64 KiB；私有 rubric、验收源码、参考补丁和凭据不进入请求。调用及配置版本、服务地址、请求／返回模型、实际 usage 分别留证，缺失统计保持未知。

**原会话与验收**：

- 先凭原生父链确认输入／回答并严格释放执行，再由外部需求方推进。有效结果先保存后应用；同一冻结回答重放不重调模型、不重复投递。
- 仅方案确认后的实施／返工阶段允许 `verify`。最终交付依次核授权范围、独立程序事实、冻结回归和必要交付审查；程序未通过不能接受代码，模型不能自行声明任务完成。
- 失败反馈提供可公开的位置与实际差异；大型回归保留失败事实而非完整收集清单，并按 UTF-8 字节有界。真实代码修复最多两次，同版本语义异议只复核一次；确定程序失败必须修复，存疑结论保留交付待处理。
- 超时仅结束执行片段；Run 保留 timeout，原会话、方案及半成品待续做。任务工作预算累计开发者、最终评审和需求方时间及未决预留；普通交流和基础设施切片不计业务修复。
- 同账号可执行的续做优先于新需求；服务等待不占 Claude 执行名额。停止、身份变化、会话／工作区缺失、消费不明、预算耗尽和严格释放失败均不能被自动恢复绕过。
- 已生成未投递复用原消息；已投递未确认先核原生消费；已消费未回复续原会话；交付待验收继续原冻结版本；程序验证已完成但结果未收口复用原验证事实。

**内容与页面**：

- schema 3 每场景恰好一项 `kind=modify`、`development_cycle=feature|bug` 的任务，具有独立原生验收，不携带旧短题 `max_turns`。`owner_materials` 只引用 `disclosure/` 中的业务材料。
- 目录可用 `project_manifest=development.json` 选择新定义，保留原 `project.json` 与 `catalog-v37.json`；冻结历史不迁移。`admission` 的 ready 集合必须精确等于可执行项目集合，blocked 必须有原因。
- 当前重审口径为 100 项目、30 就绪项目／36 完整任务、70 待准入；旧 426 场景／726 短任务和研究提案单列。生成目录不能替代准入证明，激活须由 `build-project-development-content.py --activate --validation-report <回执>` 核全部任务覆盖与内容摘要。
- 页面按完整交付计完成数，轮次、业务修复、异议复核及服务恢复分别展示；连续对话按需读取。开发者、需求方、最终评审用量单列，缓存命中以真实服务证据为准。
- 局部 `<pasted_content>` 包装只在同 ID 单层标签与已知边界换行移除后，能精确还原原输入时接受；额外正文、不同 ID 和嵌套／多重包装拒绝。

### 4. Validation & Error Matrix

| 条件 | 处理 |
| --- | --- |
| HTTP 地址、重复或超过 8 个模型、密钥混入地址／模型 | 配置 PUT 400，保持原配置和客户端 |
| 配置字段类型错误／未知字段 | 422，固定错误不回显密钥输入 |
| 未登录／无内部服务凭据 | 沿用管理鉴权拒绝读取与写入 |
| 配置保存失败 | 500，旧客户端及私有配置继续生效 |
| 页面文件损坏 | `ready=false/source=invalid`，拒绝盲用环境供应商；可完整重填或恢复环境 |
| 新完整任务尚未配置客户端 | 拒绝新批次，历史 reader 保持可用 |
| 配置在请求中修改 | 保存原结果及来源，下一请求采用新版本 |
| 未确认方案即 verify | 阻塞提前验收，保留会话 |
| 明确程序失败或复核次数耗尽 | 不接受交付，具体反馈或保留阻塞原因 |
| 验证已完成／收口重复到达 | 复用原事实，只接受一次任务完成 |

### 5. Scenarios and Examples

- 正常：页面填写 `https://ai.flower-cli.com/v1`，模型按 `gemini-3-flash-agent`、`deepseek-flash` 排列。主模型额度不足后转备用，方案确认和实施都在开发者原会话进行。
- 边界：管理员改变地址和模型顺序，密钥留空；已生成追问仍发送原内容，之后的需求方请求使用新版本，已运行客户端保留原来源。
- 错误：普通问答每轮都要求 pass；或将 slice timeout 当作任务结束并重建 seed。正确：普通回复直接推进，超时严格释放后恢复原会话与工作区，共用累计预算。
- 错误：只凭语义 pass 覆盖程序失败、将问题改名补齐百项目数、或因结果未知盲重发 API。正确：保留独立事实、逐仓准入和未决预留，分别处理真实失败与基础设施恢复。

### 6. Tests Required

- `test_project_dialogue`：请求格式、严格动作、额度／限流／5xx／传输降级、认证不降级、总时限、重复字段与密钥反射；另核 `_NoRedirect` 是生产 opener 的实际处理器。
- `test_project_requester_settings`：私有权限、重载、空密钥沿用、恢复环境、多个模型顺序、在途客户端保持、保存失败原子性、API 鉴权与 DTO 错误脱敏。
- `test_project_development`：十轮普通交流零评审、确认方案、具体失败修复、有限异议、超时／暂停／重启／停止竞争、配置变化与缓存消息、续做优先、预算和接受幂等。
- `validate-development-content.py`：逐任务核原版失败、参考通过、授权范围、冻结回归；双试点另拒绝错误候选。来源、许可证、离线制品与交付副本摘要一致。
- `verify-project-development-pilots.py --browser`：合成开发者／语义评审、本机 HTTPS 需求方、真实 SQLite／原生交接／Docker 原生验收；Chrome 双主题与 390／1280 宽度核配置保存、三模型降级、新 Bearer、连续对话及 API 对账。
- 真实供应商最小连通、真实模型完整业务、模拟机制及生产部署分别留证；未实测的模型质量、费用与缓存收益不报通过。

## Scenario: Pi 项目与工程养号每次指挥只处理一个目标

### 1. Scope / Trigger

- 修改 `ProjectsService` 的候选排序、目标创建、交付收口或 `images/pi-agent/host.mjs` 的工具结果与循环结束时适用。
- 一次指挥按账号、空间和控制者 `generation` 区分；养号的 `cycle_no` 是完整工程池轮次，两者不能混用。

### 2. Signatures

```python
ProjectsService.state(account_id=None, *, summary_only=False, proof_metadata=False) -> dict
ProjectsService._check_round_work(account_id: int, generation: int, work: dict | None) -> None
ProjectsService.tool(account_id, generation, name, args, call_id, stop=None) -> dict
# project_submit 完整通过并成功释放原执行后的工具结果：
{"submission_id": "...", "status": "passed", "round_complete": True}
```

- Pi 沿现有 JSONL `tool_result.result` 接收该字段；只在 `project_submit`、`status='passed'|'deferred'`、`round_complete === true` 同时成立时采用 SDK `AgentToolResult.terminate`。`deferred` 表示已安全暂存，不表示目标通过，详见下方“验收反馈与自动复验”。
- 不新增 HTTP 请求参数、环境键或数据库列。`projects_*` 与 `warmup_projects_*` 分别保存各自目标、代次及通过事实。

### 3. Contracts

- 每次指挥最多绑定一个工程目标；已有未完成工作优先恢复。后端按该账号及代次查询持久工作，已结束或已绑定其他工作时拒绝创建第二项。入口及选材后发布前均在服务锁内核对，不能仅依赖模型指南。
- `available_objectives` 先排除已完成、前置未满足及冷却中的目标，再按 `digest_json([namespace, account_id, cycle_no, project_key])` 升序对项目分组作稳定伪随机排列。同项目使用相同排名，稳定排序保留目录中的原目标路线。随机单位是项目，不能把项目内多个目标拆散穿插到其他项目。
- 当前工程轮次的最后工作不为 `stopped/deferred` 时，其项目的可执行目标优先于其他项目，包含上一目标已通过后的后续迭代；该项目没有可执行目标时才进入后续项目。Pi 指南要求从候选最前的项目选材；原工作恢复、前置依赖及冷却门禁仍由后端严格执行。
- 项目排名不依赖控制代次、当前时间或目录位置。同轮重启、项目池重新排列或完成当前项目的部分目标后，项目排名及剩余组内路线保持；账号、空间及工程轮次分别进入排名输入。随机项目不保证不同账号的首项永不相同，不能把它解释为免封保证。
- `account_state` 在完整候选池排序后才按 `offset/limit` 分页，默认页长 10、最大 20；候选集合不变时翻页不漏项、不重复。读取不消耗随机状态、不写库，运行间隔的固定／随机配置与候选排序相互独立。
- 完整交付验收通过、通过事实保存且原 Claude 执行成功释放后，才返回布尔完成标志。失败返工仍属同一目标；超时、额度等待和重启按原门禁续原 work、工作区、会话与累计耗时，不重建 seed。
- Pi 先让 SDK 保存真实工具结果，再结束本次循环。混合工具批次中完成后的工具不再交给控制端；`prepareNextTurn` 阻止后续推理。新进程的结束标志重新初始化，旧会话中的完成字段不能提前终止下一次指挥。
- 可信目标完成后无需额外生成摘要或回复；此次收尾停止额外压缩／推理。同目标的 token 摘要策略见下文，模型重试和降级规则保持。SDK 因混合批次收尾生成的零用量本地 aborted 消息不计入上游调用。
- 正常收尾复用原计划排期；关闭计划不自动重启，开启时遵守各自固定或随机间隔。人工暂停、取消、控制代次变化和共享账号占用继续优先，异步收尾后须再次核取消状态。
- 两种迭代共用该边界。养号必须全部工程目标独立通过后才在后续合法认领时清理并重开工程池，不能在完成单目标时清零。项目迭代不自动重开工程池。
- 发布须同时更新共享后端和 Pi 入口，重载后保留原会话、通过事实及各空间计划；不能只更新指南或只更新单侧运行文件。

### 4. Validation & Error Matrix

| 条件 | 处理 |
| --- | --- |
| 本轮首目标已通过或停止，又请求新目标 | `status='rejected'`，不新增工作或启动 Claude |
| 并发首次选择不同目标 | 发布前复查，只允许一个工作落库并启动 |
| 验收失败、基础设施异常或执行收口失败 | 不发完成标志，按原返工／阻塞规则保留现场 |
| 其他工具携带完成字段，或字段是数字等非布尔值 | 不触发 Pi 单目标收尾 |
| 完成时人工暂停或取消 | 不重开计划，不把迟到结果覆盖新代次状态 |
| 下一次合法启动 | 可选择下一目标；未完成工作则只恢复原目标 |
| 同轮刷新、重启或调整项目池排列 | 保持项目排名与组内原路线，优先续做已开始的项目 |
| 养号全部独立通过并合法进入下一工程轮次 | 使用新 `cycle_no` 的候选排名，保留历史交付 |
| 目标前置未通过、冷却未结束或已有未完成工作 | 随机排名不提供绕过原门禁或切换原工作的许可 |

### 5. Scenarios and Examples

- 正常：目标 A 通过后结束本次指挥；原计划间隔到期且门禁放行，再开始目标 B。
- 边界：目标 A 多次片段超时，下一次指挥仍使用同一 work/session，累计耗时保留；单轮时限沿用当前配置，本契约不另设累计预算策略。
- 选材：多个账号使用同一百项目目录时各自获得稳定打乱的项目排列；同账号项目与养号空间分别排名。项目 A 的多个目标按原路线连续执行，完成后再进入项目 B，暂停重启继续原工作和累计代码。
- 错误：每次 `account_state` 都重新随机洗牌、先截第一页再打乱，或将同项目目标分别随机排名。正确：完整合法候选按项目分组排名并保留组内顺序，再分页，避免漏项、重复及项目内迭代被拆散。
- 错误：修改提示词后仍允许本轮 `claude_start` 创建 B，或为了结束 Pi 丢掉 A 的真实工具结果。正确：后端限制目标，并在 SDK 保存通过结果后结束循环。
- 错误：把“单目标已完成”当成养号全部工程已完成。正确：`cycle_no` 仅在全部独立通过后的后续认领推进。

### 6. Tests Required

- `test_projects_single_objective`：两空间第二目标拦截、并发发布、失败返工、超时保留两个会话、人工暂停竞争、执行收口失败，以及养号重开后首目标仍单独收尾。
- `test_projects_agent.test_six_hundred_objectives_are_fully_pageable_without_duplicate_payload`：600 项完整分页，分页顺序与全量视图一致，集合无遗漏或重复，单项目内保留原目标顺序。
- `test_projects_engine_cycles`：多账号／两空间项目排列不同但组内连续，同轮重启及项目池重排保持排名，已开始的项目优先续做；通过真实工具连续完成六项目标并保留累计代码，全部通过才换项目，完整工程池验收后换轮产生新排列。
- `test_projects_pi_round`：真实 Python→Node→SDK 管道中，通过结果持久化、父进程得到 settled、上游请求恰好一次。
- Pi `host.test.mjs`：单工具及混合批次、完成字段严格校验、停止后的工具不执行、原会话重开不重放工具、取消优先和本地空用量不冒充上游调用。
- 依赖、调度、命名空间和工程池回归须按真实跨轮代次构造；不能继续用同一代次连续完成多个目标的旧夹具来绕过新边界。

## Scenario: Pi 按工程目标隔离上下文及可配置 token 摘要

### 1. Scope / Trigger

- 修改 Pi 会话恢复、工具循环、模型设置或目标材料读取时适用；项目与工程养号共用此契约。
- 固定 SDK 0.75.1 的原生压缩未覆盖持续工具循环，且零用量错误尾消息不能代表此前上下文已变小，因此由宿主在安全边界统一判断。

### 2. Signatures

```text
GET/PUT/DELETE /api/settings/project-requester
ProjectRequesterSettings.agent_configuration() -> dict | None
contextTokens(messages, fixedTokens = 0) -> number
freshContext(manager) -> object | null
compactContext(manager, options, summarize, signal) -> Promise<object | null>
account_state({offset?: integer, limit?: integer})
project_read({project_key: string, objective_id?: string, section?: string, offset?: integer, limit?: integer})
```

- Pi 启动配置新增 `context_mode='fresh'|'resume'` 和 `compaction_threshold_tokens`；`options` 包含 `threshold/fixedTokens/force/deadline`。
- `context` 事件仅持久化 `reason`（`new_objective/startup/threshold/overflow`）、非负整数 `before_tokens/after_tokens`（上限 `2**40`）及控制端 `generation`；不保存摘要正文、凭据或私有路径。

### 3. Contracts

- 上下文隔离边界是工程目标：开始新目标采用 fresh，本地追加隔离检查点；已有未完成目标采用 resume，跨控制代次继续原历史。新的 `verification_correction` 进入时允许一次 fresh 隔离错误推理，并注入已核实纠错；后续通过 `guide_loaded.context_correction_event_id` 识别已应用事件。不得在每次模型请求前重建。原始 Pi 文件、Claude 会话、工作区、输入事实和累计耗时留档。
- 压缩阈值默认 `350000`，范围 `10000..900000` 且必须为严格整数。PUT 中省略或 null 沿用当前值，旧私有 schema 1 文件缺字段时补默认；保存仍原子写 0600 文件并更新 revision，读取接口不返回密钥。启动／恢复冻结配置，两空间同时适用；没有新增环境键或数据库列。
- 达到阈值时触发摘要。优先使用最近有效助手的 `input+output+cacheRead+cacheWrite`，再估算后续内容；排除错误／取消及摘要前旧用量。无有效用量则使用 SDK 估算并计入固定指南和工具定义。自定义规划窗口不改变上游真实容量。
- SDK 原生自动压缩关闭。启动／恢复前和工具批次结束检查阈值；工具回执先持久化，再结束 SDK 子循环，在空闲边界摘要并 continue，不重发已确认工具或用户输入。正常正文不做字节硬裁剪，未配对工具及失败助手不进入模型历史。
- 较早正文按至多约 16000 个估算 token 分块，顺序归纳并携带上次摘要；近期完整交互最多保留 `min(12000, threshold/4)` 个估算 token。各片段摘要须非空且估算不超过 8192；取消／原截止时间仍允许，且估算用量确实降低并低于阈值后才追加检查点。异常不发布新检查点，原文保留。
- 摘要和普通推理共享本轮额外尝试上限（至多 8 次）、模型健康状态、同模型重试／降级、服务端等待及原截止时间；真实摘要调用纳入计量。Python 传来的剩余秒数可带小数，宿主须向下取整到整数毫秒后建立截止时间，避免 `AbortSignal.timeout` 拒绝小数或延长原预算。可信目标完成后直接收尾，无额外摘要或推理。
- Pi 每次启动／恢复按冻结的 `models` 配置顺序选择首个 `cooldown_until <= Date.now()` 的模型；失败模型的五分钟冷却跨轮保留，到期后在下一轮重新参与原顺序选择。正常执行中的轮次不因冷却到期主动回切；故障恢复继续遵守既有重试、降级、服务端等待及预算边界。
- `.model-health.json` 的 version 1、配置指纹及旧 `preferred_model` 字段保持兼容；`preferred_model` 仅记录最近成功模型供诊断，不参与候选排序。回切复用原 Pi 会话和已确认工具结果，不通过清空健康文件或重建会话恢复主用。
- 当前已知限制：摘要 `stopReason='length'` 仍可能通过非空及长度检查并发布未完成摘要。此行为属于 FBK-001 的保护缺口，不能把现有检查描述为已保证摘要完整结束；不代表磁盘原文已删除。
- 真正 400／413 上下文拒绝最多在强制摘要且确实缩减后续接一次；认证、明确内容拒绝、禁止重试、服务端等待及原预算优先。无法缩减或重复拒绝明确报 `context_limit`，不盲发相同超长请求给其他模型。
- `account_state` 的 offset 默认 0、limit 默认 10 且范围 1..20；三个列表 `available_objectives/waiting_objectives/passed` 同步分页，`objective_page` 给出各自真实总数及公共 next_offset，保留全部未完成目标数量。模型视图去除重复指南，页面完整视图保持。
- `project_read` 默认读取 overview，提供 objective_id 时默认读取 objective，research 读取研究；offset 默认 0、limit 默认 1000 且范围 1..2000，按字符返回 `content/offset/limit/total_chars/next_offset`。原工作继续使用冻结材料，仅提供公开正文，不向模型暴露私有验收。
- 已确认 `context_limit` 可按既有显式启动入口恢复；旧通用上下文错误须先追加绑定原错误的 `operator_diagnosis`，事件键为 `operator-diagnosis:context-limit:event-<原事件ID>`。旧通用断流可使用下节的自动会话诊断。身份、未知输入、合同及账号门禁仍须满足，不能泛化解锁。
- 镜像必须同时包含 host 与 `context-policy.mjs`，Docker COPY 与上下文白名单成对更新；发布后核对前后端字段和两空间运行版本。

### 4. Validation & Error Matrix

| 条件 | 处理 |
| --- | --- |
| 阈值为 bool／字符串／小数或未知 DTO 字段 | 422；整数越界为 400，均保持原配置 |
| 旧配置缺阈值，或新配置省略该字段 | 分别补 350000 或沿用已保存值；下一次启动／恢复生效 |
| 百万级历史后有零用量 error／aborted | 仍依据此前成功用量，分段摘要后恢复原目标 |
| 摘要抛错、为空、过长、未降低用量或取消／超时 | 不发布新检查点，不继续超长推理；原历史保留 |
| 摘要返回非空但 finish_reason=length | 当前已知保护缺口：仍可能发布并继续，见 FBK-001 |
| 强制摘要后仍收到真实上下文拒绝 | 明确 context_limit，不继续自动重试 |
| 高优先级模型仍在冷却 | 跳过该模型，按配置顺序选择其它未冷却候选；全部冷却时保留既有等待恢复 |
| 高优先级模型已过冷却，旧 preferred_model 仍指向低优先级备用 | 下一轮选择顺位最靠前的可用模型，旧成功记录不能将备用永久置顶 |
| 分页参数非法或材料 offset 超出正文 | 工具返回 rejected，不能把截断页当作完整清单 |

### 5. Scenarios and Examples

- 正常：新目标 A 使用 fresh；同一目标的多次模型／工具交互连续保留。累计输入含缓存达到 350000 后摘要，再继续 A；A 通过后结束，下轮 B 再隔离旧上下文。
- 边界：保存 `{"base_url":"https://ai.flower-cli.com/v1","models":["gemini-3-flash-agent"],"compaction_threshold_tokens":450000}`，密钥沿用；下次项目或养号启动均采用 450000，在途执行保留原阈值。
- 错误：每次请求清空历史、按 24 KiB 硬裁剪材料，或只看首 10 个目标就报告全部完成。正确：以工程目标隔离，同目标按 token 摘要，沿 next_offset 读取剩余页。
- 错误：直接重发百万级旧历史，或清空会话解除旧通用错误。正确：分段归纳，并凭绑定原错误的诊断经原门禁显式恢复。
- 正常回切：配置 `[gemini-3-flash-agent, deepseek-flash]`，Gemini 故障后冷却期间使用 DeepSeek；五分钟冷却到期后的下一轮再次优先尝试 Gemini，已有工具回执继续沿原会话使用。

### 6. Tests Required

- `cd images/pi-agent && npm test`：覆盖冷却期间继续使用备用、冷却到期后按配置顺序回切、三模型中仅恢复已过冷却的候选、兼容旧备用成功记录，以及同会话恢复不重放已确认工具；摘要、取消与有界重试回归继续通过。

## Scenario: Pi 中断自动恢复与历史断流诊断

### 1. Scope / Trigger

- 修改 `images/pi-agent/host.mjs`、`ProjectsPi`、`ProjectsService` 的模型错误、子进程退出、持久恢复和旧阻塞兼容时适用；项目与工程养号共用该合同。
- 修改页面恢复提示或增加故障字段时，必须核对 SDK → JSONL → 事件 JSON → 公开视图 → SSE／页面的完整链路。

### 2. Signatures

```text
unavailable(message, response) -> string | null
diagnose_stream_failure(directory: Path, session_file: str, error_at: float) -> str | None
ProjectsService._finish_model_recovery(agent, work, generation, retry_at, code: str | None = None)
GET /api/projects
GET /api/accounts/warmup/pi
```

- 错误事件沿用 `reason=model_unavailable` 的调度语义，可选增加有限枚举 `code`；明确请求拒绝使用 `reason=provider_request_error`。不接受任意客户端 `retryable` 标记，也不保存原始供应商错误正文。
- 公开账号视图可返回 `recovery=null|{phase,attempt,retry_at?,code?,message?}`。其来源为控制端持久恢复事件，不新增数据库列或环境键。
- 历史诊断为 `kind=error`，包含 `reason=model_unavailable`、`code=stream_incomplete`、`source=session_diagnosis`、`generation`、`diagnostic_of_event_id` 与固定消息；唯一键为 `session-diagnosis:stream-incomplete:event-<原事件ID>`。
- 已核实旧断流被自动认领时记录 `auto_retry`，人工认领仍记录 `manual_retry`；两者均保存原错误事件 ID、新代次和实际启动来源。

### 3. Contracts

- 先检查 SDK 失败终态，再检查真实 HTTP、认证／权限／请求／上下文拒绝、禁止恢复和非法等待。`Stream ended without finish_reason` 可恢复；成功 HTTP 中匹配 SDK 固定 `Provider finish_reason: <结束码>` 格式的未知结束码也可有限恢复。普通业务正文或没有响应补证的任意内部异常不能因此被重试。
- 普通推理和摘要共享原有有界恢复、配置模型降级、取消信号和截止时间。失败助手及半截工具不执行，已确认工具结果不重放。服务端要求的等待、模型冷却和账号门禁取较晚时间。
- `stream_incomplete`、`model_response_error`、`controller_interrupted` 用固定说明展示断流、响应错误和控制进程中断；认证、权限、请求不兼容、禁止重试、无效等待、坏管道及未就绪退出也各有固定故障码。Python 仅透传 `PI_FAILURE_MESSAGES` 内定义的码。
- 只有 valid ready 之后的意外 EOF／BrokenPipe 才可归为控制进程中断；坏 JSON、超长或未知管道记录不能伪装为临时模型错误。停止与超时优先，取消时不追加自动恢复事件；所有退出路径关闭 stdin 并收口子进程。
- 控制端必须先严格释放原 CLI 执行，再安排恢复。执行收口不确定使用 `execution_unconfirmed`，其优先级高于已保存的可重试准备故障；原运行定位和租约保留，不能继续自动排期。
- 已开启计划按 60／120／300 秒进行三轮快速恢复，持续失败后转为 `max(900, schedule_interval_sec)` 秒的低频检查。计数、最早恢复时间及已确认事实跨重启保留；关闭计划或人工暂停／停止不能被恢复机制重新开启。
- 历史自动诊断只面向当前原工作最近一次、无结构化原因的旧通用模型错误，且工作已 blocked、无 runtime／活动片段、无未解决启动故障。身份、授权、前置、未知输入与冻结合同必须核对；其他人工阻塞不因旧模型错误解除。
- 会话路径必须属于本账号本空间目录，目录／文件不能是链接；文件以 `O_NOFOLLOW|O_NONBLOCK` 打开，只接受单链接普通文件。核对最多 8 KiB 的 session 头及其 cwd，并只读尾部最多 512 KiB 的完整 JSONL 记录。
- 只接受最后一条 SDK message 为 `provider=projects`、`role=assistant`、`stopReason=error`、错误恰为 `Stream ended without finish_reason`；带时区时间与原错误事件相差不超过五秒。读取前后大小或修改时间变化、残缺行、错误目录、成功尾消息或证据不符均不建立诊断。
- 文件读取不持数据库写锁。发布诊断前用原账号、工作完整快照和最近相关事件进行事务复查；诊断与计划同事务发布，工作仍保持 blocked，直到合法 start 在同事务解除本项阻塞、记录认领并更新控制代次。
- 兄弟空间占用账号时可先保存诊断，实际启动必须认领共享所有者；占用或可重试额度门禁只顺延计划。不开启原本关闭的计划，不切换原 work、Claude/Pi 会话、工作区或累计耗时。
- 历史内容读取的 `ValueError/OSError` 只隔离原目标，保留原错误及会话并显示内容核对说明，不能中断其他账号的启动恢复。提示写入须复查代次、工作、更新时间与最近事件，避免覆盖新故障；不借该降级吞掉全局数据库错误。
- `recovery` 仅投影当前未运行控制者的 scheduled／exhausted／paused 恢复事件，并要求当前消息仍匹配该恢复记录，避免旧模型错误盖住新门禁。页面复用原 `schedule.next_run_at`、SSE 和时钟显示原因、次数、下一次时间及低频冷却；GET／SSE 不触发诊断或启动。

### 4. Validation & Error Matrix

| 条件 | 处理 |
| --- | --- |
| 缺少 finish_reason 或真实成功 HTTP 中未知 SDK 结束码 | 有界恢复，持续失败后持久冷却 |
| 成功正文出现错误文字、取消、明确认证／权限拒绝、禁止恢复或非法等待 | 不因断流规则自动重试；展示具体原因 |
| valid ready 后进程退出 | 严格收口后自动接续原目标；未就绪或坏协议则保留具体运行时故障 |
| 旧通用错误与完整会话终态匹配 | 幂等绑定原事件；开启计划则自动检查，关闭计划则等待显式启动 |
| 原错误／工作／会话时间不符、后续事件覆盖或存在未知输入 | 不解除阻塞、不重发操作 |
| 原冻结内容不可读取 | 仅更新仍匹配旧快照的提示，原目标保持 blocked，其他账号继续恢复 |
| 暂时被兄弟空间占用或额度未放行 | 保留自动检查时间，条件恢复后续原工作 |
| CLI 收口未确认，同时存在可重试准备故障 | 收口不确定优先，保留现场，不自动调度 |

### 5. Scenarios and Examples

- 正常：一次响应在已确认工具之后中断，SDK 保存错误记录，恢复继续使用该工具结果；后续不完整工具不会执行。
- 历史：原错误 E 与同一会话最后失败记录匹配，保存 `session-diagnosis:stream-incomplete:event-E`；定时认领原工作，重复重启不重复诊断。
- 边界：另一个空间仍持有控制权时先安排检查，空闲后继续；用户关闭计划时只建立有效恢复资格，不启动模型。
- 错误做法：批量把 blocked 改成 paused，或清空原会话重新开始。正确做法：绑定原错误证据并经过现有身份、投递、授权和执行门禁；内容不可读取时保留原目标并隔离该项故障。

### 6. Tests Required

- `cd images/pi-agent && npm test`：真实 SDK 的缺失结束标记、半截工具、已确认结果复用、持续失败交接、明确拒绝优先与响应隐私；普通推理及摘要共享恢复继续通过。
- `.venv/bin/python -m unittest discover -s orchestrator -p 'test_projects*.py'`：两空间旧诊断幂等、关闭计划、临时占用／额度等待、取消与代次竞争、坏会话、会话时间不符、执行收口优先，以及 `ValueError/OSError` 时另一账号继续恢复和提示竞争。
- `.venv/bin/python deploy/v3/verify_pi_projects_browser.py --evidence <临时证据目录>`：真实 Chrome、API、SQLite、SSE 核对等待／低频状态、原因、次数、下次时间、刷新与账号切换；合成验证不代表正式上游或生产目标已恢复。

## Scenario: 验收反馈与自动复验

### 1. Scope / Trigger

- 修改 `ProjectVerifier`、`ProjectsVerification`、`ProjectsService` 的验收归属、失败反馈、返工与恢复，以及 Pi 工具收尾时适用；项目和工程养号共用机制。
- 新增或修改任一独立业务观察器、复核“公开测试通过但 business=false”或同一候选重复失败时，先按下方跨项目规则归因，再决定修候选、修验收器或处理环境。
- 修改原生子测试/跳过记录比较、默认 repr 归一化或冻结报告预算时，同样按本节保留来源、真实结果与完整原始证据。

### 2. Signatures

```text
projects_verification_holds / warmup_projects_verification_holds(
  work_id TEXT PRIMARY KEY, retry_at REAL DEFAULT 0,
  deferrals INTEGER DEFAULT 0, timeout_turns INTEGER DEFAULT 0,
  last_deferred_at REAL DEFAULT 0, reason TEXT)
projects_work.status += deferred
project_submit -> {status: deferred, round_complete: true, work_id, retry_at,
                   deferrals, reason, submission_id, verification}
GET /api/projects、GET /api/accounts/warmup/pi:
  agents[].deferred_objectives = [{work_id,project_key,objective_id,retry_at,reason}]
  agents[].progress.deferred = integer
  agents[].work.verification_correction = optional string
failure_facts[] = {phase, reason, test_id?, exception_type?, required_percent?, actual_percent?}
attrs 受信业务输出 = {candidate_import: bool, business: bool, feedback_codes: list[str]}
_native_contract_observer_adapter(source: bytes, specification: dict) -> tuple[bytes, dict | None]
native_subtests_match(project: str, actual: object, expected: object) -> bool
native_skips_match(actual: object, expected: object) -> bool
native_metadata_facts(project: str, actual: dict, contract: dict) -> list[dict]
ProjectsVerification._business_feedback(report: dict) -> list[str]
parse_review(raw: str, package: dict) -> dict
ProjectsVerification._review(work: dict, directory: Path, package: dict, cancel) -> dict
runtime_adapter = {name, scope, original_runner_sha256, effective_runner_sha256,
                   preserves_frozen_contract, metadata_policy_sha256?, ...}
```

### 3. Contracts

**跨项目归因与修正规则**：

1. **每个拒绝条件必须能追溯到公开要求。** 以原 work 的公开任务、材料、已确认澄清和兼容承诺为依据；参考补丁和私有断言用于验证这些要求，不能反过来追加唯一实现方式。异常子类、布尔真值、编号起点、空白和输出表示等未约定细节，按可观察业务含义判断；合同明确承诺的原对象身份、顺序、不变性和错误传播仍须精确验证。Chardet 的错误表示可兼容，attrs 明确要求的原异常对象身份不能因此改成字符串。
2. **先固定事实，再决定谁需要修复。** 核对原 work/submission、候选摘要、冻结公开合同、实际观察器与 Python/离线依赖；区分授权范围失败、真实业务失败、原生/历史回归失败、验收器自身误判和基础设施错误。公开示例全通过只是调查线索，不能单独证明候选正确；`business=false` 或汇总失败数也不能单独证明候选有错。
3. **观察器本身也要有反例。** 同一修正版须同时覆盖原版明确不满足、参考实现满足、符合公开合同的替代实现满足、真实功能错误仍失败。按行为拆分检查，用独立输入、实例和计数；不要让检查器的重复调用、一次性迭代器消费或辅助检查异常污染其它结论。每个被容忍的差异都要有一项邻近的真实错误反例，不能用全局宽松比较替代具体合同判断。
4. **失败必须给出可行动事实。** 独立报告业务、原生回归、历史目标和辅助检查阶段；经来源核对后将固定 `feedback_codes` 或有界 `failure_facts` 映射到公开行为说明。反馈应说明哪项行为未满足，不能只返回 `business=false` 或总失败数，也不能把私有断言、原始日志及异常正文交给模型猜测。
5. **冻结纠错复用已有受信路径。** 先保存旧字节证据，只有脚本、参数、路径、严格 expected 和已知 SHA256 匹配才使用控制端临时可信副本；记录 `runtime_adapter` 的原始/实际摘要，不原地改历史合同或结果，不因同名脚本就自动替换。未来内容与可信副本同步；格式兼容不改变严格布尔、来源证明和诊断白名单协议。
6. **修规则时同时处理反馈污染。** 旧误判可能已经让 Pi/Claude 猜测时区、路径、覆盖率或增加 `pragma: no cover`。复核这些改动是否有真实需求依据，追加 `verification_correction` 说明已核实事实；首次纠错隔离旧 Pi 推理，保留原 Claude session/workspace、历史和累计耗时。重复提交、重启、缩短冷却或更换模型都不能修正错误规则；沿既有有界返工、暂存和冷却恢复，不借此取消身份、未知投递及严格释放门禁。
7. **验收执行版本与上线结果单独证明。** 用原冻结候选经过真实 `verify_native` 禁网入口验证业务、公开示例、完整原生回归和此前接受的能力，必要语义审查照常进行。发布后核对真正执行的后端/可信脚本摘要和 `runtime_adapter`，再走原提交验收链；源码已提交、CI 成功或仅更新 Pi 入口都不能证明线上验收器已加载修复。离线通过不直接写成线上 passed。

**已发生的误判与复用依据**：

| 案例 | 实际踩坑点 | 后续检查规则与证据入口 |
| --- | --- | --- |
| Schema / agate | 强制未约定的异常子类，并把 `min=None` 当作必然非法 | 使用明确不可比较的非法规则验证拒绝，兼容合同内的异常差异；`_native_schema_adapter`，提交 `ecc131dd` |
| 加权聚合 / agate | 要求 `(None, -3)` 报错，与“任一值为空先跳过”冲突；修复曾只更新 Pi 入口而未加载到验收后端 | 按公开的空值优先级构造独立负权重反例，发布后核对实际验收器；`_native_weighted_adapter`，提交 `3334b627`，执行版本排查见会话 `01a171a2-4a06-7fd1-9b5b-b4ece6f0d3ce` |
| Arrow | 空格式列表的合法 ValueError/ParserError 被当作失败，辅助覆盖检查又污染原测试 setup | 兼容已确认的异常范围，辅助边界与原生回归独立计数；`_native_arrow_adapter`、`test_project_arrow_adapter`，提交 `76e7c7e2` |
| attrs | 未公开的 `raise_errors=1` 严格 bool 要求，以及观察器重复调用污染一次执行计数 | 独立实例/计数检验公开验证语义；`project_attrs_observer.py`、`test_project_attrs_adapter`，提交 `13ee9685` |
| Babel | 对未定义的广泛零权重排除与具体正偏好冲突强制单一结果 | 接受两种符合公开合同的解释，同时单独拒绝违反明确通配符排除的实现；`project_locale_preferences_observer.py`，提交 `0e069d51` |
| Bibtexparser | 将保留首尾空白的正确页码归一化判错 | 比较约定的数字和双连字符，继续保护原值、对象及其它字段；`project_pages_observer.py`，提交 `0e069d51` |
| Chardet | 强制从一编号和字符串 TypeError，公开合同未规定；模型收到泛化失败后反复猜测 | 兼容合理编号和错误表示，分别检查惰性、策略、隔离与真实逐条检测；`project_chardet_batch_observer.py`、`test_project_contract_observers` |

上述案例的逐项摘要、允许的兼容范围和协议约束以下方适配器合同为准；不能把一个项目的例外推广到其它未核实目标。历史取舍可用 `trellis mem context <session-id> --grep <关键词>` 复核：自动收敛与反馈污染见 `01a17427-4031-7eb2-80c0-9bf18aeeb897`，真实通过率与合理差异见 `01a17838-7918-7600-a7a5-67fb05472e0e`。

- 历史唯一活动工作索引幂等迁移，排除 `passed/stopped/deferred`；SQL 名称在养号空间独立映射。待复验保留原 work、原冻结合同、源码、Claude session、原始 Pi 历史和累计用量，不产生通过证明。
- 共用 `parse_review` 允许单个完整 JSON 的 Markdown 代码块包装（无语言或 `json`，大小写兼容），但原始输出仍至多 64 KiB；不从前后说明、多个对象或多个代码块中猜选结论。判定项必须包含 `id/status/reason/evidence`，仅额外容忍与该项冻结规则同类型、同值的 `requirement/allow_candidate_evidence`，后者省略的默认值为 false；返回前移除这两个冗余字段。重复键、未知字段、身份摘要错配、缺项、非法证据及与程序事实矛盾仍拒绝，证据权限只读原包。
- `ProjectsVerification._review` 在同一 180 秒调用预算内最多首次加一次协议错误重评；只在 `parse_review` 抛出 `ValueError` 时重评。原包、候选和已通过程序报告保持，第二次仅领取单调时钟剩余量，并将相同剩余量传给 SDK 配置和 Python 运行时。合法 fail/uncertain 直接返回；SDK 传输失败、取消及预算用尽不增开格式重试。原始会话分别保存在提交私有目录 `private-review` 和 `private-review-retry-2`，各次真实用量独立去重，重评前发布 `review/attempt=2`；全部协议校验通过后才写 `private-review.json`。场景调度器继续使用其既有持久重评与分层预算，不叠加此 Pi 重试循环。
- 三次业务失败或同一候选连续两次失败后暂存；已持久提交参与计数，不因重启或换控制代次重置。基础设施错误仍先本地重验两次，失败后自动暂存；验证器抛错也须先确认严格释放。连续两轮指挥超时同样暂存，防止未提交而无限续跑。
- 第一次冷却六小时，再次十二小时，以后二十四小时；只在冷却后新尝试重新计算本段返工上限，历史与累计退避次数保留。冷却不占 CLI 或模型调用；到期按原计划及账号门禁自动恢复同一 work/session。
- 同一项目共享累计工作区；存在待复验修改时不开放该项目的其他目标，优先处理其他项目，防止半成品污染新需求。待复验仍计未完成，不满足前置，不触发养号完整工程池清零。全池无可执行项时自动等最早 retry_at，无需人工确认验收错误。
- 暂存前后复核控制代次、取消和未知输入，必须先严格释放，再同事务发布 deferred、冷却记录和审计事件。只有已通过或已安全暂存的真实提交返回 round_complete；SDK 保存真实工具结果后终止本轮，不能让模型伪造字段越过后端。人工停止待复验目标仍会转 stopped 并取消自动续做。
- 失败反馈只投影最多八项有界阶段、公开测试身份、异常类型或真实覆盖率数值，不透传 stdout、私有断言及异常正文；`_public_facts` 继续共享 12 KiB 体积预算。不能让模型猜测隐藏验收或用 pragma no cover、删测试换取通过。
- Arrow `expansion_regression.py` 仅精确 SHA256 版本可适配。辅助覆盖脚本的空格式列表允许 TypeError/ValueError（含 ParserError），其他错误类型仍要求 TypeError；新能力检查失败单列 feature_coverage，原冻结测试节点独立执行和比较。临时可信入口及只读辅助挂载记录前后摘要，不原地改写旧资产或降低覆盖率门槛。
- attrs 适配只接受 `script='verification/AT-VALIDATION-REPORT-DEV-observe.py'`、`args=[]`、`python_paths=['library/src']` 和严格 `expected={candidate_import:true,business:true}`。原观察器 SHA256 为 `304a4403f8a037da3e6a5c4eb0d125678fb725fe69580c6ce479a878d5304461`，修正版为 `b6a7f9f3156b449572499dcc742b8f856ea72520da76a16a205b4d69df705716`；仅这两个版本可以使用控制端同目录的 `project_attrs_observer.py`。受信程序与未来内容副本须字节相同，固定摘要复核后写临时入口，审计保留原始/实际摘要，不改冻结资产。
- attrs 按公开合同检查字段声明顺序、真实字段名/Attribute/原异常对象、每字段一次及普通 validate 首错兼容、字段不变、可选聚合、共享禁用、组合短路/一次迭代和 BaseException 原对象传播。不要求非 bool 的 `raise_errors` 必须抛 TypeError；不同调用使用独立输入和计数，避免检查器自身重放造成误判。
- attrs 诊断对象只允许上述三个键，两个结果字段必须为严格布尔。`feedback_codes` 仅允许 `attrs_report_order`、`attrs_report_identity`、`attrs_report_once`、`attrs_report_values`、`attrs_report_aggregate`、`attrs_report_disabled`、`attrs_report_composites`、`attrs_report_base_exception`，必须去重，且 `business == (not feedback_codes)`；拆出诊断后仍严格比较原 expected。其他未授权观察器不因此放宽输出协议。
- Babel `BA-PREFERENCES-DEV-observe.py` 只接受 `args=[]`、`python_paths=['library']`、严格双布尔 expected，原摘要 `c9470d69d118400e7042fe6f7ccb702d9d6a0107f656d5b7d2de72e2bf8bfe99` 或修正版摘要 `c387742407ebeb5cc5f6d0fae0180d4e60cb3ea2ed5975996116faa1f2b39015`。实际执行控制端 `project_locale_preferences_observer.py`，审计名 `babel-locale-preferences-contract-v1`。质量、同权顺序、别名、实际可用拼写、通配符排除、输入边界、一次物化和旧接口继续验证；`en;q=0, en-US;q=1, fr;q=0.1` 的未确定冲突允许前缀排除或更具体正偏好优先两种解释，不将其强制收窄为一个结果。
- Bibtexparser `BIBTEXPARSER-O03-DEV-observe.py` 只接受 `args=[]`、`python_paths=['library','app']`、严格双布尔 expected，原摘要 `8d95cce3afe191108213fe59aadef3449522f4a75c2039448d78623e509881e2` 或修正版摘要 `df64b50177e178ee88d2fd1fad08bf494725b071528e53c93ddd6dacc802fb60`。实际执行控制端 `project_pages_observer.py`，审计名 `bibtexparser-pages-contract-v1`。明确数字范围比较时容忍首尾空白，仍检查数字原文、双连字符、未知格式整体保持、首次原值、非原地修改、其它字段、幂等和默认解析栈。
- Chardet `CHARDET-O04-DEV-observe.py` 只接受 `args=[]`、`python_paths=['library','app']`、严格双布尔 expected，原摘要 `adcf87f9f11228e81eaf0d8ada307dea2673086530613f7c645f6961ade2dc37` 或修正版摘要 `888ee5787ffcba578725bcea8174bf6f9118c4fef75ea1d110d7209d7016cbab`。实际执行控制端 `project_chardet_batch_observer.py`，审计名 `chardet-batch-contract-v1`。公开合同未规定编号起点和错误表示，连续编号可从零或一开始，失败信息可为非空字符串、异常对象或包含错误事实的字典；不强制错误必须是字符串 `TypeError`。仍检查真实编码及选项、重复标识、顺序、创建/读取/关闭时的惰性、局部错误无成功结果、continue/stop/raise、后续输入保留、上游原异常传播、逐条独立真实检测和原始字节拒绝。
- 上述三类观察器与 attrs 使用相同的三键严格诊断协议：两个严格布尔、无额外键、类别不重复且 `business == (not feedback_codes)`。Babel 类别使用 `locale_preferences_` 前缀，后缀仅为 `api/quality/order/matching/exclusions/headers/once/legacy`；页码类别使用 `pages_` 前缀，后缀仅为 `api/ranges/unknown/original/immutable/fields/idempotent/default_stack`；批检测类别使用 `batch_` 前缀，后缀仅为 `api/results/order/laziness/errors/policies/upstream/detection`。类别按当前适配器分别校验，未知来源及控制端摘要不符返回验收环境 error，任意诊断或非法协议不能通过。未来项目内容使用控制端字节相同的副本，并同步公开合同、任务提示、说明与示例；不改写既有冻结内容。
- 公开业务反馈只映射受信枚举，不透传任意诊断字符串；递归只读取 `business/regression/previous_objectives[].report`，深度至多 5，每层历史目标至多 16，结果最多八项去重说明。具体反馈存在时替代泛化返工提示，原 `_public_facts` 的私有内容过滤和总预算继续生效。
- 已核实错误通过 `verification_correction` 事件追加事实，旧提交和原始记录留档；新纠错第一次隔离 Pi 旧推理，原 Claude 会话继续复用。该机制不自动绕过权限、身份、认证、未知输入或严格清理冲突。
- 原生完整列表子测试使用 `project_native_contract.py` 按父测试、阶段、上下文和结果比较多重集合，只忽略 ordinal 与枚举顺序；重复次数、缺项、多项和状态变化仍须拒绝，真实业务数组顺序仍由原测试及 `_same_json` 验证。已有不可逆摘要沿其原格式比较；原始子测试记录不改写。跳过清单只忽略顺序，保留身份、原因和重复次数。
- 默认 repr 地址只在已核 more-itertools、pyparsing、wrapt 的父测试与参数位置完整匹配后归一化，保留对象类型、函数名及其余字面；带引号的用户字符串、SQL 十六进制和未知位置不能全局替换。旧控制器通过精确原始 SHA 或可逆的唯一已准许片段变换核来源，汇总入口导入受信比较模块，插件工作进程不依赖该导入；输入根只读暂存模块并记录 `metadata_policy_sha256`。
- `WEBCOLORS-06-DEV` 与 `PYTHON-LIQUID-02-DEV` 分别使用受信 `project_palette_observer.py`、`project_versioned_loader_observer.py` 验证公开 Mapping 隔离/不可变行为及实际缓存命中/容量/LRU 淘汰，不要求 `_colors` 或 `_cache` 字段名。`BIBTEXPARSER-O02-DEV` 未知版本允许 ValueError/TypeError/LookupError，`CK-STABLE-WRITE-DEV` 软链接拒绝允许 ValueError/OSError；正常输出、原数据/文件/链接不变和临时文件清理继续检查，NameError/AttributeError 等开发错误不算合法拒绝。
- 上述四个观察器沿 `_CONTRACT_OBSERVERS` 核精确脚本、空 args、原 python_paths、严格双布尔 expected 及新旧 SHA，再执行同字节控制端/未来副本；使用既有三键诊断协议。类别前缀分别为 `palette_`、`versioned_loader_`、`bibliography_`、`stable_write_`，允许后缀以注册表枚举为准，公开说明由 `_business_feedback` 映射，不能透传任意字符串或错误正文。
- 原生回归结果预算为 `max(2 MiB, min(16 MiB, len(canonical_json(contract))*2+65536))`，日志为结果预算的两倍加 65536 字节，保留 Docker JSON 转义空间和准备证明；业务观察沿原 2 MiB 结果预算。可信回归报告超过预算返回环境 error，不能算候选功能失败。子测试差异提供固定原因及缺少/额外计数，不要求模型猜隐藏规则。

### 4. Validation & Error Matrix

| 条件 | 结果 |
| --- | --- |
| 只有公开示例通过、business=false 或汇总失败数 | 固定原候选并对照公开合同和逐项事实调查，不直接改候选或放行 |
| 拒绝理由只有参考补丁细节、观察器重放或辅助检查污染 | 先复核验收器，按精确来源修正并补合理变体及真实错误反例 |
| 源码/CI/Pi 已更新，但实际验收摘要仍旧 | 保留现场，补齐真正执行后端的发布和原目标复验，不重复要求模型迎合旧错误 |
| 空格式列表合法拒绝 | 兼容约定内异常子类；错误接受输入仍失败 |
| 新能力边界失败 | 单列 feature_coverage；不污染第一个原测试的 setup |
| 三次业务失败／相同候选第二次失败／两轮超时 | 安全暂存，后续处理其他可执行项目 |
| 基础设施本地重验仍失败 | 暂存并低频自动复验，不要求模型重新实现 |
| 单个 JSON 代码块，或抄回与冻结规则相同的判定元数据 | 归一化展示后执行全部原校验，不因冗余表示失败 |
| 冗余元数据改变规则／布尔类型，未知字段、身份错配或证据越权 | 协议错误，不接受该结论；Pi 最多在剩余预算内重评一次 |
| Pi 第一次协议错误后剩余 40 秒／已取消或预算用尽 | 只领取 40 秒／不再调用；不重跑业务、原生或历史检查 |
| 合法 fail／uncertain／两次协议错误 | 返回业务失败／环境 error／环境 error，按原反馈及暂存规则处理，不重抽直到通过 |
| 全池冷却或依赖待复验 | 持久安排下一次检查，不启动空模型循环 |
| 取消、代次变化、未知投递、无法确认释放 | 沿用原保护，不发布正常收尾证明或新目标 |
| 冻结脚本摘要未知 | 拒绝推测适配，按验收环境故障自动暂存 |
| attrs 已匹配合同但脚本版本未知或控制端受信摘要不符 | 返回验收环境 error，不把来源错误算业务失败 |
| attrs 结果出现额外键、非 bool、未知/重复类别或 business 与类别矛盾 | failed，不将任意诊断投影到公开事实 |
| Babel 或页码旧脚本摘要已确认且协议匹配 | 执行受信临时副本，旧脚本和旧结果保留审计 |
| Babel 冲突采用合理解释／页码仅保留首尾空白 | 不因未约定细节拒绝；其它公开功能仍须逐项通过 |
| Chardet 从零编号、错误为结构化事实或异常对象 | 按公开行为验收；编号乱序、错误记录仍有成功结果、预读、吞异常或复用旧检测仍失败 |
| 忽略通配符排除、破坏页码数字／来源、修改输入 | failed，并返回对应公开行为类别 |
| 新观察器来源未知、可信副本摘要不符／诊断协议非法 | 来源错误为 error；非法输出为 failed，不放行或透传任意正文 |
| 相同原生子测试仅遍历次序不同／已核默认对象地址变化 | 完整多重集合相符即可通过；原始顺序与表示继续留证 |
| 子测试缺项、多项、重复次数、类型/函数身份、业务字面或结果改变 | 不匹配并返回有界差异事实；业务错误仍失败 |
| 色板/缓存换用另一私有字段名，公开行为全部相符 | 通过；可变导出、实例污染、不命中或不淘汰仍失败 |
| 未知版本合法参数错误／软链接合法文件错误 | 按已核拒绝族接受；忽略拒绝、写穿链接、改变输入或开发错误仍失败 |
| 冻结报告超过旧2MiB但在按合同计算的有限预算内 | 完整读取并验证，不轮转丢准备标记；超过当前预算为环境error |

### 5. Scenarios and Examples

- 正常：目标 A 失败后依据具体事实返工，三次仍失败则保留原目标，下一轮选择其他项目 B；A 冷却到期使用原 work/session 续做。
- 边界：无其他可执行目标时等待六小时后的复验，不将剩余数量归零或宣称全部通过。
- 评审兼容：冻结判定允许 `allow_candidate_evidence=true`，模型在合法 pass 的判定项中抄回相同布尔值时自动移除冗余字段并通过完整校验。错误是把未知字段全丢弃或信任模型新增权限；正确是仅兼容已确认元数据，证据始终核对原包。无法归一化的协议错误仅有限重评，原始输出留档。
- 错误：只收到“1903 passed、1 error”便反复猜测时区，或改 TypeError 以迎合未声明的异常子类。正确：核对公开合同、修复精确版本的验收误判，提供可靠阶段事实并有界自动推进。
- attrs 正常：宽松真值实现和严格 bool 实现均按相同公开功能矩阵验收；若旧目标命中已核验来源，使用可信副本执行，原报告留档。错误：要求候选为了隐藏的 `raise_errors=1` 断言改代码；正确：移除未公布要求，同时用原生回归与独立错误反例证明没有放宽真实业务合同。
- Babel 边界：可用 `en_US/fr` 时，对未明确的冲突偏好分别接受两种现有解释；错误是因此跳过所有排除检查，正确是另用 `en;q=0, *` 等明确用例继续拒绝选回被排除语言的实现。
- 页码边界：`' 001 - 009 '` 变为 `'001--009'` 或 `' 001--009 '` 均可接受，首次原值仍须精确保留；错误是仅做 strip 后接受未转换的连字符，正确是同时检查数字文本、双连字符及不变性。
- 批检测边界：从零编号且 `error={'type':'ValueError','message':'...'}` 的局部失败与从一编号、错误为字符串的实现都可通过。错误是要求模型猜测参考补丁的编号和错误类型；正确是核对连续顺序、无成功结果、后续输入保留及真实检测，并按受信类别返回具体失败事实。
- Docutils 正常：原交付 457 通过、2 跳过，1776 条子项只有 39 条枚举位置变化时按完整多重集合验收。错误是要求候选修改上游 glob 遍历顺序或直接写 passed；正确是保留原候选和旧报告，修控制端规则后走真实禁网复验与独立评审。
- 表示边界：`<range_iterator object at 0x1234>` 在已核参数位置可随地址变化；`SELECT 0x1234`、对象类型或函数名改变不可因此被忽略。错误是全局替换十六进制或把列表转 set；正确是限定上下文并保留重复计数。

### 6. Tests Required

- 新增/修改观察器的准入证据必须覆盖原版、参考实现、合理替代实现和真实错误四类，分别记录业务、公开测试、完整原生/历史回归结果；复用 `scripts/validate-development-content.py`、`scripts/validate-development-sequences.py` 及对应适配器回归。已存在的精确版本兼容修正还必须用原失败冻结候选经过真实 `ProjectVerifier.verify_native` 复验，并核对旧字节不变、实际执行摘要和新增的具体失败反馈；未来发布须另核对线上生效。
- `test_project_arrow_adapter`：两种合法异常、错误接受输入、来源摘要保护、真实 pytest 节点不受辅助失败污染、覆盖率数值及私有日志边界、真实入口只读辅助挂载。
- `test_project_attrs_adapter`：新旧字节与分发副本一致、未知来源环境错误、真实入口临时暂存/只读挂载、严格结果协议、严格 bool 与真值两种合法实现、八类真实错误反例、历史嵌套反馈和私有内容边界。真实候选另经离线 Docker 业务、公开六项及冻结原生回归验证；业务通过不能替代语义审查或历史回归。
- `test_project_contract_observers`：Babel、页码和批检测参考实现及合理变体通过业务与公开示例；批检测覆盖两种编号与三种错误表示。错误权重/顺序/排除/输入边界/重复消费、页码未规范化/未知格式被改/原值丢失/输入或其它字段被改、批检测错误结果/编号/预读/错误隔离/策略/上游异常/检测缓存等真实反例失败并有具体类别。核对新旧摘要、未来副本一致、真实入口只读挂载、严格三键协议、历史嵌套反馈与私有内容过滤；真实冻结候选另经禁网产品入口业务及原生回归，不能把离线结果直接写成线上通过。
- `test_project_native_contract`：重排通过而漏项/多项/去重/状态/上下文变化失败，45 条已核 repr 地址变化通过而类型/函数/业务字面变化失败；跳过原因与重复次数保留，原始证据和未知来源保护不变。
- `test_project_behavior_observers`：四个目标的原版失败、参考及合理字段/异常变体通过、真实功能错误失败；真实 `verify_native` 另跑四组16场景并核诊断协议。`test_project_native_verifier` 核约4MB冻结结果可完整解析且日志预算覆盖JSON转义；nose2跳过漂移测试在对应离线专用环境补跑。
- `test_projects_verification_recovery`：三次不同候选、重复相同候选、双空间冷却、服务重启后的同 work/session、验证器抛错、连续两轮超时、取消竞争、人工停止及一次纠错上下文隔离。
- `test_project_evaluation`：冗余规则归一化且原包不变、单 JSON 代码块兼容；前后说明、多对象、重复键、缺项、输出超限、未知字段、布尔伪装、越权证据及程序失败反例仍拒绝。真实原失败输出另用新旧解析器离线重放，不能改写历史提交或直接替线上标记通过。
- `test_projects_verification_review` 与 `test_projects_verification_history`：同包仅一次格式重评、两份会话和用量、180 秒累计余量、取消／耗尽不增开、合法 fail/uncertain 不重抽、传输失败不叠加重试；完整提交只执行一次各程序阶段，同一冻结候选完成最终核对。
- `host.test.mjs`：待复验与 passed 均只在真实 project_submit 和布尔收尾标记下结束；普通失败或其他工具不能终止；原结果先持久化。

### 6. Tests Required

- `test_project_requester_settings`：默认、旧文件、保存重启、字段省略、严格类型／值域、密钥脱敏及失败原子性；`test_projects_single_objective` 核保存阈值进入两空间启动快照。
- `context-policy.test.mjs`：缓存用量、零用量尾消息、摘要前旧 usage 失效、完整正文分段、近期工具配对、原文留档及失败／取消不发布检查点。
- `host.test.mjs`：350K／自定义阈值、小数剩余预算下实际摘要成功、百万级历史、连续工具流、强制摘要仅一次续接、计量、摘要内容过滤同模型重试后降级及 DeepSeek 关闭思考。
- `test_projects_agent`：目标级 fresh/resume、600 项分页与材料分段还原、公开事件白名单、旧错误诊断及未知输入／身份门禁。
- 摘要 length 的本地真实 SDK 故障注入已复现 FBK-001；未修复前不得将“截断摘要被拒绝”计为已通过断言。

## Scenario: 项目与养号工程的自然目录命名及历史接续

### 1. Scope / Trigger

- 修改 `ProjectsTerminal` 的工作区派生、注册读取、工程输入或 `cleanup_cycle` 时适用，项目迭代与养号迭代使用同一实现。
- 目录名决定真实 Claude cwd 和主会话位置，命名升级不能迁移原工程、重建 seed 或改写历史会话。

### 2. Signatures

```python
ProjectsTerminal._workspace_identity(account, row, project_key, seed_digest, cycle_no,
    *, naming_version=2, namespace=None) -> tuple[str, dict]
ProjectsTerminal._registered_identity(saved, account, row, *, namespace=None)
ProjectsTerminal.cleanup_cycle(account: dict, cycle_no: int) -> None
```

- 工作区：`environments/<environment_id>/projects/<alias>`；CLI cwd：`/home/node/projects/<alias>`。
- 私有注册：`runtime/<namespace>-workspaces/<alias>.json`；输入凭据：`runtime/<namespace>-inputs/<digest_json(receipt)>.json`。
- 新注册包含 `account_id/environment_id/project_key/seed_digest/namespace/cycle_no/workspace/naming_version`，其中 `workspace="projects/<alias>"`、`naming_version=2`。不新增 HTTP 参数或数据库列。

### 3. Contracts

- 新别名为 `<project_key>-<8位小写hex>`，后缀取 `sha256(namespace:account_id:project_key:seed_digest:cycle_no)` 前 8 位。项目标识复用 `PROJECT_KEY`，seed 为 64 位小写 hex，轮次为正整数，命名版本只接受严格整数 1/2，空间只接受服务端固定 `projects/warmup`。
- 未带 `naming_version` 的旧记录按版本 1 解释：普通首轮沿用 `workspace-<16位摘要>` 和原四字段注册；旧养号及后续轮次保留原空间前缀、轮次和相对路径字段。不为旧记录补新字段，原输入凭据摘要与字节保持有效。
- 准备时核对新旧候选，已有唯一合法注册沿用原目录及累计修改；新旧同时有效、候选无注册却已有目录、完整身份不符或链接均拒绝。无候选且原工作已有 baseline 或要求 resume 时拒绝重建源码，不以新名称绕过原证明丢失。
- 新名称仅从新建工作区生效，包括养号新轮次；项目原始中文标题、内容 key、计划、账号身份、通过事实和原会话 ID 保持原契约。
- 清理先读取两个空间的完整注册，用命名版本重算别名和身份；注册内容与文件名须完全一致，同空间同项目/seed/轮次重复注册或跨空间同名注册拒绝。兄弟空间合法注册不属于本次清理目标；自然目录和旧格式目录无可核对注册时拒绝清理。
- 早期养号的 `<32位小写hex>.json` 题库轮次 marker 原样保留，不解释为工程注册。注册目录链接、注册文件链接或硬链接，以及选中源码内的链接、特殊文件继续拒绝。
- 全部校验完成后依次删除指定轮次源码、输入凭据、工作区注册；中断仍从保留注册重入，其他空间、账号、轮次和历史会话不删除。
- `PiTerminal` 继续从选定目录生成 cwd、PYTHONPATH 与 native JSONL 位置，并通过已有 `runtime_json` 读取工作区和会话。生成版本 2 数据后，回退必须保留双格式读取能力，不能直接切回只识别旧命名的版本。

### 4. Validation & Error Matrix

| 条件 | 结果 |
| --- | --- |
| 两空间新建工程 / 已有合法旧注册 | 使用项目名加短后缀 / 原目录、原输入凭据及会话继续接续 |
| 同项目跨账号、空间、轮次或 seed | 分别派生并核验身份，禁止互相覆盖 |
| 新旧两份有效注册、短名碰撞、目录未登记 | 拒绝并保留所有既有源码，不猜最新版本或随机换名 |
| 原工作有 baseline/resume，但原工作区证明缺失 | 拒绝重建，保留原会话及进度 |
| 命名版本为 bool、未知版本或路径身份被篡改 | 校验拒绝，清理前不删任何选中目录 |
| 自然目录与兄弟空间合法注册并存 | 仅清理当前空间指定轮次，兄弟目录保留 |
| 未知自然目录、注册链接或原生执行仍占用 | 拒绝清理；无法证明归属不等于可删除 |
| 删除源码后输入凭据删除中断 | 原注册保留，下次继续清理且不触及其他轮次 |

### 5. Scenarios and Examples

- 正常：新工程目录为 `python-frontmatter-a12f34bc`；项目迭代与养号模式分别持有自己的私有注册，不在目录前缀标注内部用途。
- 历史：旧 `warmup-workspace-…` 工程暂停后继续，仍读取原目录和主 Claude JSONL；下一工程轮次新建时采用自然名称。
- 错误：只改目录前缀，随后按新 cwd 搜索原会话，或向旧四字段注册补命名版本。正确：保留原注册及输入凭据，按版本核对唯一合法目录。
- 错误：按项目名或前缀批量删除。正确：完整核对账号、环境、空间、seed、轮次、版本和实际注册路径，再按可重入顺序清理。

### 6. Tests Required

- `test_projects_workspace`：累计源码、材料补齐、原基线保持、未知工作区拒绝及原证明缺失时不重建 seed。
- `test_projects_cycles`：两空间自然名称、真实旧四字段与旧养号夹具、原输入字节保持、实际准备器 cwd/PYTHONPATH 与原生会话读取、账号/空间/轮次/seed 隔离、新旧混合和中断清理、重复注册、主动短名碰撞、未知自然目录、非法版本及链接拒绝。
- `test_projects_terminal`、`test_projects_quota`：合成原生 tmux 会话接续、隔离和额度补证；`test_projects_agent`、`test_projects_single_objective`、`test_projects_engine_cycles` 核对原任务优先、单目标边界和计划循环。
- 验证仅使用本地合成账号与进程，不调用真实模型、OAuth 或生产数据。

## Scenario: Pi 观察的事件唤醒与模型增量

### 1. Scope / Trigger

- 修改 `ProjectsService._observe`、`PiTerminal.observe`、作业 CLI 通知或 Pi 宿主工具回执时适用，项目与工程养号共用本契约。
- 终端流式正文和进度动画不应反复唤醒模型；交互仍交给 Pi 决定，控制端只等待和传递真实事实。

### 2. Signatures

```text
claude_observe({wait_sec?: integer = 30, full_screen?: boolean = false})
ProjectsService._observe(work: dict, generation: int, wait_sec: int, stop) -> dict
PiTerminal.observe(work: dict, cursor: int = 0) -> dict
ObservationView.project(result: object, full: boolean = false) -> object
ObservationView.reset() -> void
模型画面 = {observation_id, screen_mode: full|patch|unchanged,
            screen?, screen_base_observation_id?,
            screen_patch?: {start_line, delete_count, lines}, ...原观察事实}
通知 = {schema: 1, source, session_id, id, event, tool, observed_at}
```

### 3. Contracts

- `wait_sec` 是严格整数 0..30；首次、输入后及恢复执行后的观察即时获取现场，显式 0 保留即时语义。恢复仅清除旧 `observation_id`，保留完整原观察、游标、工作区和会话；重新观察后才允许输入。
- 本地每 0.5 秒检查控制代次、取消并采样；新原生文本、原生提问工具、相对上次变化的通知、退出、额度暂停及终端可读性变化优先返回。Docker/文件读取后再次校验取消和代次，不能让迟到观察推进输入授权；等待服从原本轮预算。
- 变化检测仅归一化已实测的固定 CLI 进度行、指定提示行和空白，不修改存储画面。忙碌期间合并流式正文；空闲或有编号选择界面时，有效画面稳定一秒便返回。无有效事件才等到截止时间；采样/读取及模型推理耗时另计，不能承诺所有终端形态的固定延迟。
- `projects_cli.py --config <本作业配置> --notify` 只在作业级 settings 追加 `PermissionRequest`、`PreToolUse`（`AskUserQuestion|ExitPlanMode`）和 `Stop` 通知，保留原钩子且重复安装幂等。输入至多 64 KiB，只写事件/工具名而不保存完整参数，不向 CLI 返回答案、授权或业务结论；失败退出 0，由原生记录和画面补充。
- 通知通过独占临时文件、0600、fsync 和原子替换发布。`runtime_json.interaction_signal` 须指向精确作业的 `runtime/jobs/<handle>/interaction.json`；读端拒绝链接/特殊文件及超过 4 KiB 内容，核对严格 schema、键集合、事件、32 位小写 hex 标识、有限正时间且不超当前 60 秒。`source` 必须等于 `<namespace>:<work_id>:<generation>`，同时匹配原 job 与 session；旧 runtime 无此字段时兼容。
- 原生 `AskUserQuestion/ExitPlanMode` 工具即使没有文本也返回 `interactions`；只保留工具名与标识，不把工具参数当答案。等待内游标单调前进，一旦有新文本/交互立即返回，不能越过未交付事件。通知只是唤醒提示，任何输入仍受最新观察、身份和未知投递保护。
- Python 存储及传给 Node 的结果保留完整 screen；只有宿主向模型投影。首次、进程重启、fresh、摘要成功或 `full_screen=true` 使用 full。相同画面使用 unchanged；其他画面用零基行号 `start_line`、删除行数及原始 `lines` 替换基线，按 `split('\n')`/`join('\n')` 必须精确还原。patch 的 UTF-8 JSON 字节不比 full 少时回退 full。
- patch/unchanged 必须引用上次交付的 `screen_base_observation_id`；只有合法观察推进基线，拒绝/取消不推进。状态、观察 ID、原生事件和交互提示保留。摘要成功后清空宿主基线，磁盘原文和页面快照继续读取原始完整观察，不存模型增量。镜像的 COPY 与上下文白名单必须同时分发 `observation-view.mjs`。

### 4. Validation & Error Matrix

| 条件 | 结果 |
| --- | --- |
| wait_sec 为 bool/非整数/越界，或 full_screen 非 bool | 工具 rejected，不推进观察 |
| 进度计时或忙碌流式正文持续刷新 | 本地合并等待，不额外产生模型请求或 usage |
| 新交互标记/原生提问，或无钩子的新稳定菜单 | 事件优先返回 / 约一秒去抖后返回 |
| 相同通知、旧 runtime 无通知、坏通知或其他会话内容 | 不重复唤醒 / 兼容原生和画面；归属定位冲突则拒绝 |
| 本轮停止/换代或输入后仍引用旧 observation_id | 拒绝迟到观察/输入，不能重复投递 |
| 无基线、摘要成功或显式请求整屏 | 返回 full，不能引用模型未见基线 |

### 5. Scenarios and Examples

- 正常：Pi 调用 `claude_observe({})` 后由本地等待；原生 `AskUserQuestion` 到达即返回当前画面，Pi 根据现场决定操作。
- 边界：屏幕没有变化时返回 unchanged 与基线 ID；`claude_observe({wait_sec:0,full_screen:true})` 立即读取真实整屏。patch 将基线拆行，在 `start_line` 删除 `delete_count` 行并插入 `lines` 后连接即可还原。
- 错误：看到两秒一次的 token 动画便请求模型，或拿恢复前的观察 ID 发送按键。正确：合并无效变化，恢复后先重观察；基线不明时用 full_screen=true，不猜菜单内容或重发未知输入。
- 费用证据：固定时间轨迹回放分别记录观察返回次数和载荷字节；mock 上游核对请求与 usage，无请求等待不计量。回放不代表真实模型后续决策、收费或所有业务的固定降幅。

### 6. Tests Required

- `test_projects_observation`：可控时钟的三十秒合并、流式正文、原生文本与游标、事件/重复标记、无钩子及与忙碌共存的编号菜单、默认/零等待、停止/换代、恢复后旧 ID 和严格参数。
- `test_pi_interaction`：真实通知子进程、原 settings 与幂等、无授权/参数泄漏、错误/超大/链接/FIFO、旧 runtime、原生无文本提问及两空间来源隔离。固定 CLI 2.1.293 的真实 Stop 钩子另以回环 mock 验证，不调用外部模型。
- `observation-view.test.mjs`：增删和尾换行精确还原、相同画面、较大 patch 回退、按需 full、reset 和拒绝不推进；`host.test.mjs` 核对真实 SDK 收到的 full/patch/full 与等待期间请求/usage 不增长，复用摘要及终止回归。
- `test_projects_agent/terminal/feed/store/single_objective/cycles/engine_cycles/quota`：最新观察输入保护、菜单/多行与未知投递、完整页面事实、双空间、停止恢复和目标收尾不变。

## Scenario: Python 补丁兼容与持久启动故障

### 1. Scope / Trigger

- 修改冻结环境准入、离线依赖缓存、原生验收的版本前置条件、Claude 启动故障、Pi 交接或页面恢复提示时适用。Projects、工程养号与 legacy 场景共享版本判断；两个工程空间共享故障合同。
- 兼容补丁差异只改变环境准入，冻结制品摘要、原回归节点／插件／结果、工作区身份、未知输入及严格清理仍受原合同约束。

### 2. Signatures

```python
python_versions_match(expected: str, actual: str, policy: str = 'minor') -> bool
python_plugins_match(expected: list[dict], actual: list[dict], policy: str = 'minor') -> bool
check_python_runtime(profile: dict, actual: str) -> dict
ProjectRuntimeError(code: str, message: str, *, retryable: bool = False,
                    phase: str = 'preparing', details: dict | None = None)
runtime_failure(error: BaseException, phase: str, context: dict | None = None) -> dict
write_runtime_failure(directory: Path, record: dict) -> Path | None
ProjectsTerminal.startup_recovery_ready(account: dict, work: dict) -> bool
```

- `projects_work.failure_json TEXT` 为可空新增列，初始化幂等升级；原 SQL 命名空间映射同样升级 `warmup_projects_work`。旧记录为 NULL，不追溯造数。
- 原状态、snapshot、历史列表／分页、work 详情和 SSE 的 work 投影增加 `failure: object | null`。既有前缀为 `/api/projects` 与 `/api/accounts/warmup/pi`；详情仍为 `GET <prefix>/work/{work_id}`，不增设错误 API。
- 真实启动故障的 `claude_start` 回执为 `{status:'waiting'|'rejected', message, controller_yield:true, failure}`；这不是 `project_submit` 的目标通过标志。
- 网络入口 `/usr/local/bin/v3-network-context` 的实际切换异常返回状态 1 和 `VIBEBENCH_NETWORK_ERROR_V1 <JSON>`；管理端仅接收匹配本次 `QUOTA_SOURCE` 的固定字段记录，以 `NetworkContextError(ValueError)` 保留私有事实，不透传任意 stderr。

### 3. Contracts

- `profile.python` 保留冻结验证版本；可选 `python_compatibility` 仅接受 `minor|exact`，默认 minor。版本只接受正常数字主次或主次补丁格式；minor 比较主次，exact 比较全部数字段及补丁是否存在。非法版本／策略不能默认为兼容。
- 原生插件元数据通过 `python_plugins_match` 统一比较。仅 `distribution='stdlib'` 的版本字段沿用 Python 兼容策略，`module_sha256`、模块身份、全部其他字段及列表顺序仍须精确相等；第三方插件的版本和源码摘要不放宽。比较不改写冻结或实测元数据，新控制器和已核历史控制器共用此规则。
- 每次准备都先探测实际解释器，命中缓存也执行。缓存仍按 `profile_digest` 定位；兼容复核后在证明中保存 `expected_python/actual_python/python_compatibility`，旧证明可补齐。补丁变化本身不重复安装相同固定 wheel。
- 独立验收将共享策略与 `native.json.python_profile` 暂存到只读 `/request-data`。环境不兼容输出 `VIBEBENCH_RUNTIME_ERROR_V1` 并返回 `status='error', reason='python_incompatible', details`；准备就绪后输出 `VIBEBENCH_PYTHON_RUNTIME_V1`，宿主复核并在报告保留 `python_runtime`。不能把环境拒绝算成业务失败。
- 历史 runner 适配仅接受 `_PYTHON_RUNNER_SHA256` 中已核来源，且旧版本比较与导入定位片段均唯一匹配。只在可信临时副本替换版本判断，并记录原始／实际摘要；原合同和冻结文件不改。与重复身份适配组合时仍反查原始字节；Arrow 外层入口的内层 runner 同样核源并只读暂存。新控制器的共享策略须在执行函数局部导入，兼容复制为隔离 worker 的运行方式。
- `failure` 包含字符串 `code/phase/message`、布尔 `retryable`、时间 `first_at/last_at`、整数 `attempt_count/generation`、可空 `retry_at/resolved_at` 及 `details`。message 至多 400 字符；details 仅允许 `expected_python/actual_python/python_compatibility/exception_type` 的至多 120 字符字符串，不透传任意异常正文、凭据或私有路径。
- 写故障必须在服务锁内确认当前 agent 代次、current_work、账号身份及非终态工作；合法恢复允许原 work 代次较旧。故障行、对应 error 事件和 agent 摘要同事务保存；同 code 且未解决才累计连续真实尝试，换原因或已恢复后重开序列。
- 临时故障在计划开启时，前三次失败分别保存 60／120／300 秒后的恢复时间，此后使用 `max(900, schedule_interval_sec)`；等待不持续调用模型。收尾时才开启计划或旧截止已过，必须保存至少 60 秒后的实际截止。计划关闭不安排自动重试；重启／计划认领不能提前该截止。
- 实际终端启动、基线及启动后门禁均确认后才设置 `resolved_at`、清空故障 retry_at 并记录 `runtime_recovered`。启动 Pi、开始准备或 Pi settled 均不算恢复。未解决故障优先于正常收尾，但后续明确的模型阻断、人工暂停／停止和新代次继续优先。
- 宿主仅对 `claude_start` 的 waiting／rejected、严格布尔 `controller_yield === true` 及字符串 `failure.code` 结束当前循环；先让 SDK 持久化原工具回执，同批后续工具及额外推理停止，不声明目标已通过。
- 页面当前目标、工程历史和详情读取同一事实，按 started_at 区分启动／恢复失败。自动重试时间使用当前工作对应账号的真实 `schedule.next_run_at`，历史工作不能借用当前计划；已停止先显示停止。所有外部文本转义，未保存配置不被 SSE 回填，旧记录正常展示。
- 私有启动诊断使用 schema1：`at/phase/context/exceptions`，可嵌套一层 `network`；仅保留固定账号／工作／代次／handle／source、异常类型、可用 errno 和栈的文件名／函数／行号。因果链最多 4 项、每项最多 32 帧、单记录最多 64 KiB；不读取异常正文、源码行、局部变量或任意上下文字段。网络端记录在 `/run/v3/diagnostics/<随机ID>.json`，管理端记录在 `<数据根>/<projects|warmup>/startup-failures/<随机ID>.json`，目录 0700、文件 0600、原子发布并拒绝链接；保存失败不覆盖原异常或放行执行。
- 原准备错误须在 cleanup 前留证；cleanup 再失败时独立记录并保留原因果链，公开阶段为 cleanup 时继续阻塞。`runtime_files.py` 共用原安全目录／原子发布实现，`account_runtime` 保留 `atomic_json/atomic_text` 导出；control 与 account 同批镜像都必须包含诊断及文件模块。
- 只有现有人工 start、`scheduled=False` 且 `recovering=False` 可以核对 `startup_unknown` 的未启动工作。须为 preparing，原 `started_at/segment_started_at/runtime_json` 为空、没有任何输入动作；在环境锁内重读环境，确认布局2、ready、三角色归属且运行、无内存／持久执行登记和评审交接、累计工作区注册唯一且合法、原生会话不存在，实际 `v3-cli-control orphans` 成功且为空。缺失／损坏／未知证据均拒绝，不创建环境或改写现场。
- 人工恢复仍核对原身份、授权、冻结合同、前置、额度与控制权，沿原事务重读工作／最近错误并原子保存 manual_retry 和新控制代次；不先清空 failure 或在事务外把工作改成 paused。自动扫描及服务 recover 不核发该许可；已开始过的工作、已有输入、未知收口和旧错误不能借本分支恢复。
- 监听进程的 `/proc` 文件已打开后退出可能返回 `ProcessLookupError / ESRCH`，与路径消失一样表示原进程已结束；未知 PID／内核启动时刻核验和定向 TERM／KILL 仍保持。socket 重试只包建连探测，CA 发布或 ACK 写入的 OSError 必须按原步骤失败并留证，不能被重试吞成监听超时。

### 4. Validation & Error Matrix

| 条件 | 故障／行为 |
| --- | --- |
| 3.12.15 → 3.12.16，默认 minor，标准库源码摘要相同 | 自动适配解释器及 doctest／unittest 的版本字段，保留实测版本；业务／回归条件不变 |
| 标准库源码摘要、插件身份／顺序／其他字段或第三方版本变化 | 拒绝原生回归准入，要求复核同平台原版基线；不能仅凭补丁兼容忽略源码变化 |
| 跨主次、exact 不满足或非法版本 | `python_incompatible`；profile 自身非法则校验拒绝 |
| 探测进程非零或账号资源暂占 | `python_probe_failed`／`runtime_busy`，可按计划等待 |
| 缓存证明冲突、制品摘要不符或离线安装失败 | `python_cache_invalid`／`artifact_invalid`／`offline_install_failed`，处理后显式重试 |
| 工作区归属冲突 | `workspace_conflict`，保留原现场，仍核对身份及未知输入 |
| 未知启动、基线或收口结果 | `startup_unknown`；固定说明和异常类型，先人工核对，不自动重发 |
| preparing 未启动、无输入，实际环境／工作区／进程证明全部通过 | 仅明确人工 start 接续原工作；真实启动成功前保留故障 |
| 已有输入／会话／运行时、曾启动、收口或归属未知、自动扫描／recover | 保留 blocked，不能以空运行时或旧清理回执放行 |
| `/proc` 打开后原进程退出／CA 或 ACK 写盘失败 | 前者按已结束继续；后者保存原阶段和 errno，不能伪装为连接重试 |
| 诊断路径为链接、他人可写或保存失败 | 不越界写入，不覆盖原故障，不解除执行门禁 |
| 迟到旧代次、已结束工作或账号身份变化 | 拒绝写入；不能复活计划或清除新状态 |
| Pi 正常结束、刷新或服务重启 | 保留未解决故障和真实次数；不覆盖后续明确模型错误 |

### 5. Scenarios and Examples

- 正常：`{"python":"3.12.15"}` 在 3.12.16 准备依赖并执行完整 Cerberus 原生回归；缓存及验收报告同时保留两个版本，原版业务仍应失败，参考实现应通过。
- 正常：ConfigObj 的冻结 doctest 版本为 3.12.15，实际为 3.12.16 且源码摘要相同，自动继续全部 79 个原生节点及 524 个补充示例。不能只放宽解释器而遗漏标准库元数据，也不能为兼容版本改写冻结合同。
- 边界：旧缓存只有 profile_digest，实测兼容后补齐证明；原工作较旧代次可恢复，重启不增加尝试次数。显式 `{"python":"3.12.15","python_compatibility":"exact"}` 在 3.12.16 返回明确环境拒绝。
- 错误：Pi settled 后改写成“正常结束”、把历史任务显示为当前计划的下次重试，或在每次计划到期重新请求模型解释同一确定故障。正确：读取持久 failure，历史停止任务保留停止说明，确定问题处理后从原入口恢复同一工作。
- 错误：把普通工具参数拒绝或未知执行结果加入自动重试白名单。正确：仅真实启动边界记录故障；显式恢复仍经过原身份、输入、额度、工作区及清理门禁。
- 正常：网络准备失败且没有发过输入，人工 start 取得实际空闲证明后接续原 work/session/cwd 和冻结设置；API/SSE 在实际启动确认后才展示故障已解除。
- 基础：`/proc/<pid>/cmdline` 已打开后，进程在读取前退出并返回 ESRCH；只移交原监听生命周期，不杀同 PID 的未知进程。CA 磁盘故障则保存 publish_ca／errno，而非反复探测端口。
- 错误：为排障保存 `str(error)`、完整 traceback 源码／locals，或把全部 startup_unknown 加入人工白名单。正确：使用固定字段私有记录，只对满足全部未启动证明的原目标开放人工恢复。

### 6. Tests Required

- `test_projects_runtime_resilience`：版本／策略边界、标准库兼容补丁及源码摘要／第三方版本／插件元数据漂移拒绝、输入不变、全部已核冻结来源及篡改拒绝、缓存实测、两空间故障投影、无模型空转、真实计数、成功才解除、重启截止、迟到取消、启动后异常脱敏及后续模型错误优先。
- `test_runtime_diagnostics`、`test_capture_settings_runtime`：原故障与清理故障独立、类型／errno／栈位置保持且合成敏感值不入记录，权限／拒绝链接／写入失败、网络协议来源和两空间 handle 归属；`test_startup_recovery` 以真实环境表和注册核对实际角色、原生会话、孤儿、执行登记和未知状态拒绝。
- `test_projects_runtime_resilience`、`test_projects_agent`：人工未启动恢复保留 work/session/冻结设置且只审计一次，自动扫描／recover、任何输入动作、已启动、运行时、cleanup／starting 和代次不符均拒绝；沿原身份／合同／授权门禁，不提前解除故障。
- `images/account/test_network_context.py` 用真实内核进程验证 stat/cmdline 已打开后的退出竞争，保留未知 PID 拒绝和定向强停；故障注入核 CA 错误只发布一次且保留阶段。`deploy/v3/verify_network_context.py --image <本地account镜像> --cycles 3` 在禁网合成容器内执行 7 次真实透传／抓包切换，核监听确认、持久 CA 和优雅收口，记录当前源码摘要；该底座覆盖测试不代替正式联合镜像和生产恢复验收。
- `test_project_native_verifier`、`test_project_duplicate_adapter`、`test_project_arrow_adapter`：环境错误分类与版本事实、组合适配、原文件不改及可信内层只读挂载；`test_project_native_regression` 继续核冻结节点与结果约束。
- `test_projects_pi_round` 和 `images/pi-agent/host.test.mjs`：真实 Python／Node／SDK 回执先落盘，故障交接仅一次上游请求，伪造／非布尔标志无效，混合批次及下一轮边界正确。
- 两个 `deploy/v3/verify_*pi*browser.py` 既有入口：API／SQLite／SSE 驱动真实 Chrome，核明暗主题、390／1280、刷新、次数／阶段／实际版本、恢复解除、XSS、旧历史不借当前时间和未保存配置保护。
- 实际核对为 3.12.16 的本地禁网容器：冻结 Cerberus 环境准备及缓存复用，原版失败、参考和完整原生回归通过；显式 exact 返回带期望／实际版本的环境错误。不以 mock 版本函数代替此证据。
- 同版禁网容器另核 ConfigObj 冻结原版及原线上候选：业务检查通过、79 个原生节点及 524 个补充示例全部匹配原合同；改变标准库源码摘要仍返回环境 error。`test_project_native_regression` 在补丁版本不同的真实 unittest 子进程中继续拒绝错误候选、跳过漂移和空集合。

## Scenario: Pi CLI 同代次恢复的启动尝试隔离

### 1. Scope / Trigger

- 修改 PiTerminal 的 Projects／工程养号启动、抓包监督、证明／许可／退出结果位置或原生额度补证游标时适用。
- 同一工作、同一控制代次可能恢复多次；稳定逻辑来源不能同时充当一次进程启动的文件身份。

### 2. Signatures

- PiTerminal.start(account: dict, work: dict) -> dict：返回原有 token/source/workspace/native 及交互、额度信号定位；不新增公开字段。
- PiTerminal.passive_status(work: dict) -> dict：按已核对的逻辑 source 读取原生额度补证。
- job.handle 是本次启动独立的 20 位小写十六进制标识，沿既有执行记录保存；source 仍为 namespace:work_id:generation。

### 3. Contracts

- 每次 start 独立分配 handle，runtime/jobs/<handle> 与 controls/<handle> 必须独占创建，任一路径已存在就拒绝；不得覆盖旧证明、许可、结果或设置覆盖。
- tmux socket、driver、process.json、start.json、process-result.json、交互及暂停信号都绑定本次 handle，后续读写从现有 job 定位。
- _attach_process 继续核 schema、source、PID、内核启动时刻、parent、UID 及真实进程存活；核验并登记后才发布匹配许可。新目录不能成为放宽进程校验或解除隔离的理由。
- 原工作 ID、Claude session、cwd、冻结版本／设置、累计预算、source 和额度归因不变；恢复仍依据原会话文件选择 resume。
- 原生补证游标维持 runtime/<namespace>-quota/<sha256(source)前20位>.json；启动时从原会话当时的字节末尾开始。游标不能跟随随机 handle 改名，否则 passive_status 会重读旧错误。
- Projects 和工程养号、capture 开启／关闭共用本合同；捕获模式继续使用 pi-capture 独立监督与既有 CA／Recorder 配置。
- 旧执行记录按原 schema 与已保存 handle 读取，不批量改写历史。未知启动、清理结果不确定和未对账输入继续保留原门禁，不能仅凭可写结果中的 cleaned=true 自动清除。

### 4. Validation & Error Matrix

| 条件 | 行为 |
| --- | --- |
| 同一工作同代次第二次启动，旧证明／许可／结果均存在 | 仅确认本次新进程，旧文件字节不变 |
| 同一会话已有认证或限额错误 | 从本次启动时字节边界观察，不把旧错误当新补证 |
| 随机标识碰撞已有目录 | 在创建 Docker exec 前拒绝，旧证明不改 |
| 证明来源、UID、parent、PID／启动时刻不符 | 保留原拒绝与隔离，不发放许可 |
| 新监督器尚未发布证明 | 等待本次位置的证明，不提前消费前一次文件 |
| 无法证明执行及输入已收口 | 保留现场，不能标记目标通过或重发未知输入 |

### 5. Scenarios and Examples

- 正常：同一个 projects 工作第一次结束后恢复，逻辑 source 和 session 相同，第二次 handle、证明与许可位置不同，匹配本次内核 PID 后启动。
- 边界：旧许可和新证明指向不同 PID 时，保留旧证据；新尝试只等待自己的许可。标识冲突则明确拒绝。
- 错误：把 sha256(source) 同时用于可复用的额度游标和每次启动证明目录。修正：额度游标保持稳定，运行目录按尝试独立，分别遵循各自生命周期。

### 6. Tests Required

- test_capture_settings_runtime.CaptureSettingsRuntimeTests.test_repeated_start_uses_current_proof_and_preserves_previous_attempt：两空间×两捕获模式，延迟发布新证明，确认旧 PID 不被采用、旧证明／许可／结果不被覆盖、原 session 续接且旧认证错误不重放。
- test_attempt_directory_collision_does_not_overwrite_old_proof：已有目录保持原字节，Docker exec 不创建。
- test_projects_quota、test_pi_interaction、test_projects_terminal、test_account_runtime 和运行环境／准入回归：原来源、会话、额度、交互与失败保护保持。
- 真实本地 Docker 监督器与合成 driver：重复启动的内核身份、许可、退出和定向清理均核对；测试无真实模型请求。捕获网络配置替身不能宣称验证完整生产 MITM 链路。

## Scenario: 项目与账号管理状态的有界只读查询

### 1. Scope / Trigger

- 修改项目、工程养号总览、账号卡片或 `runtime_bridge.rs` 的状态查询时适用。页面不得因复用执行准入而等待观察文件消费或执行准备长锁。

### 2. Signatures

```text
ProjectsService(..., *, namespace='projects', auto_cycle=False, view_admission=None)
ProjectsService.state(account_id=None, *, summary_only=False, proof_metadata=False) -> dict
ProjectsCatalog.proof_contract(work: dict, snapshots: dict) -> tuple[str, dict]
_projects_admission(account, work, *, snapshot_only=False) -> dict
_warmup_projects_admission(account, work, *, snapshot_only=False) -> dict
GET /runtime/api/projects
GET /runtime/api/projects/catalog
GET /runtime/api/accounts/warmup/pi
GET /runtime/api/accounts
```

### 3. Contracts

- 生产两空间通过 `view_admission=partial(..., snapshot_only=True)` 提供页面判定；省略该回调时沿用当前 `admission`。实际启动、恢复及输入仍调用严格 `admission`，不得用页面允许结果授权执行。
- 快照跳过 `QuotaGuard.consume`，读取已有持久额度和当前策略；不缓存跨请求的允许结果。读取执行登记用非阻塞锁，拿不到时返回 `allowed=False, reason='unavailable', retryable=True, retry_at=None`，页面消息为“执行状态正在更新，请稍后刷新”。不伪造空闲或额度充足。
- 完整状态保留原目标、进度、历史用量与校验信息。项目目录和自动轮次目标只在一次 `state()` 内复用；已传入当前身份时依赖检查不重复读取账号，未提供时仍读取。下一请求重新取事实。
- `view()` 单独启用 `proof_metadata=True`：页面对照当前账号通过记录、冻结项目 seed 摘要及完整目标合同；历史目录仅读取受限 catalog/项目 JSON，不构造历史 `ProjectLibrary`，不扫描源码或离线制品。按冻结路径、版本和项目复用正／负合同快照，仅在本次读取内有效，不缓存账号通过判定。当前已验证内容可复用内存合同。
- `proof_contract` 拒绝越界目录、符号链接、未登记项目、非法 schema/合同入口、损坏或重复目标。它只提供页面元数据；默认 `state()`、实际启动、恢复、输入和验收仍走原 `for_work` 及完整内容校验，不能把页面 ready 用作执行许可。
- SSE 生成器通过 `asyncio.to_thread` 读取同步事件与视图，保留原 cursor、Last-Event-ID、字段及断线行为；慢磁盘读取不得阻塞认证或其他请求所在的事件循环。
- 账号列表仅用 `state(..., summary_only=True)` 的 `status,message,controller_active,schedule,work`，包括已有工作纠错消息；该内部模式不计算卡片未使用的目标与历史统计，不改公开账号响应字段。
- 管理桥共享无默认认证头／Cookie 的 reqwest 连接池，base/token 每次读取并按请求设置，保留禁代理、禁跳转和路径／方法白名单。连接与会话验证／创建期限为5秒；验证成功读完小响应体以归还连接。
- 仅上列四个有限 JSON GET 转发具有10秒总请求期限；会话验证另计，不将10秒描述为整条浏览器请求总时限。SSE、WebSocket 和长写操作不套该状态期限；原退出与维护操作沿用自身期限。不新增环境键、数据库列或浏览器参数。

### 4. Validation & Error Matrix

| 条件 | 处理 |
| --- | --- |
| 后台持有额度消费锁 | 页面读持久快照；真实执行仍消费新观察 |
| 执行登记锁正忙 | 页面明确未知且不可放行；真实执行仍等待原锁 |
| 后续请求额度发生变化 | 重新判定，不复用此前允许结果 |
| 历史合同缺失、越界、链接或元数据损坏 | 不承认该前置证明；失败只在本次页面读取内复用，修复后下一请求重读 |
| 历史源码损坏但已有通过合同仍可读取 | 页面保留已接受合同事实；默认状态及真实执行继续完整校验，损坏内容不能因此启动 |
| 管理会话校验失败／网络超时 | 沿既有401／503错误，不泄露内部地址或凭据 |
| 有限 JSON 上游超过期限 | 响应头前沿既有503；已开始响应体时终止流，不声称可以改写已发送状态码 |
| SSE、长写操作或相似但未列入的路径 | 不加状态总期限，原鉴权及白名单继续生效 |

### 5. Scenarios and Examples

- 正常：页面读取 projects 和工程养号时不扫描消费日志；真正开始下一轮时继续消费观察并复核互斥与额度。
- 边界：执行准备正在持锁，页面及时显示暂不可读取；释放后刷新重新判断。两个账号引用同项目时本次只展开一次目录，下次仍读取新目录。
- 冷启动：首次打开历史较多的项目页，只核对冻结合同元数据；真正申请目标时再完整校验原冻结内容。不能让 SSE 在事件循环内同步扫描历史库。
- 错误：给全部管理请求统一设置10秒，截断事件订阅，或把快照允许结果用于启动。修正：仅限定四个普通 GET，执行保留原严格准入。

### 6. Tests Required

- `test_projects_admission`：真实线程持有额度／执行锁时快照及时完成且锁忙不可放行；严格执行等待并消费，后续请求看到新额度。
- `test_projects_feed`：真实页面使用快照回调；卡片五字段等价；多账号目录请求内复用、跨请求重读，进度与历史读取保持。
- `test_projects_catalog`、`test_projects_dependencies`：真实跨版本目录的合同元数据与完整合同等价、请求内复用、修复后重读、越界／链接／坏合同拒绝；破坏冻结源码后页面事实仍在，默认状态和真实启动拒绝。
- `test_projects_feed.test_sse_slow_reads_keep_the_event_loop_responsive`：同步事件和状态分别阻塞时，真实流生成器仍允许事件循环解除门闩，事件内容和游标保持。
- `runtime_bridge::tests`：本地 TCP 两次请求复用同一连接且无默认凭据；仅有限状态 GET 设置期限，SSE、长写及相似路径排除；既有路径白名单回归。
