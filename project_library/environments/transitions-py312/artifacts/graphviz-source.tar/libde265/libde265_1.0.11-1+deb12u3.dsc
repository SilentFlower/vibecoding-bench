-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: libde265
Binary: libde265-0, libde265-dev, libde265-examples
Architecture: any
Version: 1.0.11-1+deb12u3
Maintainer: Debian Multimedia Maintainers <debian-multimedia@lists.debian.org>
Uploaders: Alessio Treglia <alessio@debian.org>, Joachim Bauch <bauch@struktur.de>
Homepage: https://github.com/strukturag/libde265
Standards-Version: 4.6.2
Vcs-Browser: https://salsa.debian.org/multimedia-team/libde265
Vcs-Git: https://salsa.debian.org/multimedia-team/libde265.git
Build-Depends: debhelper-compat (= 13), qtbase5-dev | libqt4-dev, libsdl-dev, libswscale-dev, libx11-dev, libxext-dev, pkg-config
Package-List:
 libde265-0 deb libs optional arch=any
 libde265-dev deb libdevel optional arch=any
 libde265-examples deb video optional arch=any
Checksums-Sha1:
 107e0bc48b2748adfd535e15186d0f84a6e152fe 845996 libde265_1.0.11.orig.tar.gz
 7c000fdb548133c97487f7f6f82188aa0b67a028 28308 libde265_1.0.11-1+deb12u3.debian.tar.xz
Checksums-Sha256:
 2f8f12cabbdb15e53532b7c1eb964d4e15d444db1be802505e6ac97a25035bab 845996 libde265_1.0.11.orig.tar.gz
 ccdd55e4bf2aa04155de5d00fbc677e4cf620d961fd4584a43a37f13993d0f94 28308 libde265_1.0.11-1+deb12u3.debian.tar.xz
Files:
 2b07416559819212aed2fd75f74fd393 845996 libde265_1.0.11.orig.tar.gz
 cf1b5784c5a1b7ec3f4936c6fca4c260 28308 libde265_1.0.11-1+deb12u3.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEE/d0M/zhkJ3YwohhskWT6HRe9XTYFAmqvybgACgkQkWT6HRe9
XTZ8hg//Ud1tLnNrh8ff69/adokq8SH4UOmjqOOCZJr3FDmoYxO2kD8XVdo31z4q
Nj980mhx83SQn0FSmkraYCH4uAi4IXgPrG8HvlP1FoDZXI2Bp3r9Vod5KGagPoDX
nvUSCqkARgazsOKdXhB2KWtM0pT1ae6ZnIK8TSR7c6USqRKJgiEktXI4VUEL8/V7
mlKmwxbhGHqavdL1xsk9qzYun765JJAsNJX1OTJhe4RWaDmvvo+SAwueyvF1J/hi
ogLt4GoOuzww+WXiMLyi3dPcGo9L6n8kdmZnRdJHOSdffLqC6pwZFRiODzZw9rie
vmwiSNqMfSbZCVCSzCpvB1/0SvwrLyG/rKPtEAfx33nvpwZDZmx0AcgmENY6pyMF
NWJ1UWnmqFNSiuTMfq7QhGNCt5ZFeGnpJyYmRSZDj7zzO4QBMWsXWbl+x+JoW+o9
jLDZb5SZ9r2v76Gli9d2u0+BFBv+VVTOx40hWl9QAYwe2/KbJbpul/0gMTQMxnLH
2C0tLvaxBhdImM53zu49CdATkmoUMAZ2DtGn7fm8RnDq8fcWEsPG/kv9/98PC0Zz
pIopNWblR77ndNMhEtvTQBVEEbHq5Og6xN7Yi7Qx95NDYARy+6g2Jo+evT3H+BB8
T2qyl2qf8QKxAgzDeekMjWjaLm3WCvnpaa/b+o5NfWbhRZcjJxc=
=WjqH
-----END PGP SIGNATURE-----
