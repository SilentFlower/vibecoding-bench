-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: graphite2
Binary: libgraphite2-3, libgraphite2-dev, libgraphite2-doc, libgraphite2-utils, python3-graphite2
Architecture: any all
Version: 1.3.14-1+deb12u1
Maintainer: Debian LibreOffice Maintainers <debian-openoffice@lists.debian.org>
Uploaders:  Rene Engelhard <rene@debian.org>, Daniel Glassey <wdg@debian.org>,
Homepage: http://graphite.sil.org/
Standards-Version: 4.4.1
Vcs-Browser: https://salsa.debian.org/libreoffice-team/graphite2
Vcs-Git: https://salsa.debian.org/libreoffice-team/graphite2.git
Testsuite: autopkgtest
Testsuite-Triggers: @builddeps@, dpkg-dev, python3-all
Build-Depends: cmake, debhelper-compat (= 12), dh-exec (>= 0.3), dh-python, dpkg-dev (>= 1.18.2~), python3:native (>= 3.6), python3-fonttools <!nocheck>
Build-Depends-Indep: asciidoc-dblatex, docbook-xsl, doxygen, graphviz, libxml2-utils, python3-all, python3-setuptools, texlive-latex-recommended
Package-List:
 libgraphite2-3 deb libs optional arch=any
 libgraphite2-dev deb libdevel optional arch=any
 libgraphite2-doc deb doc optional arch=all
 libgraphite2-utils deb fonts optional arch=any
 python3-graphite2 deb python optional arch=all
Checksums-Sha1:
 768d478d300253a855a7a15ba1e59b56d06ad01c 6629829 graphite2_1.3.14.orig.tar.gz
 f0e41bf7beccadb124d4e6a999b1c38dc5be290e 12704 graphite2_1.3.14-1+deb12u1.debian.tar.xz
Checksums-Sha256:
 7a3b342c5681921ce2e0c2496509d30b5b078399d5a7bd2358f95166d57d91df 6629829 graphite2_1.3.14.orig.tar.gz
 be4152789f52a51ee90102daadb7f4b37069c9e22f2959a17bfcfffa9c859167 12704 graphite2_1.3.14-1+deb12u1.debian.tar.xz
Files:
 a3cb1dc0032a5875e2eaa4ed57cd38b1 6629829 graphite2_1.3.14.orig.tar.gz
 f95e28ae6324f766629780e30a84b998 12704 graphite2_1.3.14-1+deb12u1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQJEBAEBCgAuFiEE4S3qRnUGcM+pYIAdCqBFcdA+PnAFAmokbuwQHHJlbmVAZGVi
aWFuLm9yZwAKCRAKoEVx0D4+cM7pD/41Rz6ClYNAq7lzj3SMG/odSn52WQEHSivq
8A86pFiIrvv7OG0gFPjHwpUEeh5xrZAaAovF4Is52nfhytaPTHFYsDDZSyBv1dIy
t4pRp6BFN1oq4/KZmGqAbKGJtDPI7OCkFeABU3x/+jipBzIIAuHZNpL7FXOGawdk
GA5tlYKE4EVbMdwy0Sv7BuoUdsVsZN/yoExCjk30fk7pTU0RrkY1F2cqDL5QL6i8
+xStKkjPfJnnHSBvoyoqILNwG+VkwGslEIIkkTuMFY4+y0Q6/6cQPcVmammfzs4S
3Nw+5kQ0szp88B7DeDltPJ5ao7sWNoZirS9BdDycEv/uLhDAcFbh+B6b635q7V05
AE0K5HtJI8iqqO/p4xgxHx/1tx5fqPBe+FQS29lZwHlFZ/lHiCh+oPZvM+9fSzl6
uscnuKeZTJo9qZh6+TjzHLAZEQSjIinX8F1cJDdXjRWGAMJb+M2NGYOeHamhSRU/
1nIOeAsFyQkOQPAin+xCcwBo3PX+dt038Uht89J0gXmBtnLfNKyv1Ew79hMxTuOm
Zs2yQxUiI9YoTYbUCP3nankFw6Qnbzz/Cf2LpLbHG9s0VfP/vKugftPgVZvYM9PK
3pfy5Zs4qehI0BKiWiJGwAkN2Hw2SpCcrNZm1s/xRJK1mtbXjh3yqOyNYqiiVakK
AC6OCWyvUw==
=iIxK
-----END PGP SIGNATURE-----
