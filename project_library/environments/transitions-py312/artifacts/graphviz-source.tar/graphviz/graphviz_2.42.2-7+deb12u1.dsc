-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: graphviz
Binary: graphviz, libgv-guile, libgv-lua, libgv-perl, python3-gv, libgv-ruby, libgv-tcl, libcgraph6, libcdt5, libpathplan4, libgvc6, libgvc6-plugins-gtk, libgvpr2, libxdot4, liblab-gamut1, libgraphviz-dev, graphviz-doc
Architecture: any all
Version: 2.42.2-7+deb12u1
Maintainer: Laszlo Boszormenyi (GCS) <gcs@debian.org>
Homepage: https://www.graphviz.org/
Standards-Version: 4.5.0
Testsuite: autopkgtest
Testsuite-Triggers: file
Build-Depends: tk-dev, tcl-dev, debhelper-compat (= 11), dh-python, libfreetype6-dev, zlib1g-dev, libjpeg-dev, libpng-dev, libxaw7-dev, bison, flex, libexpat1-dev, libfontconfig1-dev, swig, libperl-dev, libgd-dev (>= 2.0.33), guile-3.0-dev, groff-base, ghostscript, lua5.2, liblua5.2-dev, ruby [!ia64], ruby-dev (>= 1:2.2) [!ia64], libargon2-dev, libsodium-dev, libxml2-dev, python3-dev, libcairo2-dev, libpango1.0-dev, d-shlibs, chrpath, libgtk2.0-dev, libgts-dev, libann-dev, librsvg2-dev, libwebp-dev
Build-Conflicts: tcl8.3, tcl8.4, tcl8.5
Package-List:
 graphviz deb graphics optional arch=any
 graphviz-doc deb doc optional arch=all
 libcdt5 deb libs optional arch=any
 libcgraph6 deb libs optional arch=any
 libgraphviz-dev deb libdevel optional arch=any
 libgv-guile deb interpreters optional arch=any
 libgv-lua deb interpreters optional arch=any
 libgv-perl deb perl optional arch=any
 libgv-ruby deb ruby optional arch=any
 libgv-tcl deb interpreters optional arch=any
 libgvc6 deb libs optional arch=any
 libgvc6-plugins-gtk deb libs optional arch=any
 libgvpr2 deb libs optional arch=any
 liblab-gamut1 deb libs optional arch=any
 libpathplan4 deb libs optional arch=any
 libxdot4 deb libs optional arch=any
 python3-gv deb python optional arch=any
Checksums-Sha1:
 ee6638494542714ca8f2aa2316312bb4a3884bd6 30740923 graphviz_2.42.2.orig.tar.bz2
 4daa32e23c9bb9e155b38ecc8b0372bb4901e563 39368 graphviz_2.42.2-7+deb12u1.debian.tar.xz
Checksums-Sha256:
 1daed697d9cdd7fac3b320336fa98dd3518dd211769301dc716869fc3d5409b1 30740923 graphviz_2.42.2.orig.tar.bz2
 dab1f57fd7bf36a4bf1518f1618b28213dfeaec04dcb427eaf218d26b4a6c0c3 39368 graphviz_2.42.2-7+deb12u1.debian.tar.xz
Files:
 0d0fb3cf249ee2faf86bf82b1e443902 30740923 graphviz_2.42.2.orig.tar.bz2
 b3698768bd353c07090555020f5dddf1 39368 graphviz_2.42.2-7+deb12u1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEfYh9yLp7u6e4NeO63OMQ54ZMyL8FAmbA8p0ACgkQ3OMQ54ZM
yL+Rqg//TBpgdRo2xzw/lYgRplmawjHfoViaNoZg/wr8D+snQyjlgsB4zIy2AR70
Dfo5yKNyE1flL1Z3XjAMFGTZRkIx85gAAn0yxleRK650jkA5vRr5DHUVkJ49ZGI0
PJO6dKrILyDH7yEJbRrAe191vVirskGab6dnCfhZuWqMUOJ7F+al/UKfimAnD+BH
D4FZzuYeb877N74CxWzgBAdwZ0Nrpp2HQxUnddsojgEirWcfML9vFk3WZF9iD3am
SlBeq2EsOnQuvYo4hlE0scD3P350v5/SIm+Ba7aDIhYNjtA4AK9VKtkvd3roTy8A
fxgLHd5QuZp0+800KQD/7MqHp8EmeryJJVJ4AXIkkPsX2TSEnuJ+NNGiXv5j1Rvv
jZolcregXDMlrHcWzv38uZNc6lBOou5cF7b7TxUGwFOl+1KgpPYVa6rMKK+YDkAF
oDuDXYWmAFqMDv9aSu4f0qG0tkjGz0no+XcTt49hJeVJX8EvO4RGTgN+GMBQ9kxm
+4/tONvzibdc25DnI0Xes5oaht6XFXbi1UuZwK6D2Yx/YwbcF+Po/oG8Wg6/6SFB
lYl9tUQEVboiQOF7LVGXi60RsqpiEJh6TSpJV1iHddLr4I2+7S5pkDaBpQEb60GD
hqRKHupe6/X1NXABeDGsUdguVaK0jOLj13sJ0Y/pgCEb9+1AGlc=
=5mmp
-----END PGP SIGNATURE-----
