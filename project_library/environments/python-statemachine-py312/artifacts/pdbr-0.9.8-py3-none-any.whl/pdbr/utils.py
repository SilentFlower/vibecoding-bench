import atexit
import configparser
import logging
import os
from pathlib import Path

from pdbr._pdbr import rich_pdb_klass

try:
    import readline
except ImportError:
    try:
        from pyreadline3 import Readline

        readline = Readline()
    except ModuleNotFoundError:
        readline = None
except AttributeError:
    readline = None


def set_history_file(history_file):
    """
    This is just for Pdb,
    For Ipython, look at RichPdb.pt_init
    """
    if readline is None:
        return
    try:
        readline.read_history_file(history_file)
        readline.set_history_length(1000)
    except FileNotFoundError:
        pass
    except OSError:
        pass

    atexit.register(readline.write_history_file, history_file)


def set_traceback(theme, show_locals=False):
    from rich.traceback import install

    install(theme=theme, show_locals=show_locals)


def read_config():
    style = None
    theme = None
    store_history = ".pdbr_history"
    context = None

    config = configparser.ConfigParser()
    config.sections()

    setup_filename = "setup.cfg"
    xdg_config_home = Path(os.getenv("XDG_CONFIG_HOME", Path.home() / ".config"))
    global_config_path = xdg_config_home / "pdbr" / setup_filename
    cwd_config_path = Path.cwd() / setup_filename
    config_path = cwd_config_path.exists() and cwd_config_path or global_config_path

    config.read(config_path)
    if "pdbr" in config:
        if "style" in config["pdbr"]:
            style = config["pdbr"]["style"]

        if "theme" in config["pdbr"]:
            theme = config["pdbr"]["theme"]

        use_traceback = config["pdbr"].getboolean("use_traceback", fallback=True)
        show_locals = config["pdbr"].getboolean("traceback_show_locals", fallback=False)
        if use_traceback:
            set_traceback(theme, show_locals=show_locals)

        if "store_history" in config["pdbr"]:
            store_history = config["pdbr"]["store_history"]

        if "context" in config["pdbr"]:
            context = config["pdbr"]["context"]

    _apply_log_capture_config(config)

    history_file = str(Path.home() / store_history)
    set_history_file(history_file)
    ipython_history_file = f"{history_file}_ipython"

    return style, theme, history_file, ipython_history_file, context


def _apply_log_capture_config(config):
    from pdbr.logging import install_log_capture

    section = config["pdbr.log"] if "pdbr.log" in config else None

    if section is None:
        install_log_capture()
        return

    enabled = section.getboolean("enabled", True)
    buffer_size = section.getint("buffer_size", 500)
    level_name = section.get("level", "WARNING").upper()
    level = getattr(logging, level_name, logging.WARNING)

    install_log_capture(buffer_size=buffer_size, level=level, enabled=enabled)


def debugger_cls(
    klass=None, console=None, context=None, is_celery=False, show_layouts=True
):
    if klass is None:
        try:
            from IPython.terminal.debugger import TerminalPdb

            klass = TerminalPdb
        except ImportError:
            from pdb import Pdb

            klass = Pdb

    style, theme, history_file, ipython_history_file, config_context = read_config()
    RichPdb = rich_pdb_klass(
        klass,
        console=console,
        context=context if context is not None else config_context,
        is_celery=is_celery,
        show_layouts=show_layouts,
    )
    RichPdb._style = style
    RichPdb._theme = theme
    RichPdb._history_file = history_file
    RichPdb._ipython_history_file = ipython_history_file

    return RichPdb


def _pdbr_cls(console=None, context=None, return_instance=True, show_layouts=True):
    klass = debugger_cls(console=console, context=context, show_layouts=show_layouts)
    if return_instance:
        return klass()
    return klass


def _rdbr_cls(return_instance=True):
    try:
        from celery.contrib import rdb

        rdb.BANNER = """\
{self.ident}: Type `pdbr_telnet {self.host} {self.port}` to connect

{self.ident}: Waiting for client...
"""
    except ModuleNotFoundError as error:
        raise type(error)("In order to install celery, use pdbr[celery]") from error

    klass = debugger_cls(klass=rdb.Rdb, is_celery=True, show_layouts=False)
    if return_instance:
        return klass()
    return klass
