# Author: Óscar Nájera
# License: 3-clause BSD
"""Test the SG pipeline used with Sphinx and tinybuild."""

import itertools
import json
import os
import re
import shutil
import subprocess
import sys
import time
from io import StringIO
from pathlib import Path

import lxml.etree
import lxml.html
import pytest
from sphinx.application import Sphinx
from sphinx.errors import ExtensionError
from sphinx.util.docutils import docutils_namespace

from sphinx_gallery.utils import (
    _W_KW,
    _has_graphviz,
    _has_optipng,
    _has_pypandoc,
    scale_image,
)

# file inventory for tinybuild:

# The following numbers accumulate values across the sub-galleries
# - tinybuild/examples
# - tinybuild/examples_rst_index
# - tinybuild/examples_with_rst
# - tinybuild/examples_README_header
#
# total number of plot_*.py files in
# (examples + examples_rst_index + examples_with_rst + examples_README_header)
N_EXAMPLES = 20 + 3 + 2 + 1
N_FAILING = 4
N_GOOD = N_EXAMPLES - N_FAILING  # galleries that run w/o error
# passthroughs and non-executed examples in
# (examples + examples_rst_index + examples_with_rst + examples_README_header)
N_PASS = 4 + 0 + 2 + 0
# indices SG generates  (extra non-plot*.py file) in
# (examples + examples_rst_index + examples_with_rst + examples_README_header)
N_INDEX = 2 + 1 + 3 + 1
# SG execution times
# (examples + examples_rst_index + examples_with_rst + examples_README_header + root-level)
N_EXECUTE = 2 + 3 + 1 + 1 + 1
# gen_modules + sg_api_usage + doc/index.rst + minigallery.rst
N_OTHER = 12 + 1 + 1 + 1 + 1
N_RST = N_EXAMPLES + N_PASS + N_INDEX + N_EXECUTE + N_OTHER
# these fail or are retried on every build, so their measured time always changes --
# including rounding to zero on a coarse (Windows) clock
_RERUN_EXAMPLES = (
    "plot_failing_example.py",
    "plot_failing_example_thumbnail.py",
    "plot_scraper_broken.py",
    "plot_future_imports_broken.py",
)

pytest.importorskip("jupyterlite_sphinx")  # needed for tinybuild
manim = pytest.importorskip("matplotlib.animation")
if not manim.writers.is_available("ffmpeg"):
    pytest.skip("ffmpeg is not available", allow_module_level=True)
pytest.importorskip("joblib")

# Under `pytest -n`, keep this whole module on one worker and in collection
# order: the tests share the module-scoped `sphinx_app` build, and `test_rebuild`
# mutates that source tree for the tests that follow it.
pytestmark = pytest.mark.xdist_group("tinybuild")


@pytest.fixture(scope="module")
def sphinx_app(tmp_path_factory, req_mpl, req_pil):
    return _sphinx_app(tmp_path_factory, "html")


@pytest.fixture(scope="module")
def sphinx_dirhtml_app(tmp_path_factory, req_mpl, req_pil):
    return _sphinx_app(tmp_path_factory, "dirhtml")


def _sphinx_app(tmp_path_factory, buildername):
    # Skip if numpy not installed
    pytest.importorskip("numpy")

    temp_dir = tmp_path_factory.getbasetemp() / f"root_{buildername}"
    src_dir = Path(__file__).parent / "tinybuild"

    def ignore(src, names):
        return (
            "_build",
            "gen_modules",
            "auto_examples",
            "auto_examples_README_header",
            "auto_examples_rst_index",
            "auto_examples_with_rst",
        )

    shutil.copytree(src_dir, temp_dir, ignore=ignore)
    # For testing iteration, you can get similar behavior just doing `make`
    # inside the tinybuild/doc directory
    conf_dir = temp_dir / "doc"
    out_dir = conf_dir / "_build" / buildername
    toctrees_dir = conf_dir / "_build" / "toctrees"
    # Avoid warnings about re-registration, see:
    # https://github.com/sphinx-doc/sphinx/issues/5038
    with docutils_namespace():
        app = Sphinx(
            conf_dir,
            conf_dir,
            out_dir,
            toctrees_dir,
            buildername=buildername,
            status=StringIO(),
            warning=StringIO(),
        )
        # need to build within the context manager
        # for automodule and backrefs to work
        app.build(False, [])
    return app


def test_timings(sphinx_app):
    """Test that a timings page is created."""
    out_dir = sphinx_app.outdir
    src_dir = sphinx_app.srcdir

    # local folder
    timings_rst = Path(src_dir, "auto_examples", "sg_execution_times.rst")
    assert timings_rst.is_file()
    content = timings_rst.read_text(encoding="utf-8")
    assert ":ref:`sphx_glr_auto_examples_plot_numpy_matplotlib.py`" in content
    parenthetical = "(``plot_numpy_matplotlib.py``)"
    assert parenthetical in content
    # HTML output
    timings_html = Path(out_dir, "auto_examples", "sg_execution_times.html")
    assert timings_html.is_file()
    content = timings_html.read_text(encoding="utf-8")
    assert 'href="plot_numpy_matplotlib.html' in content
    # printed
    status = sphinx_app._status.getvalue()
    fname = Path("..", "examples", "plot_numpy_matplotlib.py")
    assert f"- {fname}: " in status


def test_api_usage(sphinx_app):
    """Test that an api usage page is created."""
    out_dir = sphinx_app.outdir
    src_dir = sphinx_app.srcdir
    # the rst file is kept so that unchanged rebuilds can skip the page
    api_rst = Path(src_dir, "sg_api_usage.rst")
    assert api_rst.is_file()
    assert "Unused API Entries" in api_rst.read_text(encoding="utf-8")
    if _has_graphviz():
        assert Path(src_dir, "sg_api_unused.dot").is_file()
    # HTML output
    api_html = Path(out_dir, "sg_api_usage.html")
    assert api_html.is_file()
    content = api_html.read_text(encoding="utf-8")
    has_graphviz = _has_graphviz()
    # spot check references
    assert (
        'href="gen_modules/sphinx_gallery.gen_gallery.html'
        '#sphinx_gallery.gen_gallery.setup"'
    ) in content
    # check used and unused
    if has_graphviz:
        assert 'alt="API unused entries graph"' in content
        if sphinx_app.config.sphinx_gallery_conf["show_api_usage"]:
            assert 'alt="sphinx_gallery usage graph"' in content
        else:
            assert 'alt="sphinx_gallery usage graph"' not in content
        # check graph output
        assert 'src="_images/graphviz-' in content
    else:
        assert 'alt="API unused entries graph"' not in content
        assert 'alt="sphinx_gallery usage graph"' not in content
    # printed
    status = sphinx_app._status.getvalue()
    fname = Path("..", "examples", "plot_numpy_matplotlib.py")
    assert f"- {fname}: " in status


def test_optipng(sphinx_app):
    """Test that optipng is detected."""
    status = sphinx_app._status.getvalue()
    w = sphinx_app._warning.getvalue()
    substr = "will not be optimized"
    if _has_optipng():
        assert substr not in w
    else:
        assert substr in w
    assert "optipng version" not in status.lower()  # catch the --version


def test_junit(sphinx_app, tmp_path):
    """Test junit output."""
    out_dir = sphinx_app.outdir
    junit_file = Path(out_dir) / "sphinx-gallery" / "junit-results.xml"
    assert junit_file.is_file()
    contents = junit_file.read_bytes()
    suite = lxml.etree.fromstring(contents)
    want = dict(
        errors="0",
        failures="0",
        skipped="4",
        tests=f"{N_EXAMPLES}",
        name="sphinx-gallery",
    )
    got = dict(suite.attrib)
    del got["time"]
    assert got == want
    contents = contents.decode("utf-8")
    assert "local_module" not in contents  # it's not actually run as an ex
    assert "expected example failure" in contents
    assert "<failure message" not in contents
    src_dir = Path(sphinx_app.srcdir)
    new_root_dir = tmp_path / "src"
    shutil.copytree(src_dir.parent, new_root_dir)
    del src_dir
    new_src_dir = new_root_dir / "doc"
    new_out_dir = new_src_dir / "_build" / "html"
    new_toctree_dir = new_src_dir / "_build" / "toctrees"
    new_examples_dir = new_src_dir.parent / "examples"
    # swap numpy_matplotlib (passing) with future_imports_broken (failing)
    passing_fname = new_examples_dir / "plot_numpy_matplotlib.py"
    failing_fname = new_examples_dir / "future" / "plot_future_imports_broken.py"
    print("Names", passing_fname, failing_fname)
    shutil.move(passing_fname, passing_fname.with_suffix(".temp"))
    shutil.move(failing_fname, passing_fname)
    shutil.move(passing_fname.with_suffix(".temp"), failing_fname)
    shutil.copyfile(
        new_examples_dir / "local_module.py",
        new_examples_dir / "future" / "local_module.py",
    )
    with docutils_namespace():
        app = Sphinx(
            new_src_dir,
            new_src_dir,
            new_out_dir,
            new_toctree_dir,
            buildername="html",
            verbosity=1,
        )
        # need to build within the context manager
        # for automodule and backrefs to work
        with pytest.raises(ExtensionError, match="Here is a summary of the "):
            app.build(False, [])
    junit_file = new_out_dir / "sphinx-gallery" / "junit-results.xml"
    assert junit_file.is_file()
    suite = lxml.etree.fromstring(junit_file.read_bytes())
    # this time we only ran the stale files
    want.update(failures="2", skipped="3", tests="5")
    got = dict(suite.attrib)
    del got["time"]
    skips_and_fails = [
        {
            "classname": "plot_failing_example",
            "tag": "skipped",
            "message": None,
        },
        {
            "classname": "plot_failing_example_thumbnail",
            "tag": "skipped",
            "message": None,
        },
        {
            "classname": "plot_numpy_matplotlib",
            "tag": "failure",
            "message": "RuntimeError: Forcing",
        },
        {
            "classname": "plot_scraper_broken",
            "tag": "skipped",
            "message": None,
        },
        {
            "classname": "plot_future_imports_broken",
            "tag": "failure",
            "message": "Passed even though it was marked to fail",
        },
    ]
    assert len(suite) == len(skips_and_fails)
    for this_suite, this_example in zip(suite, skips_and_fails):
        assert this_suite.attrib["classname"] == this_example["classname"]
        assert this_suite[0].tag == this_example["tag"], this_suite.attrib["classname"]
        if this_example["message"] is not None:
            assert this_suite[0].attrib["message"].startswith(this_example["message"])
    assert got == want


def test_run_sphinx(sphinx_app):
    """Test basic outputs."""
    out_dir = Path(sphinx_app.outdir)
    assert (out_dir / "index.html").is_file()
    assert (out_dir / "auto_examples_with_rst").is_dir()
    assert (out_dir / "auto_examples_rst_index").is_dir()
    assert (out_dir / "auto_examples_README_header").is_dir()
    generated_examples_dir = out_dir / "auto_examples"
    assert generated_examples_dir.is_dir()
    # make sure that indices are properly being passed forward...
    files_to_check = [
        "auto_examples_rst_index/examp_subdir1/index.html",
        "auto_examples_rst_index/examp_subdir2/index.html",
        "auto_examples_rst_index/index.html",
    ]
    for f in files_to_check:
        assert (out_dir / f).is_file()
    status = sphinx_app._status.getvalue()
    assert f"executed {N_GOOD} out of {N_EXAMPLES}" in status
    assert "after excluding 0" in status


def test_user_index_download(sphinx_app):
    """Test download zipfiles still generated when user supplies index.rst"""
    src_dir = Path(sphinx_app.srcdir) / "auto_examples_rst_index"
    assert (src_dir / "auto_examples_rst_index_jupyter.zip").is_file()
    assert (src_dir / "auto_examples_rst_index_python.zip").is_file()


def test_thumbnail_path(sphinx_app, tmp_path):
    """Test sphinx_gallery_thumbnail_path."""
    import numpy as np
    from PIL import Image

    # Make sure our thumbnail matches what it should be
    fname_orig = str(Path(sphinx_app.srcdir, "_static_nonstandard", "demo.png"))
    fname_thumb = Path(
        sphinx_app.outdir, "_images", "sphx_glr_plot_second_future_imports_thumb.png"
    )
    fname_new = str(tmp_path / "new.png")
    scale_image(
        fname_orig, fname_new, *sphinx_app.config.sphinx_gallery_conf["thumbnail_size"]
    )
    orig = np.asarray(Image.open(fname_thumb))
    new = np.asarray(Image.open(fname_new))
    assert new.shape[:2] == orig.shape[:2]
    assert new.shape[2] in (3, 4)  # optipng can strip the alpha channel
    corr = np.corrcoef(new[..., :3].ravel(), orig[..., :3].ravel())[0, 1]
    assert corr > 0.99


def test_negative_thumbnail_config(sphinx_app, tmp_path):
    """Test 'sphinx_gallery_thumbnail_number' config correct for negative numbers."""
    import numpy as np
    from PIL import Image

    # Make sure our thumbnail is the 2nd (last) image
    fname_orig = str(
        Path(sphinx_app.outdir, "_images", "sphx_glr_plot_matplotlib_alt_002.png")
    )
    fname_thumb = Path(
        sphinx_app.outdir, "_images", "sphx_glr_plot_matplotlib_alt_thumb.png"
    )
    fname_new = str(tmp_path / "new.png")
    scale_image(
        fname_orig, fname_new, *sphinx_app.config.sphinx_gallery_conf["thumbnail_size"]
    )
    orig = np.asarray(Image.open(fname_thumb))
    new = np.asarray(Image.open(fname_new))
    assert new.shape[:2] == orig.shape[:2]
    assert new.shape[2] in (3, 4)  # optipng can strip the alpha channel
    corr = np.corrcoef(new[..., :3].ravel(), orig[..., :3].ravel())[0, 1]
    assert corr > 0.99


def test_thumbnail_expected_failing_examples(sphinx_app, tmp_path):
    """Test thumbnail behaviour for expected failing examples."""
    import numpy as np
    from PIL import Image

    # Get the "BROKEN" stamp for the default failing example thumbnail
    stamp_fname = str(
        Path(sphinx_app.srcdir, "_static_nonstandard", "broken_example.png")
    )
    stamp_fname_scaled = str(tmp_path / "new.png")
    scale_image(
        stamp_fname,
        stamp_fname_scaled,
        *sphinx_app.config.sphinx_gallery_conf["thumbnail_size"],
    )
    broken_stamp = np.asarray(Image.open(stamp_fname_scaled))
    assert broken_stamp.shape[2] in (3, 4)  # optipng can strip the alpha channel

    # Get thumbnail from example with failing example thumbnail behaviour
    # (i.e. thumbnail should be "BROKEN" stamp)
    thumb_fname = Path(
        sphinx_app.outdir, "_images", "sphx_glr_plot_failing_example_thumb.png"
    )
    thumbnail = np.asarray(Image.open(thumb_fname))
    assert broken_stamp.shape[:2] == thumbnail.shape[:2]
    corr = np.corrcoef(broken_stamp[..., :3].ravel(), thumbnail[..., :3].ravel())[0, 1]
    assert corr > 0.99  # i.e. thumbnail and "BROKEN" stamp are identical

    # Get thumbnail from example with default thumbnail behaviour
    # (i.e. thumbnail should be the plot from the example, not the "BROKEN" stamp)
    thumb_fname = Path(
        sphinx_app.outdir,
        "_images",
        "sphx_glr_plot_failing_example_thumbnail_thumb.png",
    )
    thumbnail = np.asarray(Image.open(thumb_fname))
    assert broken_stamp.shape[:2] == thumbnail.shape[:2]
    corr = np.corrcoef(broken_stamp[..., :3].ravel(), thumbnail[..., :3].ravel())[0, 1]
    assert corr < 0.7  # i.e. thumbnail and "BROKEN" stamp are not identical


def test_multi_image(sphinx_app):
    """Test `sphinx_gallery_multi_image(_block)` variables."""
    generated_examples_dir = Path(sphinx_app.outdir, "auto_examples")

    # Check file-wide `sphinx_gallery_multi_image="single"` produces no multi-img
    html_fname = generated_examples_dir / "plot_multi_image_separate.html"
    html = html_fname.read_text(encoding="utf-8")
    assert "sphx-glr-single-img" in html
    assert "sphx-glr-multi-img" not in html

    # Check block-specific `sphinx_gallery_multi_image_block` produces mixed img classes
    html_fname = generated_examples_dir / "plot_multi_image_block_separate.html"
    html = html_fname.read_text(encoding="utf-8")
    # find start of each code block
    matches = re.finditer('<div class="highlight-Python notranslate">', html)
    starts = [match.start() for match in matches] + [-1]
    assert len(starts) == 4  # 3 code block plus an extra for end index
    for block_idx, (start, end) in enumerate(zip(starts[:-1], starts[1:])):
        # ignore first code block (just imports)
        block_html = html[start:end]
        if block_idx == 1:  # multi-img classes for this code block
            assert "sphx-glr-multi-img" in block_html
            assert "sphx-glr-single-img" not in block_html
        elif block_idx == 2:  # single-img classes for this code block
            assert "sphx-glr-single-img" in block_html
            assert "sphx-glr-multi-img" not in block_html


def test_command_line_args_img(sphinx_app):
    generated_examples_dir = Path(sphinx_app.outdir, "auto_examples")
    thumb_fname = "../_images/sphx_glr_plot_command_line_args_thumb.png"
    file_fname = generated_examples_dir / thumb_fname
    assert file_fname.is_file(), file_fname


def test_image_formats(sphinx_app):
    """Test Image format support."""
    generated_examples_dir = Path(sphinx_app.outdir, "auto_examples")
    generated_examples_index = generated_examples_dir / "index.html"
    html = generated_examples_index.read_text(encoding="utf-8")
    thumb_fnames = [
        "../_images/sphx_glr_plot_svg_thumb.svg",
        "../_images/sphx_glr_plot_numpy_matplotlib_thumb.png",
        "../_images/sphx_glr_plot_animation_thumb.gif",
        "../_images/sphx_glr_plot_webp_thumb.webp",
    ]
    for thumb_fname in thumb_fnames:
        file_fname = generated_examples_dir / thumb_fname
        assert file_fname.is_file(), file_fname
        want_html = f'src="{thumb_fname}"'
        assert want_html in html
    # the original GIF does not get copied because it's not used in the
    # reST/HTML, so can't add it to this check
    for ex, ext, nums in (
        ("plot_svg", "svg", [1]),
        ("plot_numpy_matplotlib", "png", [1]),
        ("plot_animation", "png", [1, 3]),
        ("plot_animation", "mp4", [2]),
        ("plot_webp", "webp", [1]),
    ):
        html_fname = generated_examples_dir / f"{ex}.html"
        html = html_fname.read_text(encoding="utf-8")
        for num in nums:
            img_fname0 = f"../_images/sphx_glr_{ex}_{num:03}.{ext}"
            file_fname = generated_examples_dir / img_fname0
            assert file_fname.is_file(), file_fname
            want_html = f'src="{img_fname0}"'
            assert want_html in html
            img_fname2 = f"../_images/sphx_glr_{ex}_{num:03}_2_00x.{ext}"
            file_fname2 = generated_examples_dir / img_fname2
            want_html = f'srcset="{img_fname0}, {img_fname2} 2.00x"'
            if ext in ("png", "jpg", "svg", "webp"):
                # check 2.00x (tests directive)
                assert file_fname2.is_file(), file_fname2
                assert want_html in html


def test_repr_html_classes(sphinx_app):
    """Test appropriate _repr_html_ classes."""
    example_file = Path(sphinx_app.outdir, "auto_examples", "plot_repr.html")
    lines = example_file.read_text(encoding="utf-8")
    assert 'div class="output_subarea output_html rendered_html output_result"' in lines
    assert "gallery-rendered-html.css" in lines


_BACKREF_LINK = re.compile(
    r'<a class="([^"]*sphx-glr-backref[^"]*)" href="([^"]+)"'
    r'(?: title="([^"]+)")?>(.*?)</a>',
    re.S,
)
_HTML_TAG = re.compile(r"<[^>]+>")


def _backref_links(lines):
    """Extract embedded code links as dicts of {classes, href, title, text}."""
    return [
        dict(
            classes=set(cls.split()),
            href=href,
            title=title,
            text=_HTML_TAG.sub("", html),
        )
        for cls, href, title, html in _BACKREF_LINK.findall(lines)
    ]


def _assert_link(links, text, classes, href_re=None):
    """Assert some link with this text has these sphx-glr classes (and href)."""
    __tracebackhide__ = True
    with_text = [link for link in links if link["text"] == text]
    assert with_text, f"no link with text {text!r}"
    for link in with_text:
        got = {c for c in link["classes"] if c.startswith("sphx-glr")}
        if got == set(classes) and (
            href_re is None or re.search(href_re, link["href"]) is not None
        ):
            return link
    raise AssertionError(f"no link with text {text!r} matching {classes}: {with_text}")


def _assert_dummy_links(links, mod, page, cls_name, inst):
    """Assert instance/class/method/property links for a tinybuild dummy class."""
    __tracebackhide__ = True
    module_css = "sphx-glr-backref-module-sphinx_gallery-_dummy"
    anchor = "".join(rf"{part}[._-]" for part in mod.split(".") if part)
    href = rf"sphinx_gallery\._dummy\.{page}#sphinx[_-]gallery[.-]_dummy[.-]{anchor}"
    # instance
    link = _assert_link(
        links,
        inst,
        [module_css, "sphx-glr-backref-type-py-class", "sphx-glr-backref-instance"],
        href_re=href,
    )
    assert link["title"] == f"sphinx_gallery._dummy.{cls_name}"
    # class
    link = _assert_link(
        links,
        f"sphinx_gallery._dummy.{mod}{cls_name}",
        [module_css, "sphx-glr-backref-type-py-class"],
        href_re=href,
    )
    assert link["title"] == f"sphinx_gallery._dummy.{cls_name}"
    # method
    link = _assert_link(
        links,
        f"{inst}.run",
        [module_css, "sphx-glr-backref-type-py-method"],
        href_re=href + f"{cls_name}" + "[.-]run",
    )
    assert link["title"] == f"sphinx_gallery._dummy.{cls_name}.run"
    # property (Sphinx 2+ calls it a method rather than attribute, so any of)
    with_text = [link for link in links if link["text"] == f"{inst}.prop"]
    assert len(with_text) >= 1
    link = with_text[0]
    assert re.search(href + f"{cls_name}" + "[.-]prop", link["href"]) is not None
    assert module_css in link["classes"]
    assert any(
        f"sphx-glr-backref-type-py-{kind}" in link["classes"]
        for kind in ("attribute", "method", "property")
    )


def test_embed_links_and_styles(sphinx_app):
    """Test that links and styles are embedded properly in doc."""
    out_dir = sphinx_app.outdir
    src_dir = sphinx_app.srcdir
    examples_dir = Path(out_dir, "auto_examples")
    assert examples_dir.is_dir()
    assert (examples_dir / "plot_numpy_matplotlib.html").is_file()
    example_file = examples_dir / "plot_numpy_matplotlib.html"
    lines = example_file.read_text(encoding="utf-8")
    # ensure we've linked properly
    links = _backref_links(lines)
    assert "#module-matplotlib.colors" in lines
    assert "matplotlib.colors.is_color_like" in lines
    _assert_link(
        links,
        "is_color_like",
        [
            "sphx-glr-backref-module-matplotlib-colors",
            "sphx-glr-backref-type-py-function",
        ],
    )
    assert "#module-numpy" in lines
    assert "numpy.arange.html" in lines
    _assert_link(
        links,
        "np.arange",
        ["sphx-glr-backref-module-numpy", "sphx-glr-backref-type-py-function"],
    )
    assert "#module-matplotlib.pyplot" in lines
    assert "pyplot.html" in lines or "pyplot_summary.html" in lines
    assert ".html#matplotlib.figure.Figure.tight_layout" in lines
    assert "matplotlib.axes.Axes.plot.html#matplotlib.axes.Axes.plot" in lines
    assert "matplotlib_configuration_api.html#matplotlib.RcParams" in lines
    assert (
        "mpl_toolkits.mplot3d.axes3d.Axes3D.plot.html#mpl_toolkits.mplot3d.axes3d.Axes3D.plot"
        in lines
    )
    assert "stdtypes.html#list" in lines
    assert "warnings.html#warnings.warn" in lines
    assert "itertools.html#itertools.compress" in lines
    assert "numpy.ndarray.html" in lines
    # see issue 617
    id_names = re.search(
        r"sphinx_gallery.backreferences.html#sphinx[_,-]gallery[.,-]backreferences[.,-]identify[_,-]names",  # noqa: E501
        lines,
    )
    assert id_names is not None
    # instances have an extra CSS class
    _assert_link(
        links,
        "x",
        [
            "sphx-glr-backref-module-matplotlib-figure",
            "sphx-glr-backref-type-py-class",
            "sphx-glr-backref-instance",
        ],
    )
    _assert_link(
        links,
        "Figure",
        [
            "sphx-glr-backref-module-matplotlib-figure",
            "sphx-glr-backref-type-py-class",
        ],
    )
    # gh-587: no classes that are only marked as module without type
    for link in links:
        has_module = any(
            c.startswith("sphx-glr-backref-module-") for c in link["classes"]
        )
        has_type = any(c.startswith("sphx-glr-backref-type-") for c in link["classes"])
        assert has_module == has_type, link
    _assert_link(
        links,
        "sphinx_gallery.backreferences.identify_names",
        [
            "sphx-glr-backref-module-sphinx_gallery-backreferences",
            "sphx-glr-backref-type-py-function",
        ],
    )
    # gh-587: np.random.RandomState links properly
    # NumPy has had this linked as numpy.random.RandomState and
    # numpy.random.mtrand.RandomState so we need regex...
    randomstate_href = r"\.html#numpy\.random\.(mtrand\.)?RandomState"
    assert [
        link
        for link in links
        if link["text"] == "np.random.RandomState"
        and "sphx-glr-backref-type-py-class" in link["classes"]
        and "sphx-glr-backref-instance" not in link["classes"]
        and re.search(randomstate_href, link["href"]) is not None
    ]
    assert [
        link
        for link in links
        if link["text"] == "rng"
        and "sphx-glr-backref-type-py-class" in link["classes"]
        and "sphx-glr-backref-instance" in link["classes"]
        and re.search(randomstate_href, link["href"]) is not None
    ]
    # gh-587: methods of classes in the module currently being documented
    # issue 617 (regex '-'s)
    _assert_dummy_links(links, "", r"html", "DummyClass", "dc")
    # gh-1364: methods of nested classes in the module currently being documented
    _assert_dummy_links(links, "nested.", r"nested\.html", "NestedDummyClass", "ndc")

    # We do a parallel build so there should not be memory usage reported
    assert "memory usage" not in lines

    # CSS styles
    assert 'class="sphx-glr-signature"' in lines
    assert 'class="sphx-glr-timing"' in lines
    for kind in ("python", "jupyter"):
        assert (
            f'class="sphx-glr-download sphx-glr-download-{kind} docutils container"'
            in lines
        )  # noqa:E501

    # highlight language
    fname = Path(src_dir, "auto_examples", "plot_numpy_matplotlib.rst")
    assert fname.is_file()
    rst = fname.read_text(encoding="utf-8")
    assert ".. code-block:: Python\n" in rst

    # warnings
    want_warn = (
        r".*plot_numpy_matplotlib\.py:[0-9][0-9]: RuntimeWarning: "
        r"This warning should show up in the output.*"
    )
    assert re.match(want_warn, lines, re.DOTALL) is not None
    sys.stdout.write(lines)

    lines = (examples_dir / "plot_pickle.html").read_text("utf-8")
    assert "joblib.Parallel.html" in lines


def test_backreferences(sphinx_app):
    """Test backreferences."""
    out_dir = Path(sphinx_app.outdir)
    mod_file = out_dir / "gen_modules" / "sphinx_gallery.sorting.html"
    lines = mod_file.read_text(encoding="utf-8")
    assert "ExplicitOrder" in lines  # in API doc
    assert "plot_second_future_imports.html" in lines  # backref via code use
    assert "FileNameSortKey" in lines  # in API doc
    assert "plot_numpy_matplotlib.html" in lines  # backref via :class: in str
    mod_file = out_dir / "gen_modules" / "sphinx_gallery.backreferences.html"
    lines = mod_file.read_text(encoding="utf-8")
    assert "NameFinder" in lines  # in API doc
    assert "plot_future_imports.html" in lines  # backref via doc block
    # rendered file
    html_file = out_dir / "auto_examples" / "plot_second_future_imports.html"
    assert html_file.is_file()
    html = html_file.read_text(encoding="utf-8")
    assert "sphinx_gallery.sorting.html#sphinx_gallery.sorting.ExplicitOrder" in html  # noqa: E501
    assert "sphinx_gallery.scrapers.html#sphinx_gallery.scrapers.clean_modules" in html  # noqa: E501
    assert "figure_rst.html" not in html  # excluded


def test_backreferences_dirhtml(sphinx_dirhtml_app):
    """Test backreferences in dirhtml doc."""
    out_dir = Path(sphinx_dirhtml_app.outdir)
    mod_file = out_dir / "gen_modules" / "sphinx_gallery.sorting" / "index.html"
    lines = mod_file.read_text(encoding="utf-8")
    assert "ExplicitOrder" in lines  # in API doc
    assert "plot_second_future_imports/" in lines  # backref via code use
    assert "FileNameSortKey" in lines  # in API doc
    assert "plot_numpy_matplotlib/" in lines  # backref via :class: in str
    mod_file = out_dir / "gen_modules" / "sphinx_gallery.backreferences" / "index.html"
    lines = mod_file.read_text(encoding="utf-8")
    assert "NameFinder" in lines  # in API doc
    assert "plot_future_imports/" in lines  # backref via doc block
    # rendered file
    html_file = out_dir / "auto_examples" / "plot_second_future_imports" / "index.html"
    assert html_file.is_file()
    html = html_file.read_text(encoding="utf-8")
    assert "sphinx_gallery.sorting/#sphinx_gallery.sorting.ExplicitOrder" in html  # noqa: E501
    assert "sphinx_gallery.scrapers/#sphinx_gallery.scrapers.clean_modules" in html  # noqa: E501
    assert "figure_rst.html" not in html  # excluded
    # embedded code links work for dirhtml too (the old HTML rewriting could not)
    html_file = out_dir / "auto_examples" / "plot_numpy_matplotlib" / "index.html"
    links = _backref_links(html_file.read_text(encoding="utf-8"))
    _assert_link(
        links,
        "np.arange",
        ["sphx-glr-backref-module-numpy", "sphx-glr-backref-type-py-function"],
    )
    link = _assert_link(
        links,
        "sphinx_gallery.backreferences.identify_names",
        [
            "sphx-glr-backref-module-sphinx_gallery-backreferences",
            "sphx-glr-backref-type-py-function",
        ],
    )
    # internal links resolve relative to the dirhtml page location
    assert link["href"].startswith("../../gen_modules/"), link


@pytest.mark.parametrize(
    "rst_file, example_used_in",
    [
        pytest.param(
            "sphinx_gallery.backreferences.identify_names.examples",
            "plot_numpy_matplotlib",
            id="identify_names",
        ),
        pytest.param(
            "sphinx_gallery.sorting.ExplicitOrder.examples",
            "plot_second_future_imports",
            id="ExplicitOrder",
        ),
        # an intersphinx inventory prefix survives into the backreference name, so
        # its colon must be sanitized out of the filename (invalid on Windows)
        pytest.param(
            "sphinx_gallery_sphinx_gallery.sorting.ExplicitOrder.examples",
            "plot_second_future_imports",
            id="inventory-prefix",
        ),
    ],
)
def test_backreferences_examples_rst(sphinx_app, rst_file, example_used_in):
    """Test linking to mini-galleries using backreferences_dir."""
    backref_dir = sphinx_app.srcdir
    examples_rst = Path(backref_dir, "gen_modules", "backreferences", rst_file)
    lines = examples_rst.read_text(encoding="utf-8")
    assert example_used_in in lines
    # check the .. raw:: html div count
    n_open = lines.count("<div")
    n_close = lines.count("</div")
    assert n_open == n_close
    # tinybuild's examples_dirs is outside srcdir, so resolving these srcdir-absolute
    # paths against it would climb above srcdir and never resolve
    assert "/../" not in lines
    targets = re.findall(r":doc:`(.*?)`|\.\. image:: (\S+)", lines)
    assert targets
    for target in itertools.chain.from_iterable(targets):
        assert not target or target.startswith("/auto_examples/"), target


def test_backreferences_filenames(sphinx_app):
    """Backreference filenames must be usable on every platform."""
    backref_dir = Path(sphinx_app.srcdir, "gen_modules", "backreferences")
    bad = [p.name for p in backref_dir.iterdir() if set(p.name) & set(r'<>:"/\|?*')]
    assert bad == []


def test_backreferences_examples_html(sphinx_app):
    """Test linking to mini-galleries using backreferences_dir."""
    backref_file = Path(
        sphinx_app.outdir, "gen_modules", "sphinx_gallery.backreferences.html"
    )
    lines = backref_file.read_text(encoding="utf-8")
    # Class properties not properly checked on older Sphinx (e.g. 3)
    # so let's use the "id" instead
    regex = re.compile(r'<dt[ \S]*id="sphinx_gallery.backreferences.[ \S]*>')
    n_documented = len(regex.findall(lines))
    possible = "\n".join(line for line in lines.split("\n") if "<dt " in line)
    # identify_names, NameFinder NameFinder.get_mapping, NameFinder.visit_Attribute,
    # NameFinder.visit_Import NameFinder.visit_ImportFrom, NameFinder.visit_Name,
    # Backreference, Backreference.fname, Backreference.src_dir,
    # Backreference.target_dir, Backreference.intro, Backreference.title
    assert n_documented == 13, possible
    # identify_names, NameFinder (2); once doc, once left bar (x2)
    n_mini = lines.count("Examples using ")
    assert n_mini == 4
    # only 2 actual mini-gallery divs
    n_div = lines.count('<div class="sphx-glr-thumbnails')
    assert n_div == 2
    # 2 documented uses
    n_thumb = lines.count('<div class="sphx-glr-thumbcontainer')
    assert n_thumb == 2
    # matched opening/closing divs
    n_open = lines.count("<div")
    n_close = lines.count("</div")
    assert n_open == n_close  # should always be equal

    backref_file = Path(sphinx_app.outdir, "gen_modules", "sphinx_gallery._dummy.html")
    lines = backref_file.read_text(encoding="utf-8")
    # Class properties not properly checked on older Sphinx (e.g. 3)
    # so let's use the "id" instead
    regex = re.compile(r'<dt[ \S]*id="sphinx_gallery._dummy.[ \S]*>')
    n_documented = len(regex.findall(lines))
    possible = "\n".join(line for line in lines.split("\n") if "<dt " in line)
    # DummyClass, DummyClass.prop, DummyClass.run
    assert n_documented == 3, possible
    # DummyClass (1); once doc, once left bar (x2)
    n_mini = lines.count("Examples using ")
    assert n_mini == 2
    # only 1 actual mini-gallery divs
    n_div = lines.count('<div class="sphx-glr-thumbnails')
    assert n_div == 1
    # 3 documented uses
    n_thumb = lines.count('<div class="sphx-glr-thumbcontainer')
    assert n_thumb == 1
    # matched opening/closing divs
    n_open = lines.count("<div")
    n_close = lines.count("</div")
    assert n_open == n_close  # should always be equal

    backref_file = Path(
        sphinx_app.outdir, "gen_modules", "sphinx_gallery._dummy.nested.html"
    )
    lines = backref_file.read_text(encoding="utf-8")
    # Class properties not properly checked on older Sphinx (e.g. 3)
    # so let's use the "id" instead
    regex = re.compile(r'<dt[ \S]*id="sphinx_gallery._dummy.nested.[ \S]*>')
    n_documented = len(regex.findall(lines))
    possible = "\n".join(line for line in lines.split("\n") if "<dt " in line)
    # NestedDummyClass, NestedDummyClass.prop, NestedDummyClass.run
    assert n_documented == 3, possible
    # DummyClass (1); once doc, once left bar (x2)
    n_mini = lines.count("Examples using ")
    assert n_mini == 2
    # only 1 actual mini-gallery divs
    n_div = lines.count('<div class="sphx-glr-thumbnails')
    assert n_div == 1
    # 3 documented uses
    n_thumb = lines.count('<div class="sphx-glr-thumbcontainer')
    assert n_thumb == 1
    # matched opening/closing divs
    n_open = lines.count("<div")
    n_close = lines.count("</div")
    assert n_open == n_close  # should always be equal


def test_logging_std_nested(sphinx_app):
    """Test that nested stdout/stderr uses within a given script work."""
    log_rst = Path(sphinx_app.srcdir, "auto_examples", "plot_log.rst")
    lines = log_rst.read_text(encoding="utf-8")
    assert ".. code-block:: none\n\n    is in the same cell" in lines
    assert ".. code-block:: none\n\n    is not in the same cell" in lines


def _example_times(root: Path) -> dict[str, str]:
    """Map every row of every ``sg_execution_times.rst`` to its rendered time."""
    out = {}
    for times in sorted(root.rglob("sg_execution_times.rst")):
        text = times.read_text(encoding="utf-8")
        for name, value in re.findall(r"^   \* - (.+)\n     - (\S+)\n", text, re.M):
            if name != "Example":  # the header row
                out[f"{times.relative_to(root)}::{name}"] = value
    return out


def _assert_mtimes(
    list_orig: list[Path],
    list_new: list[Path],
    different: tuple[str, ...] = (),
    ignore: tuple[str, ...] = (),
) -> None:
    """Assert that the correct set of files were changed based on mtime."""
    import numpy as np
    from numpy.testing import assert_allclose

    assert [x.name for x in list_orig] == [x.name for x in list_new]
    for orig, new in zip(list_orig, list_new):
        check_name = orig.stem.removesuffix(".codeobj")
        if check_name in different:
            assert np.abs(orig.stat().st_mtime - new.stat().st_mtime) > 0.1, (
                f"{orig.name} should have been updated but was not"
            )
        elif check_name not in ignore:
            assert_allclose(
                orig.stat().st_mtime,
                new.stat().st_mtime,
                atol=1e-3,
                rtol=1e-20,
                err_msg=f"{orig.name} was updated but should not have been",
            )


def test_rebuild(tmp_path_factory, sphinx_app):
    """Test examples that haven't been changed aren't run twice."""
    # First run completes in the fixture.
    status = sphinx_app._status.getvalue()
    lines = [line for line in status.split("\n") if "removed" in line]
    want = f".*{N_RST} added, 0 changed, 0 removed.*"
    assert re.match(want, status, re.MULTILINE | re.DOTALL) is not None, lines
    want = ".*targets for [2-3] source files that are out of date$.*"
    lines = [line for line in status.split("\n") if "out of date" in line]
    assert re.match(want, status, re.MULTILINE | re.DOTALL) is not None, lines
    lines = [line for line in status.split("\n") if "on MD5" in line]
    want = ".*executed %d out of %d.*after excluding 0 files.*based on MD5.*" % (
        N_GOOD,
        N_EXAMPLES,
    )
    assert re.match(want, status, re.MULTILINE | re.DOTALL) is not None, lines
    old_src_dir = tmp_path_factory.getbasetemp() / "root_old"
    shutil.copytree(sphinx_app.srcdir, old_src_dir)
    generated_modules_0 = sorted(
        f for f in (old_src_dir / "gen_modules").iterdir() if f.is_file()
    )
    generated_backrefs_0 = sorted(
        f
        for f in (old_src_dir / "gen_modules" / "backreferences").iterdir()
        # `backreferences_all.json` is checked separately, below
        if f.name != "backreferences_all.json"
    )
    generated_rst_0 = sorted(
        f for f in (old_src_dir / "auto_examples").iterdir() if f.suffix == ".rst"
    )
    # `.cost.json` holds run timings, so it legitimately changes whenever its
    # example re-runs; `test_rebuild` checks those separately
    generated_json_0 = sorted(
        f
        for f in (old_src_dir / "auto_examples").iterdir()
        if f.suffix == ".json" and not f.name.endswith(".cost.json")
    )
    generated_md5_0 = sorted(
        f for f in (old_src_dir / "auto_examples").iterdir() if f.suffix == ".md5"
    )
    copied_py_0 = sorted(
        f for f in (old_src_dir / "auto_examples").iterdir() if f.suffix == ".py"
    )
    copied_ipy_0 = sorted(
        f for f in (old_src_dir / "auto_examples").iterdir() if f.suffix == ".ipynb"
    )
    assert len(generated_modules_0) > 0
    assert len(generated_backrefs_0) > 0
    assert len(generated_rst_0) > 0
    assert len(generated_json_0) > 0
    assert len(generated_md5_0) > 0
    assert len(copied_py_0) > 0
    assert len(copied_ipy_0) > 0
    assert len(sphinx_app.config.sphinx_gallery_conf["stale_examples"]) == 0
    assert Path(
        sphinx_app.outdir, "_images", "sphx_glr_plot_numpy_matplotlib_001.png"
    ).is_file()

    #
    # run a second time, no files should be updated
    #

    src_dir = sphinx_app.srcdir
    del sphinx_app  # don't accidentally use it below
    conf_dir = src_dir
    out_dir = Path(src_dir, "_build", "html")
    toctrees_dir = Path(src_dir, "_build", "toctrees")
    time.sleep(0.1)
    with docutils_namespace():
        new_app = Sphinx(
            src_dir,
            conf_dir,
            out_dir,
            toctrees_dir,
            buildername="html",
            status=StringIO(),
        )
        new_app.build(False, [])
    status = new_app._status.getvalue()
    lines = [line for line in status.split("\n") if "0 removed" in line]
    # XXX on Windows this can be more
    if sys.platform.startswith("win"):
        assert (
            re.match(
                ".*[01] added, ([1-9]|1[0-4]) changed, 0 removed$.*",
                status,
                re.MULTILINE | re.DOTALL,
            )
            is not None
        ), lines
    else:
        assert (
            re.match(
                ".*[01] added, ([1-9]|1[0-3]) changed, 0 removed$.*",
                status,
                re.MULTILINE | re.DOTALL,
            )
            is not None
        ), lines
    want = ".*executed 0 out of %s.*after excluding %s files.*based on MD5.*" % (
        N_FAILING,
        N_GOOD,
    )
    assert re.match(want, status, re.MULTILINE | re.DOTALL) is not None
    n_stale = len(new_app.config.sphinx_gallery_conf["stale_examples"])
    assert n_stale == N_GOOD
    assert Path(
        new_app.outdir, "_images", "sphx_glr_plot_numpy_matplotlib_001.png"
    ).is_file()

    generated_modules_1 = sorted(
        f for f in Path(new_app.srcdir, "gen_modules").iterdir() if f.is_file()
    )
    generated_backrefs_1 = sorted(
        f
        for f in Path(new_app.srcdir, "gen_modules", "backreferences").iterdir()
        # `backreferences_all.json` is checked separately, below
        if f.name != "backreferences_all.json"
    )
    generated_rst_1 = sorted(
        f for f in Path(new_app.srcdir, "auto_examples").iterdir() if f.suffix == ".rst"
    )
    generated_json_1 = sorted(
        f
        for f in Path(new_app.srcdir, "auto_examples").iterdir()
        if f.suffix == ".json" and not f.name.endswith(".cost.json")
    )
    generated_md5_1 = sorted(
        f for f in Path(new_app.srcdir, "auto_examples").iterdir() if f.suffix == ".md5"
    )
    copied_py_1 = sorted(
        f for f in Path(new_app.srcdir, "auto_examples").iterdir() if f.suffix == ".py"
    )
    copied_ipy_1 = sorted(
        f
        for f in Path(new_app.srcdir, "auto_examples").iterdir()
        if f.suffix == ".ipynb"
    )

    # mtimes for modules
    _assert_mtimes(generated_modules_0, generated_modules_1)

    # mtimes for backrefs (gh-394)
    _assert_mtimes(generated_backrefs_0, generated_backrefs_1)

    # mtimes for .md5 files, rewritten whenever an example is executed
    _assert_mtimes(generated_md5_0, generated_md5_1)

    # The API usage page, its graphs, and backreferences_all.json are only rewritten
    # when their contents change, so an unchanged rebuild must leave them alone
    api_usage_0 = sorted(old_src_dir.glob("sg_api_usage.rst")) + sorted(
        old_src_dir.glob("*.dot")
    )
    api_usage_0.append(
        old_src_dir / "gen_modules" / "backreferences" / "backreferences_all.json"
    )
    api_usage_1 = [
        Path(new_app.srcdir, f.relative_to(old_src_dir)) for f in api_usage_0
    ]
    assert len(api_usage_0) == (4 if _has_graphviz() else 2)
    _assert_mtimes(api_usage_0, api_usage_1)

    # examples that did not re-run keep their cached cost, so sg_execution_times.rst
    # reports the last measured timings instead of zeroing them
    cost_json_0 = sorted((old_src_dir / "auto_examples").glob("*.cost.json"))
    cost_json_1 = [
        Path(new_app.srcdir, f.relative_to(old_src_dir)) for f in cost_json_0
    ]
    assert len(cost_json_0) > 0
    _assert_mtimes(cost_json_0, cost_json_1)
    # an example faster than the clock resolution really does measure 0 (seen on
    # Windows), so require the cache to be non-trivial rather than all-positive
    times = [json.loads(f.read_text(encoding="utf-8"))["time"] for f in cost_json_1]
    assert min(times) >= 0
    assert max(times) > 0

    # ... and no row of the rendered page may lose its timing, which is what the cache
    # is for: without it every example skipped this build reports 00:00.000 instead of
    # what it last measured
    old_times = _example_times(old_src_dir)
    new_times = _example_times(Path(new_app.srcdir))
    assert set(old_times) == set(new_times)
    zeroed = sorted(
        key
        for key, value in new_times.items()
        if value == "00:00.000" != old_times[key]
        and not any(name in key for name in _RERUN_EXAMPLES)
    )
    assert zeroed == []

    # generated reST files
    ignore = (
        # these two should almost always be different, but in case we
        # get extremely unlucky and have identical run times
        # on the one script that gets re-run (because it's a fail)...
        "sg_execution_times",
        "plot_future_imports_broken",
        "plot_scraper_broken",
        "plot_failing_example",
        "plot_failing_example_thumbnail",
        # the rst of rst-input gallery entries is updated, because
        # inputs are currently always copied over and "execution"
        # is no-op.
        "rst_gallery_entry",
    )
    _assert_mtimes(generated_rst_0, generated_rst_1, ignore=ignore)

    # mtimes for jsons
    _assert_mtimes(generated_json_0, generated_json_1)

    # mtimes for .py files (gh-395)
    _assert_mtimes(copied_py_0, copied_py_1)

    # mtimes for .ipynb files
    _assert_mtimes(copied_ipy_0, copied_ipy_1)

    #
    # run a third and a fourth time, changing one file or running one stale
    #

    for how in ("run_stale", "modify"):
        # modify must be last as this rerun setting tries to run the
        # broken example (subsequent tests depend on it)
        _rerun(
            how,
            src_dir,
            conf_dir,
            out_dir,
            toctrees_dir,
            generated_modules_0,
            generated_backrefs_0,
            generated_rst_0,
            generated_json_0,
            generated_md5_0,
            copied_py_0,
            copied_ipy_0,
        )


def _rerun(
    how,
    src_dir,
    conf_dir,
    out_dir,
    toctrees_dir,
    generated_modules_0,
    generated_backrefs_0,
    generated_rst_0,
    generated_json_0,
    generated_md5_0,
    copied_py_0,
    copied_ipy_0,
):
    """Rerun the sphinx build and check that the right files were changed."""
    time.sleep(0.1)
    confoverrides = dict()
    if how == "modify":
        fname = Path(src_dir, "../examples", "plot_numpy_matplotlib.py")
        lines = fname.read_text(encoding="utf-8").splitlines(keepends=True)
        with fname.open("w", encoding="utf-8") as fid:
            for line in lines:
                # Make a tiny change that won't affect the recommender
                if "FYI this" in line:
                    line = line.replace("FYI this", "FYA this")
                fid.write(line)
        out_of, excluding = N_FAILING + 1, N_GOOD - 1
        n_stale = N_GOOD - 1
    else:
        assert how == "run_stale"
        confoverrides["sphinx_gallery_conf.run_stale_examples"] = "True"
        confoverrides["sphinx_gallery_conf.filename_pattern"] = "plot_numpy_ma"
        out_of, excluding = 1, 0
        n_stale = 0
    with docutils_namespace():
        new_app = Sphinx(
            src_dir,
            conf_dir,
            out_dir,
            toctrees_dir,
            buildername="html",
            status=StringIO(),
            confoverrides=confoverrides,
        )
        new_app.build(False, [])
    status = new_app._status.getvalue()
    lines = [line for line in status.split("\n") if "source files that" in line]
    lines = "\n".join([how] + lines)
    flags = re.MULTILINE | re.DOTALL
    # for some reason, setting "confoverrides" above causes Sphinx to show
    # all targets out of date, even though they haven't been modified...
    want = f".*targets for {N_RST} source files that are out of date$.*"
    assert re.match(want, status, flags) is not None, lines
    # ... but then later detects that only some have actually changed:
    lines = [line for line in status.split("\n") if "changed," in line]
    # Ones that can change on stale:
    #
    # - auto_examples/future/plot_future_imports_broken
    # - auto_examples/future/sg_execution_times
    # - auto_examples/plot_failing_example
    # - auto_examples/plot_failing_example_thumbnail
    # - auto_examples/plot_no_parallel
    # - auto_examples/plot_scraper_broken
    # - auto_examples/rst_gallery_entry
    # - auto_examples/sg_execution_times
    # - auto_examples_rst_index/sg_execution_times
    # - auto_examples_with_rst/sg_execution_times
    # - sg_api_usage
    # - sg_execution_times
    #
    # Sometimes it's not all 8, for example when the execution time and
    # memory usage reported ends up being the same.
    #
    # Modifying an example then adds these two:
    # - auto_examples/index
    # - auto_examples/plot_numpy_matplotlib
    if how == "modify":
        n_ch = "([3-9]|1[0-4])"  # 3-14
    else:
        n_ch = "([1-9]|1[0-3])"  # 1-13
    lines = "\n".join([f"\n{how} != {n_ch}:"] + lines)
    want = f".*updating environment:.*[01] added, {n_ch} changed, 0 removed.*"
    assert re.match(want, status, flags) is not None, lines
    want = ".*executed 1 out of %s.*after excluding %s files.*based on MD5.*" % (
        out_of,
        excluding,
    )
    assert re.match(want, status, flags) is not None
    got_stale = len(new_app.config.sphinx_gallery_conf["stale_examples"])
    assert got_stale == n_stale
    assert Path(
        new_app.outdir, "_images", "sphx_glr_plot_numpy_matplotlib_001.png"
    ).is_file()

    generated_modules_1 = sorted(
        f for f in Path(new_app.srcdir, "gen_modules").iterdir() if f.is_file()
    )
    generated_backrefs_1 = sorted(
        f
        for f in Path(new_app.srcdir, "gen_modules", "backreferences").iterdir()
        # `backreferences_all.json` is checked separately, below
        if f.name != "backreferences_all.json"
    )
    generated_rst_1 = sorted(
        f for f in Path(new_app.srcdir, "auto_examples").iterdir() if f.suffix == ".rst"
    )
    generated_json_1 = sorted(
        f
        for f in Path(new_app.srcdir, "auto_examples").iterdir()
        if f.suffix == ".json" and not f.name.endswith(".cost.json")
    )
    generated_md5_1 = sorted(
        f for f in Path(new_app.srcdir, "auto_examples").iterdir() if f.suffix == ".md5"
    )
    copied_py_1 = sorted(
        f for f in Path(new_app.srcdir, "auto_examples").iterdir() if f.suffix == ".py"
    )
    copied_ipy_1 = sorted(
        f
        for f in Path(new_app.srcdir, "auto_examples").iterdir()
        if f.suffix == ".ipynb"
    )

    # mtimes for modules
    _assert_mtimes(generated_modules_0, generated_modules_1)

    # mtimes for backrefs (gh-394)
    _assert_mtimes(generated_backrefs_0, generated_backrefs_1)

    # generated reST files
    different = ("plot_numpy_matplotlib",)
    ignore = (
        # this one should almost always be different, but in case we
        # get extremely unlucky and have identical run times
        # on the one script above that changes...
        "sg_execution_times",
        "sg_api_usage",
        # this one will not change even though it was retried
        "plot_future_imports_broken",
        "plot_scraper_broken",
        "plot_failing_example",
        "plot_failing_example_thumbnail",
        # the rst of rst-input gallery entries is updated, because
        # inputs are currently always copied over and "execution"
        # is no-op.
        "rst_gallery_entry",
    )
    # mtimes for .md5 files, rewritten whenever an example is executed
    _assert_mtimes(
        generated_md5_0, generated_md5_1, different=("plot_numpy_matplotlib.py",)
    )

    rst_different, rst_ignore = different, ignore
    if how == "run_stale":
        # Re-running an unmodified example changes its reST only through the
        # reported run time, which is rounded to the ms -- when two runs land
        # in the same bucket the reST is byte-identical and _replace_md5
        # rightly leaves it (and its mtime) alone. The .md5 check above is the
        # deterministic proof that the example was actually re-run.
        rst_different, rst_ignore = (), ignore + different
    _assert_mtimes(generated_rst_0, generated_rst_1, rst_different, rst_ignore)

    # mtimes for jsons
    use_different = () if how == "run_stale" else different
    _assert_mtimes(generated_json_0, generated_json_1, ignore=ignore)

    # mtimes for .py files (gh-395)
    _assert_mtimes(copied_py_0, copied_py_1, different=use_different)

    # mtimes for .ipynb files
    _assert_mtimes(copied_ipy_0, copied_ipy_1, different=use_different)


# these embed a measured run time, so they legitimately differ between two builds
_TIMED_RST = ("sg_execution_times.rst",) + tuple(
    name.replace(".py", ".rst") for name in _RERUN_EXAMPLES
)


def _copy_tinybuild(sphinx_app, tmp_path):
    """Copy the whole tinybuild tree, since examples_dirs points outside of doc/."""
    shutil.copytree(Path(sphinx_app.srcdir).parent, tmp_path / "tinybuild")
    return tmp_path / "tinybuild" / "doc"


def _subprocess_build(src_dir, seed="0", *extra):
    """Build in a fresh process, which is the only way set order can vary."""
    proc = subprocess.run(
        [sys.executable, "-m", "sphinx", "-b", "html", "-d", "_build/doctrees"]
        + list(extra)
        + [".", "_build/html"],
        cwd=src_dir,
        env={**os.environ, "PYTHONHASHSEED": seed},
        capture_output=True,
        text=True,
    )
    assert proc.returncode == 0, proc.stdout[-4000:] + proc.stderr[-4000:]


def _snapshot_generated(src_dir):
    """Read every generated reST, graph, and JSON file in the source directory."""
    return {
        path.relative_to(src_dir): path.read_text(encoding="utf-8")
        for path in sorted(src_dir.rglob("*"))
        if path.is_file()
        and "_build" not in path.parts
        and path.suffix in (".rst", ".dot", ".json")
    }


def test_rebuild_deterministic(tmp_path, sphinx_app):
    """Test generated files do not depend on set iteration order.

    Sets iterate in a different order in every process, so a file generated from one
    can change on a rebuild even though nothing did. That is not merely churn: the
    ``.dot`` files are a ``note_dependency`` of ``sg_api_usage``, so a reshuffled
    graph marks the page outdated on every other build. Rebuilds run in-process
    share a hash seed and cannot catch it, hence the subprocesses here.
    """
    src_dir = _copy_tinybuild(sphinx_app, tmp_path)

    _subprocess_build(src_dir, "0")
    first = _snapshot_generated(src_dir)
    _subprocess_build(src_dir, "1")
    second = _snapshot_generated(src_dir)

    assert set(first) == set(second)
    # the artifacts most at risk are the ones built from sets, so make sure the
    # comparison actually covered them rather than silently finding nothing
    names = {path.name for path in first}
    assert "sg_api_usage.rst" in names
    assert "backreferences_all.json" in names
    if _has_graphviz():
        assert "sg_api_unused.dot" in names
    differ = sorted(
        str(path)
        for path, text in first.items()
        if text != second[path] and path.name not in _TIMED_RST
    )
    assert differ == []


def test_api_usage_purged(tmp_path, sphinx_app):
    """Test entries of a document that is no longer read are dropped.

    API entries are collected into the environment and persist across builds, so a
    module that stops being documented has to be purged explicitly or it lingers in
    the page forever.
    """
    src_dir = _copy_tinybuild(sphinx_app, tmp_path)
    # build here rather than reuse the fixture's, so that the entries really do come
    # from a pickled environment that the second build has to purge
    _subprocess_build(src_dir)
    api_usage = src_dir / "sg_api_usage.rst"
    assert "sphinx_gallery._dummy.unused_b" in api_usage.read_text(encoding="utf-8")

    # stop documenting one of the two dummy modules
    index = src_dir / "index.rst"
    index.write_text(
        index.read_text(encoding="utf-8").replace("   _dummy.unused_b\n", ""), **_W_KW
    )
    (src_dir / "gen_modules" / "sphinx_gallery._dummy.unused_b.rst").unlink()
    _subprocess_build(src_dir)

    text = api_usage.read_text(encoding="utf-8")
    assert "sphinx_gallery._dummy.unused_b" not in text
    assert "sphinx_gallery._dummy.unused_a" in text  # the other one survives


def test_parallel_read_api_usage(tmp_path, sphinx_app):
    """Test the API usage page is complete when documents are read in parallel.

    ``write_api_entries`` runs during the read phase, so under ``-j`` it fires in
    fork()ed workers whose entries only reach the main process via ``env-merge-info``.
    Without that merge the page silently loses most of its entries rather than
    failing, so compare a parallel full read against a serial one.
    """
    src_dir = _copy_tinybuild(sphinx_app, tmp_path)

    _subprocess_build(src_dir)
    serial = _snapshot_generated(src_dir)
    # -E to force every document to be re-read, so autodoc actually runs in the
    # workers; without it an incremental read has nothing to merge back
    _subprocess_build(src_dir, "0", "-E", "-j", "4")
    parallel = _snapshot_generated(src_dir)

    api_usage = Path("sg_api_usage.rst")
    assert api_usage in serial
    assert "sphinx_gallery._dummy.unused_a" in serial[api_usage]
    differ = sorted(
        str(path)
        for path, text in serial.items()
        if text != parallel[path] and path.name not in _TIMED_RST
    )
    assert differ == []


@pytest.mark.parametrize(
    "name, want",
    [
        pytest.param(
            "future/plot_future_imports_broken",
            ".*RuntimeError.*Forcing this example to fail on Python 3.*",
            id="future",
        ),
        pytest.param(
            "plot_scraper_broken",
            ".*ValueError.*zero-size array to reduction.*",
            id="scraper",
        ),
    ],
)
def test_error_messages(sphinx_app, name, want):
    """Test that informative error messages are added."""
    src_dir = Path(sphinx_app.srcdir)
    rst = (src_dir / "auto_examples" / f"{name}.rst").read_text("utf-8")
    assert re.match(want, rst, re.DOTALL) is not None, f"{name} should have had: {want}"


@pytest.mark.parametrize(
    "name, want",
    [
        pytest.param(
            "future/plot_future_imports_broken",
            ".*RuntimeError.*Forcing this example to fail on Python 3.*",
            id="future",
        ),
        pytest.param(
            "plot_scraper_broken",
            ".*ValueError.*zero-size array to reduction.*",
            id="scraper",
        ),
    ],
)
def test_error_messages_dirhtml(sphinx_dirhtml_app, name, want):
    """Test that informative error messages are added."""
    src_dir = sphinx_dirhtml_app.srcdir
    example_rst = Path(src_dir, "auto_examples", f"{name}.rst")
    rst = example_rst.read_text(encoding="utf-8")
    rst = rst.replace("\n", " ")
    assert re.match(want, rst) is not None


def test_alt_text_image(sphinx_app):
    """Test alt text for matplotlib images in html and rst."""
    out_dir = sphinx_app.outdir
    src_dir = sphinx_app.srcdir
    # alt text is fig titles, rst
    example_rst = Path(src_dir, "auto_examples", "plot_matplotlib_alt.rst")
    rst = example_rst.read_text(encoding="utf-8")
    # suptitle and axes titles
    assert ":alt: This is a sup title, subplot 1, subplot 2" in rst
    # multiple titles
    assert ":alt: Left Title, Center Title, Right Title" in rst

    # no fig title - alt text is file name, rst
    example_rst = Path(src_dir, "auto_examples", "plot_numpy_matplotlib.rst")
    rst = example_rst.read_text(encoding="utf-8")
    assert ":alt: plot numpy matplotlib" in rst
    # html
    example_html = Path(out_dir, "auto_examples", "plot_numpy_matplotlib.html")
    html = example_html.read_text(encoding="utf-8")
    assert 'alt="plot numpy matplotlib"' in html


def test_alt_text_thumbnail(sphinx_app):
    """Test alt text for thumbnail in html and rst."""
    out_dir = sphinx_app.outdir
    src_dir = sphinx_app.srcdir
    # check gallery index thumbnail, html
    generated_examples_index = Path(out_dir, "auto_examples", "index.html")
    html = generated_examples_index.read_text(encoding="utf-8")
    assert 'alt=""' in html
    # check backreferences thumbnail, html
    backref_html = Path(out_dir, "gen_modules", "sphinx_gallery.backreferences.html")
    html = backref_html.read_text(encoding="utf-8")
    assert 'alt=""' in html
    # check gallery index thumbnail, rst
    generated_examples_index = Path(src_dir, "auto_examples", "index.rst")
    rst = generated_examples_index.read_text(encoding="utf-8")
    assert ":alt:" in rst


def test_noqa_removal(sphinx_app):
    """Test that "noqa: E501" is removed from end of text blocks."""
    src_dir = sphinx_app.srcdir

    example_rst = Path(src_dir, "auto_examples", "plot_matplotlib_alt.rst")
    rst = example_rst.read_text(encoding="utf-8")
    assert "# noqa: E501" not in rst


def test_backreference_labels(sphinx_app):
    """Tests that backreference labels work."""
    src_dir = sphinx_app.srcdir
    out_dir = sphinx_app.outdir
    # Test backreference label
    backref_rst = Path(src_dir, "gen_modules", "sphinx_gallery.backreferences.rst")
    rst = backref_rst.read_text(encoding="utf-8")
    label = ".. _sphx_glr_backref_sphinx_gallery.backreferences.identify_names:"  # noqa: E501
    assert label in rst
    # Test html link
    index_html = Path(out_dir, "index.html")
    html = index_html.read_text(encoding="utf-8")
    link = 'href="gen_modules/sphinx_gallery.backreferences.html#sphx-glr-backref-sphinx-gallery-backreferences-identify-names">'  # noqa: E501
    assert link in html


@pytest.fixture(scope="module")
def minigallery_tree(sphinx_app):
    out_dir = sphinx_app.outdir
    minigallery_html = Path(out_dir, "minigallery.html")
    tree = lxml.html.fromstring(minigallery_html.read_text(encoding="utf-8"))

    names = tree.xpath('//p[starts-with(text(), "Test")]')
    divs = tree.find_class("sphx-glr-thumbnails")
    assert len(names) == len(divs)
    return {name.text_content(): div for name, div in zip(names, divs)}


@pytest.mark.parametrize(
    "test, heading, sortkey",
    [
        # first example, no heading
        ("Test 1-N", None, {"explicit"}),
        # first example, default heading, default level
        (
            "Test 1-D-D",
            ("h2", "Examples using sphinx_gallery.sorting.ExplicitOrder"),
            {"explicit"},
        ),
        # first example, default heading, custom level
        (
            "Test 1-D-C",
            ("h3", "Examples using sphinx_gallery.sorting.ExplicitOrder"),
            {"explicit"},
        ),
        # first example, custom heading, default level
        ("Test 1-C-D", ("h2", "This is a custom heading"), {"explicit"}),
        # both examples, no heading
        ("Test 2-N", None, {"explicit", "filename"}),
        # both examples, default heading, default level
        (
            "Test 2-D-D",
            ("h2", "Examples using one of multiple objects"),
            {"explicit", "filename"},
        ),
        # both examples, custom heading, custom level
        (
            "Test 2-C-C",
            ("h1", "This is a different custom heading"),
            {"explicit", "filename"},
        ),
        # filepath, no heading
        ("Test 1-F", None, {"path"}),
        # glob, no heading
        ("Test 2-F-G", None, {"glob"}),
        # all files
        (
            "Test 3-F-G-B",
            ("h2", "All the input types", ""),
            {"path", "glob", "explicit", "filename"},
        ),
        ("Test 1-F-R", None, ["plot_boo", "plot_cos"]),
        ("Test 1-S", None, ["plot_sub2", "plot_sub1"]),
        ("Test 3-N", None, {"path", "glob", "explicit", "filename"}),
    ],
)
def test_minigallery_directive(minigallery_tree, test, heading, sortkey):
    """Tests the functionality of the minigallery directive.

    Use `print(f"{test}: {lxml.html.tostring(text)}")` for checking.
    """
    assert test in minigallery_tree

    text = minigallery_tree[test]

    assert text is not None

    heading_element = text.xpath(
        'preceding-sibling::*[position()=1 and starts-with(name(), "h")]'
    )
    # Check headings
    if heading:
        assert heading_element[0].tag == heading[0]
        assert heading_element[0].text_content().startswith(heading[1])
    else:
        assert heading_element == []

    if test in ["Test 1-F-R", "Test 1-S"]:
        img = text.xpath('descendant::img[starts-with(@src, "_images/sphx_glr")]')
        # These examples are from subdir: examples_with_rst, examples_rst_index
        # thus we look for "rst"
        href = text.xpath('descendant::a[contains(@href, "rst")]')

        assert img and href

        for p, i, h in zip(sortkey, img, href):
            assert (p in i.values()[-1]) and (p in h.values()[-1])
    else:
        examples = {
            "explicit": "plot_second_future_imports",
            "filename": "plot_numpy_matplotlib",
            "path": "plot_log",
            "glob": "plot_matplotlib_alt",
        }

        for key, fname in examples.items():
            img = text.xpath(
                f'descendant::img[@src = "_images/sphx_glr_{fname}_thumb.png"]'
            )
            href = text.xpath(
                f'descendant::a[starts-with(@href, "auto_examples/{fname}.html")]'
            )
            if key in sortkey:
                assert img and href

            else:
                assert not (img or href)


def test_minigallery_duplicates(minigallery_tree):
    """Ensure minigallery removes duplicate examples.

    "Test duplicates" in `minigallery.rst` should result in only 2 examples:
    - plot_second_future_imports - object (`ExplicitOrder`) AND 2 file inputs
    - plot_numpy_matplotlib - object (`Block`) and 1 file input
    """
    assert "Test duplicates" in minigallery_tree

    text = minigallery_tree["Test duplicates"]

    imgs = text.xpath('descendant::img[starts-with(@src, "_images/sphx_glr")]')
    expected_examples = {
        "_images/sphx_glr_plot_second_future_imports_thumb.png",
        "_images/sphx_glr_plot_numpy_matplotlib_thumb.png",
    }
    assert {img.values()[-1] for img in imgs} == expected_examples


def test_matplotlib_warning_filter(sphinx_app):
    """Test Matplotlib agg warning is removed."""
    out_dir = sphinx_app.outdir
    example_html = Path(out_dir, "auto_examples", "plot_matplotlib_alt.html")
    html = example_html.read_text(encoding="utf-8")
    warning = (
        "Matplotlib is currently using agg, which is a"
        " non-GUI backend, so cannot show the figure."
    )
    assert warning not in html
    warning = "is non-interactive, and thus cannot be shown"
    assert warning not in html


def test_jupyter_notebook_pandoc(sphinx_app):
    """Test using pypandoc."""
    src_dir = sphinx_app.srcdir
    fname = Path(src_dir, "auto_examples", "plot_numpy_matplotlib.ipynb")
    md = fname.read_text(encoding="utf-8")

    md_sg = r"Use :mod:`sphinx_gallery` to link to other packages, like\n:mod:`numpy`, :mod:`matplotlib.colors`, and :mod:`matplotlib.pyplot`."  # noqa
    md_pandoc = r"Use `sphinx_gallery`{.interpreted-text role=\"mod\"} to link to other\npackages, like `numpy`{.interpreted-text role=\"mod\"},\n`matplotlib.colors`{.interpreted-text role=\"mod\"}, and\n`matplotlib.pyplot`{.interpreted-text role=\"mod\"}."  # noqa

    if any(_has_pypandoc()):
        assert md_pandoc in md
    else:
        assert md_sg in md


def test_jupyter_notebook_rst_prolog_epilog(sphinx_app):
    """Test that ``rst_prolog``/``rst_epilog`` link targets resolve (gh-1202)."""
    nb = json.loads(
        Path(sphinx_app.srcdir, "auto_examples", "plot_animation.ipynb").read_text(
            encoding="utf-8"
        )
    )
    # pandoc hard-wraps its output, so compare without the line breaks
    md = " ".join(
        " ".join("".join(cell["source"]).split())
        for cell in nb["cells"]
        if cell["cell_type"] == "markdown"
    )
    assert "[mylink](https://example.com)" in md
    assert "[My Other Link](https://example.org)" in md


def test_md5_hash(sphinx_app):
    """Test MD5 hashing."""
    src_dir = sphinx_app.srcdir
    fname = Path(src_dir, "auto_examples", "plot_log.py.md5")
    expected_md5 = "0edc2de97f96f3b55f8b4a21994931a8"
    actual_md5 = fname.read_text()

    assert actual_md5 == expected_md5


def test_interactive_example_logo_exists(sphinx_app):
    """Test that the binder logo path is correct."""
    root = Path(sphinx_app.outdir, "auto_examples")
    html = (root / "plot_svg.html").read_text(encoding="utf-8")
    img_strs = "\n" + "\n".join(re.findall("<img [^>]+>", html, re.DOTALL))
    path = re.match(
        r'.*<img alt="Launch binder" src="([^"]+)" (width|style)=[^/>]+\/>.*',
        html,
        re.DOTALL,
    )
    assert path is not None, img_strs
    path = path.groups()[0]
    img_fname = (root / path).absolute()
    assert "binder_badge_logo" in str(img_fname)  # can have numbers appended
    assert img_fname.is_file()
    assert (
        "https://mybinder.org/v2/gh/sphinx-gallery/sphinx-gallery.github.io/master?urlpath=lab/tree/notebooks/auto_examples/plot_svg.ipynb"
        in html
    )  # noqa: E501

    path = re.match(
        r'.*<img alt="Launch JupyterLite" src="([^"]*)" (width|style)=[^/>]+\/>.*',
        html,
        re.DOTALL,
    )
    assert path is not None
    path = path.groups()[0]
    img_fname = (root / path).absolute()
    assert "jupyterlite_badge_logo" in str(img_fname)  # can have numbers appended
    assert img_fname.is_file()


def test_download_and_interactive_note(sphinx_app):
    """Test text saying go to the end to download code or run the example."""
    root = Path(sphinx_app.outdir, "auto_examples")
    html = (root / "plot_svg.html").read_text(encoding="utf-8")

    pattern = (
        r"to download the full example.+" r"in your browser via JupyterLite or Binder"
    )
    assert re.search(pattern, html)


def test_defer_figures(sphinx_app):
    """Test the deferring of figures."""
    root = Path(sphinx_app.outdir, "auto_examples")
    fname = root / "plot_defer_figures.html"
    html = fname.read_text(encoding="utf-8")

    # The example has two code blocks with plotting commands, but the first
    # block has the flag ``sphinx_gallery_defer_figures``.  Thus, there should
    # be only one image, not two, in the output.
    assert "../_images/sphx_glr_plot_defer_figures_001.png" in html
    assert "../_images/sphx_glr_plot_defer_figures_002.png" not in html


def test_no_dummy_image(sphinx_app):
    """Test sphinx_gallery_dummy_images NOT created when executable is True."""
    img1 = Path(
        sphinx_app.srcdir, "auto_examples", "images", "sphx_glr_plot_repr_001.png"
    )
    img2 = Path(
        sphinx_app.srcdir, "auto_examples", "images", "sphx_glr_plot_repr_002.png"
    )
    assert not img1.is_file()
    assert not img2.is_file()


def test_jupyterlite_modifications(sphinx_app):
    src_dir = sphinx_app.srcdir

    for notebook_filename in Path(src_dir, "jupyterlite_contents").rglob("*.ipynb"):
        with notebook_filename.open() as f:
            notebook_content = json.load(f)

        first_cell = notebook_content["cells"][0]
        assert first_cell["cell_type"] == "markdown"
        assert (
            f"JupyterLite-specific change for {notebook_filename}"
            in first_cell["source"]
        )


def test_cpp_rst(sphinx_app):
    cpp_rst = Path(sphinx_app.srcdir) / "auto_examples" / "parse_this.rst"
    content = cpp_rst.read_text()
    assert content.count(".. code-block:: C++") == 3
    assert content.count(":dedent: 1", 1)
    assert "Download C++ source code" in content
    assert "binder-badge" not in content
    assert "lite-badge" not in content
    assert "Download Jupyter notebook" not in content


def test_matlab_rst(sphinx_app):
    matlab_rst = Path(sphinx_app.srcdir) / "auto_examples" / "isentropic.rst"
    content = matlab_rst.read_text()
    assert content.count(".. code-block:: Matlab", 3)
    assert "isentropic, adiabatic flow example\n==============" in content
    assert "Download Matlab source code" in content


def test_julia_rst(sphinx_app):
    julia_rst = Path(sphinx_app.srcdir) / "auto_examples" / "julia_sample.rst"
    content = julia_rst.read_text()
    assert content.count(".. code-block:: Julia", 3)
    assert "Julia example\n=============" in content
    assert "Download Julia source code" in content


def test_recommend_n_examples(sphinx_app):
    """Test correct thumbnails are displayed for an example."""
    pytest.importorskip("numpy")
    root = Path(sphinx_app.outdir, "auto_examples")
    fname = Path(root, "plot_defer_figures.html")
    html = fname.read_text(encoding="utf-8")

    (related_html,) = re.findall(
        '<p class="rubric">Related examples</p>(.*)</section>', html, re.DOTALL
    )

    n_thumbnails = related_html.count('<div class="sphx-glr-thumbnail-title">')
    n_examples = sphinx_app.config.sphinx_gallery_conf["recommender"]["n_examples"]
    assert n_thumbnails == n_examples

    # Check the same 3 related examples are shown (can change when new examples added)
    assert 'href="plot_webp.html"' in related_html
    assert 'href="plot_command_line_args.html"' in related_html
    assert 'href="plot_numpy_matplotlib.html"' in related_html


def test_sidebar_components_download_links(sphinx_app):
    """Test that the `sg_download_links.html` component works as expected."""
    example_file = Path(sphinx_app.outdir, "auto_examples", "plot_repr.html")
    tree = lxml.html.fromstring(example_file.read_text(encoding="utf-8"))

    for class_name, desc in [
        ("sphx-glr-download-python", "Download source code"),
        ("sphx-glr-download-jupyter", "Download Jupyter notebook"),
        ("sphx-glr-download-zip", "Download zipped"),
    ]:
        orig_href = (
            tree.find_class(class_name)[0]
            .getchildren()[0]
            .getchildren()[0]
            .attrib["href"]
        )
        sidebar_div = tree.find_class(f"{class_name}-sidebar")[0]
        assert sidebar_div.attrib["title"] == Path(orig_href).name
        assert sidebar_div.getchildren()[0].attrib["href"] == orig_href
        assert sidebar_div.getchildren()[0].text_content().strip() == desc


def test_sidebar_components_launcher_links(sphinx_app):
    """Test that the `sg_launcher_links.html` component works as expected."""
    example_file = Path(sphinx_app.outdir, "auto_examples", "plot_repr.html")
    tree = lxml.html.fromstring(example_file.read_text(encoding="utf-8"))

    for class_name in ["binder-badge", "lite-badge"]:
        orig_anchor = tree.find_class(class_name)[0].getchildren()[0]
        orig_href = orig_anchor.attrib["href"]
        orig_img = orig_anchor.getchildren()[0]
        sidebar_anchor = tree.find_class(f"{class_name}-sidebar")[0].getchildren()[0]
        assert sidebar_anchor.attrib["href"] == orig_href
        assert sidebar_anchor.getchildren()[0].attrib["src"] == orig_img.attrib["src"]
        assert sidebar_anchor.getchildren()[0].attrib["alt"] == orig_img.attrib["alt"]
