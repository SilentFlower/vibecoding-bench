"""
The virtuous test runner.
"""
